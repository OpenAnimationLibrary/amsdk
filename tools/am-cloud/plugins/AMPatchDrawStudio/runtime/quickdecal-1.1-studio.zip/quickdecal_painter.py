from __future__ import annotations

import argparse
import math
from pathlib import Path
import sys
import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk
from typing import Callable

from PIL import Image, ImageChops, ImageDraw, ImageTk

from am_bake import AMBakeError, BakeModel, Patch, parse_model, point_in_polygon


APP_NAME = "QuickDecal Painter"
APP_VERSION = "1.1"
MAX_UNDO = 12


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def rgb_to_hex(rgb: tuple[int, int, int]) -> str:
    return "#%02x%02x%02x" % rgb


def hex_to_rgb(value: str) -> tuple[int, int, int]:
    value = value.lstrip("#")
    if len(value) != 6:
        raise ValueError(f"Invalid color: {value}")
    return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))  # type: ignore[return-value]


def contrast_color(rgb: tuple[int, int, int]) -> str:
    luminance = 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2]
    return "#000000" if luminance > 150 else "#ffffff"


def triangle_weights(
    point: tuple[float, float],
    triangle: tuple[tuple[float, float], tuple[float, float], tuple[float, float]],
    tolerance: float = 1e-5,
) -> tuple[float, float, float] | None:
    """Return barycentric weights when *point* lies in the 2D triangle."""
    px, py = point
    (x1, y1), (x2, y2), (x3, y3) = triangle
    denominator = (y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3)
    if abs(denominator) < 1e-10:
        return None
    w1 = ((y2 - y3) * (px - x3) + (x3 - x2) * (py - y3)) / denominator
    w2 = ((y3 - y1) * (px - x3) + (x1 - x3) * (py - y3)) / denominator
    w3 = 1.0 - w1 - w2
    if min(w1, w2, w3) < -tolerance or max(w1, w2, w3) > 1.0 + tolerance:
        return None
    return (w1, w2, w3)


def affine_output_to_input(
    destination: tuple[tuple[float, float], tuple[float, float], tuple[float, float]],
    source: tuple[tuple[float, float], tuple[float, float], tuple[float, float]],
) -> tuple[float, float, float, float, float, float] | None:
    """Return Pillow AFFINE coefficients mapping destination pixels to source pixels."""
    (x1, y1), (x2, y2), (x3, y3) = destination
    (u1, v1), (u2, v2), (u3, v3) = source
    determinant = x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)
    if abs(determinant) < 1e-10:
        return None

    def coefficients(q1: float, q2: float, q3: float) -> tuple[float, float, float]:
        a = (q1 * (y2 - y3) + q2 * (y3 - y1) + q3 * (y1 - y2)) / determinant
        b = (q1 * (x3 - x2) + q2 * (x1 - x3) + q3 * (x2 - x1)) / determinant
        c = (
            q1 * (x2 * y3 - x3 * y2)
            + q2 * (x3 * y1 - x1 * y3)
            + q3 * (x1 * y2 - x2 * y1)
        ) / determinant
        return (a, b, c)

    a, b, c = coefficients(u1, u2, u3)
    d, e, f = coefficients(v1, v2, v3)
    return (a, b, c, d, e, f)


class TextureCanvas(tk.Canvas):
    def __init__(self, master: tk.Misc, app: "PainterApp") -> None:
        super().__init__(master, background="#282828", highlightthickness=0, cursor="crosshair")
        self.app = app
        self.scale = 1.0
        self.offset_x = 0.0
        self.offset_y = 0.0
        self.fit_mode = True
        self._photo: ImageTk.PhotoImage | None = None
        self._redraw_job: str | None = None
        self._stroke_last: tuple[float, float] | None = None
        self._panning = False
        self._pan_start = (0, 0)
        self._offset_start = (0.0, 0.0)

        self.bind("<Configure>", self._on_configure)
        self.bind("<ButtonPress-1>", self._left_press)
        self.bind("<B1-Motion>", self._left_drag)
        self.bind("<ButtonRelease-1>", self._left_release)
        self.bind("<ButtonPress-2>", self._pan_press)
        self.bind("<B2-Motion>", self._pan_drag)
        self.bind("<ButtonRelease-2>", self._pan_release)
        self.bind("<ButtonPress-3>", self._right_press)
        self.bind("<MouseWheel>", self._mouse_wheel)
        self.bind("<Button-4>", lambda event: self._linux_wheel(event, 1))
        self.bind("<Button-5>", lambda event: self._linux_wheel(event, -1))
        self.bind("<Motion>", self._motion)

    def _on_configure(self, _event: tk.Event) -> None:
        if self.fit_mode:
            self.fit_image()
        else:
            self.request_redraw()

    def fit_image(self) -> None:
        image = self.app.image
        if image is None:
            self.delete("all")
            return
        width = max(1, self.winfo_width())
        height = max(1, self.winfo_height())
        self.scale = max(0.02, min((width - 16) / image.width, (height - 16) / image.height))
        self.offset_x = (width - image.width * self.scale) / 2
        self.offset_y = (height - image.height * self.scale) / 2
        self.fit_mode = True
        self.redraw()

    def native_size(self) -> None:
        image = self.app.image
        if image is None:
            return
        self.scale = 1.0
        self.offset_x = (self.winfo_width() - image.width) / 2
        self.offset_y = (self.winfo_height() - image.height) / 2
        self.fit_mode = False
        self.redraw()

    def zoom(self, factor: float, canvas_x: float | None = None, canvas_y: float | None = None) -> None:
        image = self.app.image
        if image is None:
            return
        if canvas_x is None:
            canvas_x = self.winfo_width() / 2
        if canvas_y is None:
            canvas_y = self.winfo_height() / 2
        ix, iy = self.canvas_to_image(canvas_x, canvas_y)
        new_scale = clamp(self.scale * factor, 0.02, 4.0)
        self.scale = new_scale
        self.offset_x = canvas_x - ix * new_scale
        self.offset_y = canvas_y - iy * new_scale
        self.fit_mode = False
        self.redraw()

    def image_to_canvas(self, x: float, y: float) -> tuple[float, float]:
        return (self.offset_x + x * self.scale, self.offset_y + y * self.scale)

    def canvas_to_image(self, x: float, y: float) -> tuple[float, float]:
        return ((x - self.offset_x) / self.scale, (y - self.offset_y) / self.scale)

    def request_redraw(self) -> None:
        if self._redraw_job is None:
            self._redraw_job = self.after(25, self.redraw)

    def redraw(self) -> None:
        if self._redraw_job is not None:
            try:
                self.after_cancel(self._redraw_job)
            except tk.TclError:
                pass
            self._redraw_job = None
        self.delete("all")
        image = self.app.image
        model = self.app.model
        if image is None:
            self.create_text(
                self.winfo_width() / 2,
                self.winfo_height() / 2,
                text="Open an A:M .mdl file and its baked texture.",
                fill="#d0d0d0",
                font=("Segoe UI", 12),
            )
            return

        scaled_size = (
            max(1, round(image.width * self.scale)),
            max(1, round(image.height * self.scale)),
        )
        resample = Image.Resampling.NEAREST if self.scale >= 1.0 else Image.Resampling.BILINEAR
        display = image.resize(scaled_size, resample)
        self._photo = ImageTk.PhotoImage(display)
        self.create_image(self.offset_x, self.offset_y, anchor="nw", image=self._photo, tags=("texture",))

        if model and self.app.show_outlines.get():
            for patch in model.patches:
                points: list[float] = []
                for u, v in patch.uv_polygon:
                    cx, cy = self.image_to_canvas(u * image.width, v * image.height)
                    points.extend((cx, cy))
                selected = patch.index == self.app.selected_patch
                color = "#ff3030" if selected else "#1d1d1d"
                width = 3 if selected else 1
                self.create_polygon(
                    points,
                    outline=color,
                    fill="",
                    width=width,
                    tags=("patch_overlay",),
                )
                if self.app.show_labels.get():
                    u0, v0, u1, v1 = patch.uv_bounds
                    center_x, center_y = self.image_to_canvas(
                        ((u0 + u1) / 2) * image.width,
                        ((v0 + v1) / 2) * image.height,
                    )
                    visible_w = (u1 - u0) * image.width * self.scale
                    visible_h = (v1 - v0) * image.height * self.scale
                    if min(visible_w, visible_h) >= 22 or selected:
                        sample = self.app.sample_patch_color(patch.index)
                        self.create_text(
                            center_x,
                            center_y,
                            text=f"P{patch.index:03d}",
                            fill=contrast_color(sample),
                            font=("Consolas", 8, "bold"),
                            tags=("patch_overlay",),
                        )

        if self.app.tool.get() in ("brush", "eraser"):
            self._draw_brush_cursor()

    def _draw_brush_cursor(self) -> None:
        try:
            x = self.winfo_pointerx() - self.winfo_rootx()
            y = self.winfo_pointery() - self.winfo_rooty()
        except tk.TclError:
            return
        radius = max(1.0, self.app.brush_size.get() * self.scale / 2)
        self.create_oval(
            x - radius,
            y - radius,
            x + radius,
            y + radius,
            outline="#ffffff",
            width=1,
            tags=("brush_cursor",),
        )
        self.create_oval(
            x - radius - 1,
            y - radius - 1,
            x + radius + 1,
            y + radius + 1,
            outline="#000000",
            width=1,
            tags=("brush_cursor",),
        )

    def _inside_image(self, ix: float, iy: float) -> bool:
        image = self.app.image
        return bool(image and 0 <= ix < image.width and 0 <= iy < image.height)

    def _left_press(self, event: tk.Event) -> None:
        self.focus_set()
        ix, iy = self.canvas_to_image(event.x, event.y)
        if not self._inside_image(ix, iy):
            return
        tool = self.app.tool.get()
        patch_index = None
        if self.app.model and self.app.image:
            patch_index = self.app.model.patch_at_uv(ix / self.app.image.width, iy / self.app.image.height)
        if tool in ("brush", "eraser"):
            if patch_index is not None and self.app.patch_only.get():
                self.app.set_selected_patch(patch_index)
            self.app.begin_edit()
            self._stroke_last = (ix, iy)
            self.app.paint_segment(ix, iy, ix, iy, erase=(tool == "eraser"))
            self.request_redraw()
        elif tool == "picker":
            if patch_index is not None:
                self.app.set_selected_patch(patch_index)
            self.app.pick_color(round(ix), round(iy))
        else:
            self._select_at(ix, iy)

    def _left_drag(self, event: tk.Event) -> None:
        if self._stroke_last is None:
            return
        ix, iy = self.canvas_to_image(event.x, event.y)
        image = self.app.image
        if image is None:
            return
        ix = clamp(ix, 0, image.width - 1)
        iy = clamp(iy, 0, image.height - 1)
        last_x, last_y = self._stroke_last
        self.app.paint_segment(last_x, last_y, ix, iy, erase=(self.app.tool.get() == "eraser"))
        self._stroke_last = (ix, iy)
        self.request_redraw()
        self.app.model_canvas.request_redraw()

    def _left_release(self, _event: tk.Event) -> None:
        if self._stroke_last is not None:
            self._stroke_last = None
            self.app.finish_edit()
            self.redraw()
            self.app.model_canvas.redraw()

    def _right_press(self, event: tk.Event) -> None:
        ix, iy = self.canvas_to_image(event.x, event.y)
        if self._inside_image(ix, iy):
            self._select_at(ix, iy)

    def _select_at(self, ix: float, iy: float) -> None:
        image = self.app.image
        model = self.app.model
        if image is None or model is None:
            return
        patch_index = model.patch_at_uv(ix / image.width, iy / image.height)
        if patch_index is not None:
            self.app.set_selected_patch(patch_index)

    def _pan_press(self, event: tk.Event) -> None:
        self._panning = True
        self._pan_start = (event.x, event.y)
        self._offset_start = (self.offset_x, self.offset_y)
        self.configure(cursor="fleur")

    def _pan_drag(self, event: tk.Event) -> None:
        if not self._panning:
            return
        self.offset_x = self._offset_start[0] + event.x - self._pan_start[0]
        self.offset_y = self._offset_start[1] + event.y - self._pan_start[1]
        self.fit_mode = False
        self.request_redraw()

    def _pan_release(self, _event: tk.Event) -> None:
        self._panning = False
        self.configure(cursor="crosshair")

    def _mouse_wheel(self, event: tk.Event) -> None:
        factor = 1.15 if event.delta > 0 else 1 / 1.15
        self.zoom(factor, event.x, event.y)

    def _linux_wheel(self, event: tk.Event, direction: int) -> None:
        factor = 1.15 if direction > 0 else 1 / 1.15
        self.zoom(factor, event.x, event.y)

    def _motion(self, event: tk.Event) -> None:
        self.delete("brush_cursor")
        ix, iy = self.canvas_to_image(event.x, event.y)
        if self._inside_image(ix, iy):
            patch_text = ""
            if self.app.model and self.app.image:
                patch_index = self.app.model.patch_at_uv(ix / self.app.image.width, iy / self.app.image.height)
                if patch_index is not None:
                    patch_text = f"  P{patch_index:03d}"
            self.app.status.set(f"Texture x={ix:.1f}, y={iy:.1f}{patch_text}")
        if self.app.tool.get() in ("brush", "eraser"):
            radius = max(1.0, self.app.brush_size.get() * self.scale / 2)
            self.create_oval(event.x - radius, event.y - radius, event.x + radius, event.y + radius,
                             outline="#000000", width=3, tags=("brush_cursor",))
            self.create_oval(event.x - radius, event.y - radius, event.x + radius, event.y + radius,
                             outline="#ffffff", width=1, tags=("brush_cursor",))


class ModelCanvas(tk.Canvas):
    """Projected model patch map that can also paint back into the baked atlas."""

    def __init__(self, master: tk.Misc, app: "PainterApp") -> None:
        super().__init__(master, background="#353535", highlightthickness=0, cursor="crosshair")
        self.app = app
        self._screen_polygons: dict[int, list[tuple[float, float]]] = {}
        self._redraw_job: str | None = None
        self._photo: ImageTk.PhotoImage | None = None
        self._stroke_last: tuple[int, float, float] | None = None
        self._editing = False
        self._stroke_changed = False

        self.bind("<Configure>", lambda _event: self.request_redraw())
        self.bind("<ButtonPress-1>", self._left_press)
        self.bind("<B1-Motion>", self._left_drag)
        self.bind("<ButtonRelease-1>", self._left_release)
        self.bind("<ButtonPress-3>", self._right_press)
        self.bind("<Motion>", self._motion)
        self.bind("<Leave>", lambda _event: self.delete("brush_cursor"))

    def request_redraw(self) -> None:
        if self._redraw_job is None:
            self._redraw_job = self.after(35, self.redraw)

    def _project(self, point: tuple[float, float, float]) -> tuple[float, float]:
        x, y, z = point
        view = self.app.projection.get()
        if view == "Front (X-Y)":
            return (x, y)
        if view == "Top (Z-X)":
            return (-z, x)
        return (-z, y)

    def _depth_key(self, patch: Patch) -> float:
        """Studio extension hook; default retains original v1.1 ordering."""
        return patch.centroid[0]

    def _patch_visible(self, patch: Patch) -> bool:
        side_filter = self.app.side_filter.get()
        if side_filter == "All":
            return True
        x = patch.centroid[0]
        if side_filter == "+X side":
            return x >= -0.25
        if side_filter == "-X side":
            return x <= 0.25
        return True

    @staticmethod
    def _polygon_size(points: list[tuple[float, float]]) -> float:
        if not points:
            return 0.0
        return min(
            max(point[0] for point in points) - min(point[0] for point in points),
            max(point[1] for point in points) - min(point[1] for point in points),
        )

    def _paste_texture_triangle(
        self,
        target: Image.Image,
        texture: Image.Image,
        destination: tuple[tuple[float, float], tuple[float, float], tuple[float, float]],
        source: tuple[tuple[float, float], tuple[float, float], tuple[float, float]],
    ) -> None:
        coefficients = affine_output_to_input(destination, source)
        if coefficients is None:
            return
        width, height = target.size
        min_x = max(0, math.floor(min(point[0] for point in destination)))
        min_y = max(0, math.floor(min(point[1] for point in destination)))
        max_x = min(width, math.ceil(max(point[0] for point in destination)))
        max_y = min(height, math.ceil(max(point[1] for point in destination)))
        if max_x <= min_x or max_y <= min_y:
            return

        a, b, c, d, e, f = coefficients
        local_coefficients = (
            a,
            b,
            c + a * min_x + b * min_y,
            d,
            e,
            f + d * min_x + e * min_y,
        )
        warped = texture.transform(
            (max_x - min_x, max_y - min_y),
            Image.Transform.AFFINE,
            local_coefficients,
            resample=Image.Resampling.BILINEAR,
        )
        mask = Image.new("L", warped.size, 0)
        local_triangle = [(x - min_x, y - min_y) for x, y in destination]
        ImageDraw.Draw(mask).polygon(local_triangle, fill=255)
        target.paste(warped, (min_x, min_y), mask)

    def redraw(self) -> None:
        if self._redraw_job is not None:
            try:
                self.after_cancel(self._redraw_job)
            except tk.TclError:
                pass
            self._redraw_job = None
        self.delete("all")
        self._screen_polygons.clear()
        model = self.app.model
        if model is None:
            self.create_text(
                self.winfo_width() / 2,
                self.winfo_height() / 2,
                text="Model patch map",
                fill="#d0d0d0",
                font=("Segoe UI", 11),
            )
            return

        visible = [patch for patch in model.patches if self._patch_visible(patch)]
        projected_points = [self._project(point) for patch in visible for point in patch.positions]
        if not projected_points:
            return
        xs = [point[0] for point in projected_points]
        ys = [point[1] for point in projected_points]
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        span_x = max(1e-6, max_x - min_x)
        span_y = max(1e-6, max_y - min_y)
        width = max(1, self.winfo_width())
        height = max(1, self.winfo_height())
        scale = min((width - 30) / span_x, (height - 30) / span_y)
        off_x = (width - span_x * scale) / 2 - min_x * scale
        off_y = (height + span_y * scale) / 2 + min_y * scale

        # Back-to-front order provides a stable hit-testing preference.
        visible.sort(key=self._depth_key)
        polygons: list[tuple[Patch, list[tuple[float, float]]]] = []
        for patch in visible:
            polygon: list[tuple[float, float]] = []
            for point in patch.positions:
                px, py = self._project(point)
                polygon.append((off_x + px * scale, off_y - py * scale))
            self._screen_polygons[patch.index] = polygon
            polygons.append((patch, polygon))

        # Render the actual baked image onto the projected patch triangles. This
        # keeps model-view painting visible instead of showing only one sampled color.
        texture = self.app.image
        render = Image.new("RGB", (width, height), (53, 53, 53))
        for patch, polygon in polygons:
            if texture is not None and len(patch.uv_polygon) == len(polygon):
                source_points = [
                    (u * texture.width, v * texture.height)
                    for u, v in patch.uv_polygon
                ]
                for corner in range(1, len(polygon) - 1):
                    destination_triangle = (polygon[0], polygon[corner], polygon[corner + 1])
                    source_triangle = (
                        source_points[0],
                        source_points[corner],
                        source_points[corner + 1],
                    )
                    self._paste_texture_triangle(render, texture, destination_triangle, source_triangle)
            else:
                flat = [coordinate for point in polygon for coordinate in point]
                ImageDraw.Draw(render).polygon(flat, fill=self.app.sample_patch_color(patch.index))

        self._photo = ImageTk.PhotoImage(render)
        self.create_image(0, 0, anchor="nw", image=self._photo, tags=("model_texture",))

        for patch, polygon in polygons:
            selected = patch.index == self.app.selected_patch
            if self.app.show_outlines.get() or selected:
                flat = [coordinate for point in polygon for coordinate in point]
                self.create_polygon(
                    flat,
                    fill="",
                    outline="#ff3333" if selected else "#777777",
                    width=3 if selected else 1,
                    tags=("model_overlay",),
                )
            if self.app.show_labels.get() and (selected or self._polygon_size(polygon) >= 24):
                cx = sum(point[0] for point in polygon) / len(polygon)
                cy = sum(point[1] for point in polygon) / len(polygon)
                self.create_text(
                    cx,
                    cy,
                    text=f"P{patch.index:03d}",
                    fill=contrast_color(self.app.sample_patch_color(patch.index)),
                    font=("Consolas", 7, "bold"),
                    tags=("model_overlay",),
                )

    def _hit_patch(self, x: float, y: float) -> int | None:
        for patch_index, polygon in reversed(list(self._screen_polygons.items())):
            if point_in_polygon(x, y, polygon):
                return patch_index
        return None

    def _screen_to_texture(self, patch_index: int, x: float, y: float) -> tuple[float, float] | None:
        model = self.app.model
        image = self.app.image
        polygon = self._screen_polygons.get(patch_index)
        if model is None or image is None or polygon is None:
            return None
        patch = model.patches[patch_index]
        if len(polygon) != len(patch.uv_polygon) or len(polygon) < 3:
            return None

        for corner in range(1, len(polygon) - 1):
            screen_triangle = (polygon[0], polygon[corner], polygon[corner + 1])
            weights = triangle_weights((x, y), screen_triangle)
            if weights is None:
                continue
            uv_triangle = (
                patch.uv_polygon[0],
                patch.uv_polygon[corner],
                patch.uv_polygon[corner + 1],
            )
            u = sum(weight * uv[0] for weight, uv in zip(weights, uv_triangle))
            v = sum(weight * uv[1] for weight, uv in zip(weights, uv_triangle))
            return (
                clamp(u * image.width, 0, image.width - 1),
                clamp(v * image.height, 0, image.height - 1),
            )
        return None

    def _brush_radius_on_screen(self, patch_index: int) -> float:
        model = self.app.model
        image = self.app.image
        polygon = self._screen_polygons.get(patch_index)
        if model is None or image is None or polygon is None:
            return 5.0
        patch = model.patches[patch_index]
        ratios: list[float] = []
        for index in range(len(polygon)):
            next_index = (index + 1) % len(polygon)
            screen_length = math.dist(polygon[index], polygon[next_index])
            u0, v0 = patch.uv_polygon[index]
            u1, v1 = patch.uv_polygon[next_index]
            texture_length = math.hypot((u1 - u0) * image.width, (v1 - v0) * image.height)
            if texture_length > 1e-5:
                ratios.append(screen_length / texture_length)
        ratio = sum(ratios) / len(ratios) if ratios else 0.25
        return clamp(self.app.brush_size.get() * ratio / 2, 2.0, 100.0)

    def _left_press(self, event: tk.Event) -> None:
        self.focus_set()
        patch_index = self._hit_patch(event.x, event.y)
        if patch_index is None:
            return
        tool = self.app.tool.get()
        if tool == "select":
            self.app.set_selected_patch(patch_index)
            return

        mapped = self._screen_to_texture(patch_index, event.x, event.y)
        if mapped is None:
            return
        tx, ty = mapped
        if tool == "picker":
            self.app.set_selected_patch(patch_index)
            self.app.pick_color(round(tx), round(ty))
            return
        if tool not in ("brush", "eraser"):
            return

        # A paint stroke starts on the clicked patch. In patch-only mode this
        # makes the restriction explicit and prevents an apparently dead stroke.
        self.app.set_selected_patch(patch_index)
        self.app.begin_edit()
        self._editing = True
        self._stroke_changed = True
        self._stroke_last = (patch_index, tx, ty)
        self.app.paint_segment(
            tx,
            ty,
            tx,
            ty,
            erase=(tool == "eraser"),
            clip_patch_index=patch_index,
        )
        self.app.texture_canvas.request_redraw()
        self.request_redraw()

    def _left_drag(self, event: tk.Event) -> None:
        if not self._editing:
            return
        patch_index = self._hit_patch(event.x, event.y)
        if patch_index is None:
            self._stroke_last = None
            return
        if self.app.patch_only.get() and patch_index != self.app.selected_patch:
            self._stroke_last = None
            return
        mapped = self._screen_to_texture(patch_index, event.x, event.y)
        if mapped is None:
            self._stroke_last = None
            return
        tx, ty = mapped
        previous = self._stroke_last
        if previous is not None and previous[0] == patch_index:
            x0, y0 = previous[1], previous[2]
        else:
            x0, y0 = tx, ty
        self.app.paint_segment(
            x0,
            y0,
            tx,
            ty,
            erase=(self.app.tool.get() == "eraser"),
            clip_patch_index=patch_index,
        )
        self._stroke_last = (patch_index, tx, ty)
        self._stroke_changed = True
        self.app.texture_canvas.request_redraw()
        self.request_redraw()

    def _left_release(self, _event: tk.Event) -> None:
        if not self._editing:
            return
        self._editing = False
        self._stroke_last = None
        if self._stroke_changed:
            self.app.finish_edit()
        self._stroke_changed = False
        self.app.texture_canvas.redraw()
        self.redraw()

    def _right_press(self, event: tk.Event) -> None:
        patch_index = self._hit_patch(event.x, event.y)
        if patch_index is not None:
            self.app.set_selected_patch(patch_index)

    def _motion(self, event: tk.Event) -> None:
        self.delete("brush_cursor")
        patch_index = self._hit_patch(event.x, event.y)
        if patch_index is None:
            return
        mapped = self._screen_to_texture(patch_index, event.x, event.y)
        if mapped is None:
            self.app.status.set(f"Model patch P{patch_index:03d}")
        else:
            self.app.status.set(
                f"Model patch P{patch_index:03d}  →  texture x={mapped[0]:.1f}, y={mapped[1]:.1f}"
            )
        if self.app.tool.get() in ("brush", "eraser"):
            radius = self._brush_radius_on_screen(patch_index)
            self.create_oval(
                event.x - radius - 1,
                event.y - radius - 1,
                event.x + radius + 1,
                event.y + radius + 1,
                outline="#000000",
                width=3,
                tags=("brush_cursor",),
            )
            self.create_oval(
                event.x - radius,
                event.y - radius,
                event.x + radius,
                event.y + radius,
                outline="#ffffff",
                width=1,
                tags=("brush_cursor",),
            )


class PainterApp(tk.Tk):
    def __init__(self, initial_model: Path | None = None, initial_texture: Path | None = None) -> None:
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1450x860")
        self.minsize(1050, 650)
        self.protocol("WM_DELETE_WINDOW", self.close)

        self.model: BakeModel | None = None
        self.model_path: Path | None = None
        self.texture_path: Path | None = None
        self.image: Image.Image | None = None
        self.erase_baseline: Image.Image | None = None
        self.selected_patch: int | None = None
        self.patch_masks: dict[tuple[int, tuple[int, int]], Image.Image] = {}
        self.undo_stack: list[Image.Image] = []
        self.redo_stack: list[Image.Image] = []
        self.dirty = False

        self.tool = tk.StringVar(value="select")
        self.brush_size = tk.IntVar(value=36)
        self.opacity = tk.IntVar(value=100)
        self.paint_color = tk.StringVar(value="#7020a0")
        self.patch_only = tk.BooleanVar(value=True)
        self.show_outlines = tk.BooleanVar(value=True)
        self.show_labels = tk.BooleanVar(value=False)
        self.projection = tk.StringVar(value="Side (Z-Y)")
        self.side_filter = tk.StringVar(value="+X side")
        self.channel = tk.StringVar(value="")
        self.filter_text = tk.StringVar(value="")
        self.status = tk.StringVar(value="Ready")
        self.patch_info = tk.StringVar(value="No patch selected")

        self._build_menu()
        self._build_ui()
        self._bind_shortcuts()
        self._update_color_button()
        self._update_title()

        if initial_model and initial_model.exists():
            self.load_model(initial_model, initial_texture)
        else:
            sample_model = Path(__file__).resolve().parent / "sample" / "simple_quadraped_quickdecal.mdl"
            if sample_model.exists():
                self.load_model(sample_model, initial_texture)

    # ---------- UI construction ----------
    def _build_menu(self) -> None:
        menu = tk.Menu(self)
        file_menu = tk.Menu(menu, tearoff=False)
        file_menu.add_command(label="Open Model…", accelerator="Ctrl+O", command=self.open_model_dialog)
        file_menu.add_command(label="Open Texture…", command=self.open_texture_dialog)
        file_menu.add_separator()
        file_menu.add_command(label="Save Texture", accelerator="Ctrl+S", command=self.save_texture)
        file_menu.add_command(label="Save Texture As…", accelerator="Ctrl+Shift+S", command=self.save_texture_as)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.close)
        menu.add_cascade(label="File", menu=file_menu)

        edit_menu = tk.Menu(menu, tearoff=False)
        edit_menu.add_command(label="Undo", accelerator="Ctrl+Z", command=self.undo)
        edit_menu.add_command(label="Redo", accelerator="Ctrl+Y", command=self.redo)
        edit_menu.add_separator()
        edit_menu.add_command(label="Fill Selected Patch", accelerator="F", command=self.fill_selected_patch)
        edit_menu.add_command(label="Restore Selected Patch", command=self.restore_selected_patch)
        edit_menu.add_command(label="Set Current Image as Erase Baseline", command=self.set_erase_baseline)
        menu.add_cascade(label="Edit", menu=edit_menu)

        view_menu = tk.Menu(menu, tearoff=False)
        view_menu.add_checkbutton(label="Patch Outlines", variable=self.show_outlines, command=self.refresh_views)
        view_menu.add_checkbutton(label="Patch Numbers", variable=self.show_labels, command=self.refresh_views)
        view_menu.add_separator()
        view_menu.add_command(label="Fit Texture", accelerator="0", command=lambda: self.texture_canvas.fit_image())
        view_menu.add_command(label="Actual Pixels", accelerator="1", command=lambda: self.texture_canvas.native_size())
        menu.add_cascade(label="View", menu=view_menu)

        help_menu = tk.Menu(menu, tearoff=False)
        help_menu.add_command(label="Quick Help", command=self.show_help)
        help_menu.add_command(label="About", command=self.show_about)
        menu.add_cascade(label="Help", menu=help_menu)
        self.config(menu=menu)

    def _build_ui(self) -> None:
        toolbar = ttk.Frame(self, padding=(6, 5))
        toolbar.pack(fill="x")

        for text, value in (("Select", "select"), ("Brush", "brush"), ("Eraser", "eraser"), ("Picker", "picker")):
            ttk.Radiobutton(
                toolbar,
                text=text,
                value=value,
                variable=self.tool,
                command=self._tool_changed,
            ).pack(side="left", padx=2)

        ttk.Separator(toolbar, orient="vertical").pack(side="left", fill="y", padx=7)
        ttk.Label(toolbar, text="Size").pack(side="left")
        ttk.Scale(toolbar, from_=1, to=200, variable=self.brush_size, orient="horizontal", length=135).pack(side="left", padx=(3, 8))
        ttk.Label(toolbar, text="Opacity").pack(side="left")
        ttk.Scale(toolbar, from_=1, to=100, variable=self.opacity, orient="horizontal", length=110).pack(side="left", padx=(3, 8))

        self.color_button = tk.Button(toolbar, text="Color", width=8, command=self.choose_color, relief="raised")
        self.color_button.pack(side="left", padx=3)
        ttk.Button(toolbar, text="Fill Patch", command=self.fill_selected_patch).pack(side="left", padx=3)
        ttk.Checkbutton(toolbar, text="Selected patch only", variable=self.patch_only).pack(side="left", padx=8)

        ttk.Separator(toolbar, orient="vertical").pack(side="left", fill="y", padx=7)
        ttk.Label(toolbar, text="Channel").pack(side="left")
        self.channel_combo = ttk.Combobox(toolbar, textvariable=self.channel, state="readonly", width=30)
        self.channel_combo.pack(side="left", padx=4)
        self.channel_combo.bind("<<ComboboxSelected>>", self._channel_changed)

        main = ttk.Panedwindow(self, orient="horizontal")
        main.pack(fill="both", expand=True)

        atlas_frame = ttk.Labelframe(main, text="Baked texture — paint or select patches directly; right-click always selects")
        self.texture_canvas = TextureCanvas(atlas_frame, self)
        self.texture_canvas.pack(fill="both", expand=True)
        main.add(atlas_frame, weight=3)

        right = ttk.Panedwindow(main, orient="vertical")
        main.add(right, weight=2)

        model_frame = ttk.Labelframe(right, text="Projected model — paint/select directly; right-click always selects")
        controls = ttk.Frame(model_frame, padding=(4, 3))
        controls.pack(fill="x")
        ttk.Label(controls, text="Projection").pack(side="left")
        projection_combo = ttk.Combobox(
            controls,
            textvariable=self.projection,
            state="readonly",
            values=("Side (Z-Y)", "Front (X-Y)", "Top (Z-X)"),
            width=14,
        )
        projection_combo.pack(side="left", padx=4)
        projection_combo.bind("<<ComboboxSelected>>", lambda _event: self.model_canvas.redraw())
        ttk.Label(controls, text="Visible").pack(side="left", padx=(10, 0))
        side_combo = ttk.Combobox(
            controls,
            textvariable=self.side_filter,
            state="readonly",
            values=("+X side", "-X side", "All"),
            width=10,
        )
        side_combo.pack(side="left", padx=4)
        side_combo.bind("<<ComboboxSelected>>", lambda _event: self.model_canvas.redraw())
        ttk.Checkbutton(controls, text="Numbers", variable=self.show_labels, command=self.refresh_views).pack(side="right")
        ttk.Checkbutton(controls, text="Outlines", variable=self.show_outlines, command=self.refresh_views).pack(side="right", padx=5)

        self.model_canvas = ModelCanvas(model_frame, self)
        self.model_canvas.pack(fill="both", expand=True)
        right.add(model_frame, weight=3)

        inspector = ttk.Labelframe(right, text="Patch inspector")
        filter_frame = ttk.Frame(inspector, padding=(4, 4))
        filter_frame.pack(fill="x")
        ttk.Label(filter_frame, text="Filter").pack(side="left")
        filter_entry = ttk.Entry(filter_frame, textvariable=self.filter_text)
        filter_entry.pack(side="left", fill="x", expand=True, padx=4)
        self.filter_text.trace_add("write", lambda *_args: self.populate_patch_list())

        tree_frame = ttk.Frame(inspector)
        tree_frame.pack(fill="both", expand=True)
        columns = ("patch", "topology", "groups", "side")
        self.patch_tree = ttk.Treeview(tree_frame, columns=columns, show="headings", selectmode="browse", height=8)
        self.patch_tree.heading("patch", text="Patch")
        self.patch_tree.heading("topology", text="Pts")
        self.patch_tree.heading("groups", text="Named group(s)")
        self.patch_tree.heading("side", text="Side")
        self.patch_tree.column("patch", width=65, stretch=False)
        self.patch_tree.column("topology", width=45, stretch=False, anchor="center")
        self.patch_tree.column("groups", width=220)
        self.patch_tree.column("side", width=60, stretch=False, anchor="center")
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.patch_tree.yview)
        self.patch_tree.configure(yscrollcommand=scrollbar.set)
        self.patch_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.patch_tree.bind("<<TreeviewSelect>>", self._tree_selected)

        ttk.Label(inspector, textvariable=self.patch_info, padding=(5, 4), justify="left").pack(fill="x")
        right.add(inspector, weight=2)

        status = ttk.Label(self, textvariable=self.status, relief="sunken", anchor="w", padding=(5, 2))
        status.pack(fill="x")

    def _bind_shortcuts(self) -> None:
        self.bind_all("<Control-o>", lambda _event: self.open_model_dialog())
        self.bind_all("<Control-s>", lambda _event: self.save_texture())
        self.bind_all("<Control-Shift-S>", lambda _event: self.save_texture_as())
        self.bind_all("<Control-z>", lambda _event: self.undo())
        self.bind_all("<Control-y>", lambda _event: self.redo())
        self.bind_all("<KeyPress-f>", lambda _event: self.fill_selected_patch())
        self.bind_all("<KeyPress-0>", lambda _event: self.texture_canvas.fit_image())
        self.bind_all("<KeyPress-1>", lambda _event: self.texture_canvas.native_size())
        self.bind_all("<KeyPress-b>", lambda _event: self.tool.set("brush"))
        self.bind_all("<KeyPress-e>", lambda _event: self.tool.set("eraser"))
        self.bind_all("<KeyPress-p>", lambda _event: self.tool.set("picker"))
        self.bind_all("<KeyPress-v>", lambda _event: self.tool.set("select"))

    # ---------- document loading ----------
    def open_model_dialog(self) -> None:
        if not self.confirm_discard_changes():
            return
        filename = filedialog.askopenfilename(
            title="Open Animation:Master model",
            filetypes=(("Animation:Master model", "*.mdl"), ("All files", "*.*")),
        )
        if filename:
            self.load_model(Path(filename))

    def load_model(self, path: Path, preferred_texture: Path | None = None) -> None:
        try:
            model = parse_model(path)
        except (AMBakeError, OSError) as exc:
            messagebox.showerror(APP_NAME, str(exc), parent=self)
            return
        self.model = model
        self.model_path = model.path
        self.patch_masks.clear()
        self.selected_patch = None
        self.channel_combo["values"] = model.image_files

        texture = preferred_texture
        if texture is None:
            color_path = model.color_image_path()
            if color_path and color_path.exists():
                texture = color_path
            else:
                texture = next((candidate for candidate in model.referenced_image_paths() if candidate.exists()), None)
        if texture and texture.exists():
            self.load_texture(texture, keep_model=True)
        else:
            self.image = None
            self.texture_path = None
            self.channel.set(model.image_files[0] if model.image_files else "")
            messagebox.showwarning(
                APP_NAME,
                "The model was parsed, but none of its referenced baked images were found next to the model.\n\nUse File > Open Texture to choose one.",
                parent=self,
            )

        self.populate_patch_list()
        self.refresh_views()
        self.status.set(f"Loaded {model.path.name}: {len(model.patches)} patches")
        self._update_title()

    def open_texture_dialog(self) -> None:
        filename = filedialog.askopenfilename(
            title="Open baked texture",
            filetypes=(("PNG image", "*.png"), ("Image files", "*.png;*.jpg;*.jpeg;*.tif;*.tiff"), ("All files", "*.*")),
        )
        if filename:
            self.load_texture(Path(filename), keep_model=True)

    def load_texture(self, path: Path, keep_model: bool = True) -> None:
        try:
            image = Image.open(path).convert("RGB")
            image.load()
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"Could not open texture:\n{path}\n\n{exc}", parent=self)
            return
        self.image = image
        self.erase_baseline = image.copy()
        self.texture_path = path.resolve()
        self.undo_stack.clear()
        self.redo_stack.clear()
        self.dirty = False
        self.patch_masks.clear()
        self.channel.set(path.name)
        self.texture_canvas.after_idle(self.texture_canvas.fit_image)
        self.refresh_views()
        self._update_title()
        self.status.set(f"Loaded texture {path.name} ({image.width} × {image.height})")

    def _channel_changed(self, _event: tk.Event) -> None:
        if self.model is None or not self.channel.get():
            return
        candidate = self.model.path.parent / self.channel.get()
        if candidate.exists():
            if self.confirm_discard_changes():
                self.load_texture(candidate)
        else:
            messagebox.showwarning(APP_NAME, f"Referenced channel image does not exist:\n{candidate}", parent=self)
            if self.texture_path:
                self.channel.set(self.texture_path.name)

    # ---------- painting ----------
    def begin_edit(self) -> None:
        if self.image is None:
            return
        self.undo_stack.append(self.image.copy())
        if len(self.undo_stack) > MAX_UNDO:
            self.undo_stack.pop(0)
        self.redo_stack.clear()

    def finish_edit(self) -> None:
        self.dirty = True
        self._update_title()

    def _stroke_mask(
        self,
        x0: float,
        y0: float,
        x1: float,
        y1: float,
        clip_patch_index: int | None = None,
    ) -> Image.Image | None:
        if self.image is None:
            return None
        alpha = round(255 * clamp(self.opacity.get() / 100.0, 0.01, 1.0))
        width = max(1, round(self.brush_size.get()))
        mask = Image.new("L", self.image.size, 0)
        draw = ImageDraw.Draw(mask)
        draw.line((round(x0), round(y0), round(x1), round(y1)), fill=alpha, width=width)
        radius = width / 2
        for x, y in ((x0, y0), (x1, y1)):
            draw.ellipse((round(x - radius), round(y - radius), round(x + radius), round(y + radius)), fill=alpha)

        restricted_patch = clip_patch_index
        if restricted_patch is None and self.patch_only.get() and self.selected_patch is not None:
            restricted_patch = self.selected_patch
        if restricted_patch is not None and self.model is not None:
            patch_mask = self.get_patch_mask(restricted_patch)
            mask = ImageChops.multiply(mask, patch_mask)
        return mask

    def paint_segment(
        self,
        x0: float,
        y0: float,
        x1: float,
        y1: float,
        erase: bool = False,
        clip_patch_index: int | None = None,
    ) -> None:
        if self.image is None:
            return
        mask = self._stroke_mask(x0, y0, x1, y1, clip_patch_index=clip_patch_index)
        if mask is None:
            return
        if erase:
            source = self.erase_baseline
            if source is None or source.size != self.image.size:
                return
        else:
            source = Image.new("RGB", self.image.size, hex_to_rgb(self.paint_color.get()))
        self.image.paste(source, (0, 0), mask)
        self.dirty = True

    def fill_selected_patch(self) -> None:
        if self.image is None or self.model is None or self.selected_patch is None:
            self.status.set("Select a patch before using Fill Patch.")
            return
        self.begin_edit()
        mask = self.get_patch_mask(self.selected_patch)
        if self.opacity.get() < 100:
            alpha = round(255 * self.opacity.get() / 100)
            mask = mask.point(lambda value: value * alpha // 255)
        layer = Image.new("RGB", self.image.size, hex_to_rgb(self.paint_color.get()))
        self.image.paste(layer, (0, 0), mask)
        self.finish_edit()
        self.refresh_views()
        self.status.set(f"Filled P{self.selected_patch:03d}")

    def restore_selected_patch(self) -> None:
        if self.image is None or self.erase_baseline is None or self.model is None or self.selected_patch is None:
            return
        self.begin_edit()
        mask = self.get_patch_mask(self.selected_patch)
        self.image.paste(self.erase_baseline, (0, 0), mask)
        self.finish_edit()
        self.refresh_views()
        self.status.set(f"Restored P{self.selected_patch:03d} from the erase baseline")

    def get_patch_mask(self, patch_index: int) -> Image.Image:
        if self.image is None or self.model is None:
            raise RuntimeError("No model/image loaded")
        key = (patch_index, self.image.size)
        if key not in self.patch_masks:
            self.patch_masks[key] = self.model.patch_mask(patch_index, self.image.size)
        return self.patch_masks[key]

    def set_erase_baseline(self) -> None:
        if self.image is None:
            return
        self.erase_baseline = self.image.copy()
        self.status.set("Current image set as the eraser/restore baseline")

    def pick_color(self, x: int, y: int) -> None:
        if self.image is None:
            return
        x = max(0, min(self.image.width - 1, x))
        y = max(0, min(self.image.height - 1, y))
        self.paint_color.set(rgb_to_hex(self.image.getpixel((x, y))))
        self._update_color_button()
        self.status.set(f"Picked {self.paint_color.get()} at {x}, {y}")

    def choose_color(self) -> None:
        result = colorchooser.askcolor(color=self.paint_color.get(), parent=self, title="Choose paint color")
        if result and result[1]:
            self.paint_color.set(result[1])
            self._update_color_button()

    def _update_color_button(self) -> None:
        color = self.paint_color.get()
        try:
            foreground = contrast_color(hex_to_rgb(color))
        except ValueError:
            foreground = "#ffffff"
        self.color_button.configure(background=color, activebackground=color, foreground=foreground, activeforeground=foreground)

    # ---------- patch selection/inspection ----------
    def set_selected_patch(self, patch_index: int) -> None:
        if self.model is None or not 0 <= patch_index < len(self.model.patches):
            return
        self.selected_patch = patch_index
        patch = self.model.patches[patch_index]
        cx, cy, cz = patch.centroid
        groups = ", ".join(patch.groups) if patch.groups else "(none)"
        u0, v0, u1, v1 = patch.uv_bounds
        self.patch_info.set(
            f"P{patch.index:03d}   {patch.topology}-point patch   Groups: {groups}\n"
            f"Centroid: X {cx:.3f}, Y {cy:.3f}, Z {cz:.3f}   UV: {u0:.5f}, {v0:.5f} — {u1:.5f}, {v1:.5f}"
        )
        iid = f"patch-{patch_index}"
        if self.patch_tree.exists(iid):
            self.patch_tree.selection_set(iid)
            self.patch_tree.see(iid)
        self.refresh_views()
        self.status.set(f"Selected P{patch_index:03d}")

    def populate_patch_list(self) -> None:
        self.patch_tree.delete(*self.patch_tree.get_children())
        if self.model is None:
            return
        needle = self.filter_text.get().strip().lower()
        for patch in self.model.patches:
            groups = ", ".join(patch.groups) if patch.groups else "(none)"
            side = "+X" if patch.centroid[0] > 0.25 else "-X" if patch.centroid[0] < -0.25 else "center"
            haystack = f"p{patch.index:03d} {patch.index} {patch.topology} {groups} {side}".lower()
            if needle and needle not in haystack:
                continue
            self.patch_tree.insert(
                "",
                "end",
                iid=f"patch-{patch.index}",
                values=(f"P{patch.index:03d}", patch.topology, groups, side),
            )

    def _tree_selected(self, _event: tk.Event) -> None:
        selected = self.patch_tree.selection()
        if not selected:
            return
        try:
            patch_index = int(selected[0].split("-", 1)[1])
        except (ValueError, IndexError):
            return
        if patch_index != self.selected_patch:
            self.set_selected_patch(patch_index)

    def sample_patch_color(self, patch_index: int) -> tuple[int, int, int]:
        if self.image is None or self.model is None or not 0 <= patch_index < len(self.model.patches):
            return (128, 128, 128)
        patch = self.model.patches[patch_index]
        u0, v0, u1, v1 = patch.uv_bounds
        x = max(0, min(self.image.width - 1, round((u0 + u1) * 0.5 * self.image.width)))
        y = max(0, min(self.image.height - 1, round((v0 + v1) * 0.5 * self.image.height)))
        return self.image.getpixel((x, y))

    # ---------- undo/save ----------
    def undo(self) -> None:
        if self.image is None or not self.undo_stack:
            self.status.set("Nothing to undo")
            return
        self.redo_stack.append(self.image.copy())
        self.image = self.undo_stack.pop()
        self.dirty = True
        self.refresh_views()
        self._update_title()
        self.status.set("Undo")

    def redo(self) -> None:
        if self.image is None or not self.redo_stack:
            self.status.set("Nothing to redo")
            return
        self.undo_stack.append(self.image.copy())
        self.image = self.redo_stack.pop()
        self.dirty = True
        self.refresh_views()
        self._update_title()
        self.status.set("Redo")

    def save_texture(self) -> bool:
        if self.image is None:
            return False
        if self.texture_path is None:
            return self.save_texture_as()
        try:
            self.image.save(self.texture_path)
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"Could not save texture:\n{self.texture_path}\n\n{exc}", parent=self)
            return False
        self.dirty = False
        self._update_title()
        self.status.set(f"Saved {self.texture_path}")
        return True

    def save_texture_as(self) -> bool:
        if self.image is None:
            return False
        initial = self.texture_path.name if self.texture_path else "painted_baked_texture.png"
        filename = filedialog.asksaveasfilename(
            title="Save baked texture",
            defaultextension=".png",
            initialfile=initial,
            filetypes=(("PNG image", "*.png"), ("TIFF image", "*.tif;*.tiff"), ("All files", "*.*")),
        )
        if not filename:
            return False
        self.texture_path = Path(filename).resolve()
        return self.save_texture()

    def confirm_discard_changes(self) -> bool:
        if not self.dirty:
            return True
        choice = messagebox.askyesnocancel(
            APP_NAME,
            "The texture has unsaved changes. Save before continuing?",
            parent=self,
        )
        if choice is None:
            return False
        if choice:
            return self.save_texture()
        return True

    def close(self) -> None:
        if self.confirm_discard_changes():
            self.destroy()

    # ---------- general ----------
    def refresh_views(self) -> None:
        self.texture_canvas.redraw()
        self.model_canvas.redraw()

    def _tool_changed(self) -> None:
        self.texture_canvas.configure(cursor="crosshair")
        self.model_canvas.configure(cursor="crosshair")
        self.texture_canvas.request_redraw()
        self.model_canvas.request_redraw()

    def _update_title(self) -> None:
        model = self.model_path.name if self.model_path else "No model"
        texture = self.texture_path.name if self.texture_path else "No texture"
        dirty = " *" if self.dirty else ""
        self.title(f"{APP_NAME} {APP_VERSION} — {model} — {texture}{dirty}")

    def show_help(self) -> None:
        messagebox.showinfo(
            "QuickDecal Painter Help",
            "1. Open an A:M model containing a BakedStamp. The referenced color image is loaded automatically when it is beside the model.\n\n"
            "2. Select, paint, erase, or pick color directly in either the baked texture or the projected model view. The same patch is highlighted in every view. Right-click always selects.\n\n"
            "3. Model-view strokes are converted back into the selected patch's baked UV cell. Each dab is clipped to that patch so neighboring packed cells are protected.\n\n"
            "4. With 'Selected patch only' enabled, a model stroke stays on its starting patch. Turn it off to continue across visible model patches. Fill Patch recolors the complete selected cell.\n\n"
            "5. Middle-drag pans the texture and the mouse wheel zooms it.\n\n"
            "Shortcuts: V select, B brush, E eraser, P picker, F fill patch, Ctrl+Z undo, Ctrl+Y redo, 0 fit, 1 actual pixels.",
            parent=self,
        )

    def show_about(self) -> None:
        messagebox.showinfo(
            "About QuickDecal Painter",
            f"QuickDecal Painter {APP_VERSION}\n\nA small Python/Tkinter paint utility for Animation:Master Bake Surfaces textures.\n"
            "It reads the model's patch list and BakedStamp UV layout so users can paint either the atlas or a projected, texture-mapped model view.",
            parent=self,
        )


def self_test(model_path: Path, texture_path: Path | None) -> int:
    model = parse_model(model_path)
    print(f"Model: {model.path}")
    print(f"Patches: {len(model.patches)}")
    print(f"Control-point records: {len(model.control_points)}")
    print(f"Named groups: {len(model.groups)}")
    print(f"Referenced images: {len(model.image_files)}")
    if texture_path:
        image = Image.open(texture_path)
        print(f"Texture: {image.size[0]} x {image.size[1]}")
        mask = model.patch_mask(0, image.size)
        print(f"Patch P000 mask pixels: {mask.getbbox()}")
    assert len(model.patches) > 0
    assert all(len(patch.uv_polygon) in (3, 4, 5) for patch in model.patches)
    print("Self-test passed.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Paint Animation:Master Bake Surfaces texture atlases.")
    parser.add_argument("model", nargs="?", type=Path, help="A:M .mdl file containing BakedStamp data")
    parser.add_argument("texture", nargs="?", type=Path, help="optional baked texture image")
    parser.add_argument("--self-test", action="store_true", help="parse the inputs and exit without opening the GUI")
    args = parser.parse_args()

    base = Path(__file__).resolve().parent
    model_path = args.model
    texture_path = args.texture
    if model_path is None:
        sample_model = base / "sample" / "simple_quadraped_quickdecal.mdl"
        if sample_model.exists():
            model_path = sample_model
    if texture_path is None:
        sample_texture = base / "sample" / "bs_simple_quadraped_quickdecal_color.png"
        if sample_texture.exists() and (args.model is None or model_path == base / "sample" / "simple_quadraped_quickdecal.mdl"):
            texture_path = sample_texture

    if args.self_test:
        if model_path is None:
            parser.error("--self-test requires a model path or the bundled sample model")
        return self_test(model_path, texture_path)

    app = PainterApp(model_path, texture_path)
    app.mainloop()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AMBakeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1)

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re
from typing import Iterable

from PIL import Image, ImageDraw


class AMBakeError(RuntimeError):
    """Raised when an Animation:Master baked-surface model cannot be parsed."""


@dataclass(slots=True)
class ControlPoint:
    cp_id: int
    attached: bool
    target: int | None = None
    position: tuple[float, float, float] | None = None


@dataclass(slots=True)
class Patch:
    index: int
    flags: int
    cp_ids: list[int]
    resolved_ids: list[int]
    positions: list[tuple[float, float, float]]
    topology: int
    uv_samples: list[tuple[float, float]] = field(default_factory=list)
    uv_polygon: list[tuple[float, float]] = field(default_factory=list)
    stamp_ids: list[int] = field(default_factory=list)
    groups: list[str] = field(default_factory=list)

    @property
    def centroid(self) -> tuple[float, float, float]:
        if not self.positions:
            return (0.0, 0.0, 0.0)
        count = float(len(self.positions))
        return tuple(sum(point[axis] for point in self.positions) / count for axis in range(3))  # type: ignore[return-value]

    @property
    def uv_bounds(self) -> tuple[float, float, float, float]:
        if not self.uv_polygon:
            return (0.0, 0.0, 0.0, 0.0)
        us = [point[0] for point in self.uv_polygon]
        vs = [point[1] for point in self.uv_polygon]
        return (min(us), min(vs), max(us), max(vs))

    def pixel_polygon(self, width: int, height: int) -> list[tuple[int, int]]:
        return [
            (
                max(0, min(width - 1, round(u * width))),
                max(0, min(height - 1, round(v * height))),
            )
            for u, v in self.uv_polygon
        ]


@dataclass(slots=True)
class BakeModel:
    path: Path
    control_points: dict[int, ControlPoint]
    patches: list[Patch]
    groups: dict[str, set[int]]
    image_files: list[str]
    decal_name: str = ""
    stamp_name: str = ""

    def referenced_image_paths(self) -> list[Path]:
        return [self.path.parent / filename for filename in self.image_files]

    def color_image_path(self) -> Path | None:
        for filename in self.image_files:
            lower = filename.lower()
            if "_color." in lower or lower.endswith("color.png"):
                return self.path.parent / filename
        return self.path.parent / self.image_files[0] if self.image_files else None

    def patch_mask(self, patch_index: int, size: tuple[int, int]) -> Image.Image:
        width, height = size
        if not 0 <= patch_index < len(self.patches):
            raise IndexError(f"Patch index out of range: {patch_index}")
        patch = self.patches[patch_index]
        mask = Image.new("L", size, 0)
        polygon = patch.pixel_polygon(width, height)
        if len(polygon) >= 3:
            ImageDraw.Draw(mask).polygon(polygon, fill=255)
        return mask

    def patch_at_uv(self, u: float, v: float) -> int | None:
        # Reverse order makes the most recently drawn/visually top patch win.
        for patch in reversed(self.patches):
            if point_in_polygon(u, v, patch.uv_polygon):
                return patch.index
        return None


def point_in_polygon(x: float, y: float, polygon: Iterable[tuple[float, float]]) -> bool:
    points = list(polygon)
    if len(points) < 3:
        return False
    inside = False
    j = len(points) - 1
    for i, (xi, yi) in enumerate(points):
        xj, yj = points[j]
        crosses = (yi > y) != (yj > y)
        if crosses:
            denominator = yj - yi
            if abs(denominator) < 1e-15:
                denominator = 1e-15
            x_cross = (xj - xi) * (y - yi) / denominator + xi
            if x < x_cross:
                inside = not inside
        j = i
    return inside


def _section(text: str, start_tag: str, end_tag: str) -> str:
    start = text.find(start_tag)
    if start < 0:
        raise AMBakeError(f"Missing {start_tag}")
    end = text.find(end_tag, start)
    if end < 0:
        raise AMBakeError(f"Missing {end_tag}")
    return text[start + len(start_tag):end]


def parse_model(path: str | Path) -> BakeModel:
    model_path = Path(path).expanduser().resolve()
    try:
        text = model_path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        raise AMBakeError(f"Could not read model: {model_path}") from exc

    mesh = _section(text, "<MESH>", "</MESH>")
    mesh_before_patches = mesh.split("<PATCHES>", 1)[0]

    control_points: dict[int, ControlPoint] = {}
    for spline_match in re.finditer(r"<SPLINE>\s*(.*?)</SPLINE>", mesh_before_patches, re.S):
        for raw_line in spline_match.group(1).splitlines():
            fields = raw_line.strip().split()
            if len(fields) < 4 or not fields[0].lstrip("-").isdigit():
                continue
            try:
                attached = int(fields[1]) != 0
                cp_id = int(fields[2])
                if attached:
                    control_points[cp_id] = ControlPoint(
                        cp_id=cp_id,
                        attached=True,
                        target=int(fields[3]),
                    )
                else:
                    control_points[cp_id] = ControlPoint(
                        cp_id=cp_id,
                        attached=False,
                        position=(float(fields[3]), float(fields[4]), float(fields[5])),
                    )
            except (ValueError, IndexError):
                continue

    if not control_points:
        raise AMBakeError("No control-point records were found in the model mesh.")

    def root_id(cp_id: int) -> int:
        seen: set[int] = set()
        current = cp_id
        while current in control_points and control_points[current].attached:
            if current in seen:
                raise AMBakeError(f"Attached-CP cycle encountered at CP {current}")
            seen.add(current)
            target = control_points[current].target
            if target is None:
                break
            current = target
        return current

    def position(cp_id: int) -> tuple[float, float, float]:
        root = root_id(cp_id)
        cp = control_points.get(root)
        if cp is None or cp.position is None:
            raise AMBakeError(f"No geometric position found for CP {cp_id} (root {root})")
        return cp.position

    patch_text = _section(mesh, "<PATCHES>", "</PATCHES>")
    patches: list[Patch] = []
    for raw_line in patch_text.splitlines():
        fields = raw_line.strip().split()
        if len(fields) < 4 or not fields[0].lstrip("-").isdigit():
            continue
        try:
            flags = int(fields[0])
            cp_ids = [int(value) for value in fields[1:]]
            resolved = [root_id(value) for value in cp_ids]
            positions = [position(value) for value in cp_ids]
        except (ValueError, AMBakeError):
            continue
        patches.append(
            Patch(
                index=len(patches),
                flags=flags,
                cp_ids=cp_ids,
                resolved_ids=resolved,
                positions=positions,
                topology=len(set(resolved)),
            )
        )

    if not patches:
        raise AMBakeError("No patch records were found in the model mesh.")

    groups: dict[str, set[int]] = {}
    for group_match in re.finditer(r"<GROUP>\s*(.*?)</GROUP>", text, re.S):
        block = group_match.group(1)
        name_match = re.search(r"(?m)^Name=([^\r\n]+)", block)
        cps_match = re.search(r"<CPS>\s*(.*?)</CPS>", block, re.S)
        if not name_match or not cps_match:
            continue
        name = name_match.group(1).strip()
        ids = {
            root_id(int(value))
            for value in re.findall(r"(?m)^\s*(\d+)\s*$", cps_match.group(1))
        }
        groups[name] = ids

    decal_match = re.search(r"<DECAL>\s*Name=([^\r\n]+)", text, re.S)
    stamp_match = re.search(r"<STAMP>\s*Name=([^\r\n]+).*?<DATA>\s*(.*?)</DATA>", text, re.S)
    if not stamp_match:
        raise AMBakeError("No baked stamp data was found. Expected <STAMP> ... <DATA>.")

    stamp_name = stamp_match.group(1).strip()
    stamp_lines = [line.strip() for line in stamp_match.group(2).splitlines() if line.strip()]
    if len(stamp_lines) != len(patches):
        raise AMBakeError(
            f"Patch/stamp mismatch: {len(patches)} patches but {len(stamp_lines)} stamp records."
        )

    for patch, raw_line in zip(patches, stamp_lines):
        fields = raw_line.split()
        if len(fields) < 8:
            raise AMBakeError(f"Malformed stamp record for patch {patch.index}")
        try:
            # A:M's baked stamp records retain four identifier fields for both
            # regular and five-point patches. The remaining values are UVW triples.
            stamp_ids = [int(value) for value in fields[1:5]]
            numeric = [float(value) for value in fields[5:]]
        except ValueError as exc:
            raise AMBakeError(f"Malformed numeric data for patch {patch.index}") from exc
        if len(numeric) % 3:
            raise AMBakeError(f"Stamp UVW data is not a multiple of three for patch {patch.index}")
        uv_samples = [(numeric[i], numeric[i + 1]) for i in range(0, len(numeric), 3)]
        uv_polygon = uv_samples[::3]
        if len(uv_polygon) not in (3, 4, 5):
            raise AMBakeError(
                f"Unexpected baked patch outline ({len(uv_polygon)} corners) for patch {patch.index}"
            )
        patch.stamp_ids = stamp_ids
        patch.uv_samples = uv_samples
        patch.uv_polygon = uv_polygon
        root_set = set(patch.resolved_ids)
        patch.groups = [name for name, members in groups.items() if root_set <= members]

    image_files: list[str] = []
    for filename in re.findall(r"(?m)^FileName=([^\r\n]+)", text):
        clean = filename.strip().strip('"')
        if clean not in image_files:
            image_files.append(clean)

    return BakeModel(
        path=model_path,
        control_points=control_points,
        patches=patches,
        groups=groups,
        image_files=image_files,
        decal_name=decal_match.group(1).strip() if decal_match else "",
        stamp_name=stamp_name,
    )

﻿//BC  2/19/2004  \Bob110\Include\Vector.h
#pragma once

#include "StdAfx.h"

#include "Macros.h"
#include "Permutation.h"

#ifndef _ALGORITHM_
#include <algorithm>
#endif
#ifndef _IOSTREAM_
#include <iostream>
#endif

#ifndef FLT_EPSILON
#define FLT_EPSILON 1.192092896e-07F
#endif

class Matrix34;
class Matrix33;
class Vector2;
class Quaternion;

//#define DEFAULT_INITIALIZED 1
//size 12
class Vector {
public:
#ifdef DEFAULT_INITIALIZED
    float x{0.F};
    float y{0.F};
    float z{0.F};
#else
    float x;
    float y;
    float z;
#endif
    constexpr Vector() noexcept = default;// : x(INFINITY), y(INFINITY), z(INFINITY) {}
    constexpr Vector(const float f) noexcept : x(f), y(f), z(f) {}
    constexpr Vector(const float xi, const float yi, const float zi) noexcept : x(xi), y(yi), z(zi) {}

#pragma warning(suppress : 26447)
    Vector(const Vector other, const Permutation &perm) noexcept : x(other[perm[0]]), y(other[perm[1]]), z(other[perm[2]]) {}
    constexpr explicit Vector(Vector2 other) noexcept;

    constexpr float const &operator [](const int index) const noexcept {
        ASSERT(index < 3);
        return (&x)[index];
    }

    constexpr float &operator [](const int index) noexcept {
        ASSERT(index < 3);
        return (&x)[index];
    }

#ifdef DEBUG
    void SetX(const float value) noexcept {
        ASSERT(_finitef(value));
        x = value;
    }
    void SetY(const float value) noexcept {
        ASSERT(_finitef(value));
        y = value;
    }
    void SetZ(const float value) noexcept {
        ASSERT(_finitef(value));
        z = value;
    }
    void Set(const float xi, const float yi, const float zi) noexcept {
        ASSERT(_finitef(xi));
        ASSERT(_finitef(yi));
        ASSERT(_finitef(zi));
        x = xi;
        y = yi;
        z = zi;
    }
    void Set(const float value) noexcept {
        ASSERT(_finitef(value));
        x = y = z = value;
    }
    Vector &operator=(const float scale) noexcept {
        ASSERT(_finitef(scale));
        x = y = z = scale;
        return *this;
    }
    Vector &operator *=(const Vector other) noexcept {
        ASSERT(other.IsValid());
        x *= other.x;
        y *= other.y;
        z *= other.z;
        return *this;
    }
    Vector &operator *=(const float scale) noexcept {
        ASSERT(_finitef(scale));
        x *= scale;
        y *= scale;
        z *= scale;
        return *this;
    }
    Vector &operator /=(const Vector other) noexcept {
        ASSERT(other.IsValid());
        x /= other.x;
        y /= other.y;
        z /= other.z;
        return *this;
    }
    Vector &operator /=(const float scale) noexcept {
        ASSERT(_finitef(scale));
        ASSERT(scale != 0.F);
        x /= scale;
        y /= scale;
        z /= scale;
        return *this;
    }
    Vector &operator +=(const Vector other) noexcept {
        ASSERT(other.IsValid());
        x += other.x;
        y += other.y;
        z += other.z;
        return *this;
    }
    Vector &operator +=(const float scale) noexcept {
        x += scale;
        y += scale;
        z += scale;
        return *this;
    }
    Vector &operator -=(const Vector other) noexcept {
        ASSERT(other.IsValid());
        x -= other.x;
        y -= other.y;
        z -= other.z;
        return *this;
    }
    Vector &operator -=(const float scale) noexcept {
        ASSERT(_finitef(scale));
        x -= scale;
        y -= scale;
        z -= scale;
        return *this;
    }
    Vector &operator ^=(const Vector a) noexcept {
        ASSERT(!a.IsValid());
        return *this = Cross(a);
    }
    float operator |(const Vector other) const noexcept {        //same as Dot
        ASSERT(other.IsValid());
        return Dot(other);
    }
    Vector operator ^(const Vector other) const noexcept {        //same as Cross
        ASSERT(other.IsValid());
        return Cross(other);
    }
    void FixNormalizedVector() noexcept {
        ASSERT(IsValid());
        //fix when Normalize returns a Vector like this (0,1.000,1e-6)
        const Vector temp = Absolute();
        const bool x_one = temp.x > .9999f && temp.y < 1e-3F && temp.z < 1e-3F;
        if (x_one) {
            Set(SIGN_FLOAT(x), 0.F, 0.F);
        } else {
            const bool y_one = temp.y > .9999f && temp.x < 1e-3F && temp.z < 1e-3F;
            if (y_one) {
                Set(0.F, SIGN_FLOAT(y), 0.F);
            } else {
                const bool z_one = temp.z > .9999f && temp.x < 1e-3F && temp.y < 1e-3F;
                if (z_one) {
                    Set(0.F, 0.F, SIGN_FLOAT(z));
#ifdef _DEBUG
                } else {
                    //nothing todo
                    int a;
                    a = 0;
#endif
                }
            }
        }
    }
    Vector operator +(float scale) const noexcept;
    Vector operator -(float scale) const noexcept;
    Vector operator /(float scale) const noexcept;
    friend Vector operator *(const Vector &, float) noexcept;
    friend Vector operator *(float, const Vector &) noexcept;
    friend Vector operator *(const Vector &, double) noexcept;
    friend Vector operator *(double, const Vector &) noexcept;
#else
    constexpr void SetX(const float value) noexcept {
        x = value;
    }
    constexpr void SetY(const float value) noexcept {
        y = value;
    }
    constexpr void SetZ(const float value) noexcept {
        z = value;
    }
    constexpr void Set(const float xi, const float yi, const float zi) noexcept {
        x = xi;
        y = yi;
        z = zi;
    }
    constexpr void Set(const float value) noexcept {
        x = y = z = value;
    }
    constexpr Vector &operator=(const float scale) noexcept {
        x = y = z = scale;
        return *this;
    }
    constexpr Vector &operator *=(const Vector other) noexcept {
        x *= other.x;
        y *= other.y;
        z *= other.z;
        return *this;
    }
    constexpr Vector &operator *=(const float scale) noexcept {
        x *= scale;
        y *= scale;
        z *= scale;
        return *this;
    }
    constexpr Vector &operator /=(const Vector other) noexcept {
        x /= other.x;
        y /= other.y;
        z /= other.z;
        return *this;
    }
    constexpr Vector &operator /=(const float scale) noexcept {
        x /= scale;
        y /= scale;
        z /= scale;
        return *this;
    }
    constexpr Vector &operator +=(const Vector other) noexcept {
        x += other.x;
        y += other.y;
        z += other.z;
        return *this;
    }
    constexpr Vector &operator +=(const float scale) noexcept {
        x += scale;
        y += scale;
        z += scale;
        return *this;
    }
    constexpr Vector &operator -=(const Vector other) noexcept {
        x -= other.x;
        y -= other.y;
        z -= other.z;
        return *this;
    }
    constexpr Vector &operator -=(const float scale) noexcept {
        x -= scale;
        y -= scale;
        z -= scale;
        return *this;
    }
    Vector &operator ^=(const Vector a) noexcept {
        return *this = Cross(a);
    }
    constexpr float operator |(const Vector other) const noexcept {
        //same as Dot
        return Dot(other);
    }
    Vector operator ^(const Vector other) const noexcept {
        //same as Cross
        return Cross(other);
    }
    constexpr void FixNormalizedVector() noexcept {
        //fix when Normalize returns a Vector like this (0,1.000,1e-6)
        const Vector temp = Absolute();
        const bool x_one = temp.x > .9999f && temp.y < 1e-3F && temp.z < 1e-3F;
        if ( x_one) {
            Set(SIGN_FLOAT(x), 0.F, 0.F);
        } else {
            const bool y_one = temp.y > .9999f && temp.x < 1e-3F && temp.z < 1e-3F;
            if ( y_one) {
                Set(0.F, SIGN_FLOAT(y), 0.F);
            } else {
                const bool z_one = temp.z > .9999f && temp.x < 1e-3F && temp.y < 1e-3F;
                if ( z_one) {
                    Set(0.F, 0.F, SIGN_FLOAT(z));
                }
            }
        }
    }
    constexpr Vector operator +(float scale) const noexcept;
    constexpr Vector operator -(float scale) const noexcept;
    constexpr Vector operator /(float scale) const noexcept;
    constexpr friend Vector operator *(const Vector &, float) noexcept;
    constexpr friend Vector operator *(float, const Vector &) noexcept;
    constexpr friend Vector operator *(const Vector &, double) noexcept;
    constexpr friend Vector operator *(double, const Vector &) noexcept;

#endif

    constexpr void SetZero() noexcept {
        x = y = z = 0.F;
    }
    constexpr Vector &Negate() noexcept {
        x = -x;
        y = -y;
        z = -z;
        return *this;
    }
    Vector operator -() const noexcept {    //unary minus
        return Vector(*this).Negate();
    }
    friend bool operator ==(const Vector &li, const Vector &re) noexcept {
        return floatEQ(li.x, re.x) && floatEQ(li.y, re.y) && floatEQ(li.z, re.z);
    }
    friend bool operator !=(const Vector &li, const Vector &re) noexcept {
        return !operator==(li, re);
    }
    constexpr friend Vector operator +(const Vector li, const Vector re) noexcept {
        return Vector(li.x + re.x, li.y + re.y, li.z + re.z); //li += re;
    }
    constexpr friend Vector operator -(const Vector li, const Vector re) noexcept {
        return Vector(li.x - re.x, li.y - re.y, li.z - re.z); //li -= re;
    }
    constexpr friend Vector operator *(const Vector li, const Vector re) noexcept {
        return Vector(li.x * re.x, li.y * re.y, li.z * re.z); //li *= re;
    }
    constexpr friend Vector operator /(const Vector li, const Vector re) noexcept {
        return Vector(li.x / re.x, li.y / re.y, li.z / re.z); //li /= re;
    }
    [[nodiscard]] static float Distance(const Vector v1, const Vector v2) noexcept {
        return Vector(v2 - v1).Norm();
    }
    [[nodiscard]] Vector Hundredized() const noexcept {
        return Vector(*this).Hundredize();
    }
    Vector &Hundredize() noexcept {
        const float length_local = Norm();
        if (length_local != 0.F) {//[[likely]] {
            *this *= UNIT / length_local;
        }
        return *this;
    }
    [[nodiscard]] int MaxDim() const noexcept {
        const float fx = hash_math::abs(x), fy = hash_math::abs(y), fz = hash_math::abs(z);
        return fx > fy ? fx > fz ? 0 : 2 : fy > fz ? 1 : 2;
    }
    [[nodiscard]] int MinDim() const noexcept {
        const float fx = hash_math::abs(x), fy = hash_math::abs(y), fz = hash_math::abs(z);
        return fx < fy ? fx < fz ? 0 : 2 : fy < fz ? 1 : 2;
    }
    void RoundVector(const double modulo = 0.0001) noexcept {
        Round(x, modulo);
        Round(y, modulo);
        Round(z, modulo);
    }
    [[nodiscard]] bool IsLess(const float minvalue) const noexcept {
        if (hash_math::abs(x) > minvalue) {
            return false;
        }
        if (hash_math::abs(y) > minvalue) {
            return false;
        }
        if (hash_math::abs(z) > minvalue) {
            return false;
        }
        return true;
    }
    //if maxdifference == 0.F , the values must match
    [[nodiscard]] bool IsEqual(const Vector other, const float maxdifference = FLT_EPSILON) const noexcept {
        if (maxdifference == 0.F) {
            if (floatNEQ(x, other.x)) {
                return false;
            }
            if (floatNEQ(y, other.y)) {
                return false;
            }
            if (floatNEQ(z, other.y)) {
                return false;
            }
        } else {
            if (hash_math::abs(x - other.x) > maxdifference) {
                return false;
            }
            if (hash_math::abs(y - other.y) > maxdifference) {
                return false;
            }
            if (hash_math::abs(z - other.z) > maxdifference) {
                return false;
            }
        }
        return true;
    }
    [[nodiscard]] bool IsZero() const noexcept {
        return !IsNotZero();
    }
    [[nodiscard]] bool IsNotZero() const noexcept {
        if (x != 0.F) {
            return true;
        }
        if (y != 0.F) {
            return true;
        }
        if (z != 0.F) {
            return true;
        }
        return false;
    }
    void RoundToZero(const float min = 1e-10F) noexcept {
        //if values are smaller than min , set this values to 0
        if (hash_math::abs(x) < min) {
            x = 0.F;
        }
        if (hash_math::abs(y) < min) {
            y = 0.F;
        }
        if (hash_math::abs(z) < min) {
            z = 0.F;
        }
    }
    [[nodiscard]] bool InBound(const float minbound = 0.F, const float maxbound = 1.F) const noexcept {
        if (x < minbound || x > maxbound) {
            return false;
        }
        if (y < minbound || y > maxbound) {
            return false;
        }
        if (z < minbound || z > maxbound) {
            return false;
        }
        return true;
    }
    void FixZero() noexcept {
        //fix -0.0
        if (hash_math::abs(x) < 1e-10F) {
            x = 0.F;
        }
        if (hash_math::abs(y) < 1e-10F) {
            y = 0.F;
        }
        if (hash_math::abs(z) < 1e-10F) {
            z = 0.F;
        }
    }
    constexpr void Clamp(const float minvalue = 0.F, const float maxvalue = 1.F) noexcept {
        x = hash_clamp(x, minvalue, maxvalue);
        y = hash_clamp(y, minvalue, maxvalue);
        z = hash_clamp(y, minvalue, maxvalue);
    }
    void PushMinMax(Vector &minv, Vector &maxv) const noexcept {
        minv.x = std::min(x, minv.x);
        minv.y = std::min(y, minv.y);
        minv.z = std::min(z, minv.z);
        maxv.x = std::max(x, maxv.x);
        maxv.y = std::max(y, maxv.y);
        maxv.z = std::max(z, maxv.z);
    }
    friend void swap(Vector &lhs, Vector &rhs) noexcept {
        const Vector tmp(lhs);
        lhs = rhs;
        rhs = tmp;
    }

    friend float Dot(const Vector lhs, const Vector rhs) noexcept {
        return lhs.Dot(rhs);
    }

    friend Vector Cross(const Vector lhs, const Vector rhs) noexcept {
        return lhs.Cross(rhs);
    }

    constexpr friend bool IsBackward(const Vector a, const Vector b, const Vector c) noexcept {
        return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x) < 0.F;
    }

    constexpr friend Vector Min(const Vector left, const Vector right) noexcept {
        return Vector(left.x < right.x ? left.x : right.x, left.y < right.y ? left.y : right.y, left.z < right.z ? left.z : right.z);
    }

    constexpr friend Vector Max(const Vector left, const Vector right) noexcept {
        return Vector(left.x > right.x ? left.x : right.x, left.y > right.y ? left.y : right.y, left.z > right.z ? left.z : right.z);
    }

#ifdef _WIN64
    [[nodiscard]] bool IsValid() const noexcept {
        if (!_finitef(x)) {
            return false;
        }
        if (!_finitef(y)) {
            return false;
        }
        if (!_finitef(z)) {
            return false;
        }
        return true;
    }

    void Validate() noexcept {
        if (!_finitef(x)) {
            x = 0.F;
        }
        if (!_finitef(y)) {
            y = 0.F;
        }
        if (!_finitef(z)) {
            z = 0.F;
        }
    }
#else
    [[nodiscard]] bool IsValid() const noexcept {
        if (!isfinite(x)) {
            return false;
        }
        if (!isfinite(y)) {
            return false;
        }
        if (!isfinite(z)) {
            return false;
        }
        return true;
    }

    void Validate() noexcept {
        if (!isfinite(x)) {
            x = 0.F;
        }
        if (!isfinite(y)) {
            y = 0.F;
        }
        if (!isfinite(z)) {
            z = 0.F;
        }
    }
#endif

    HASH_INLINE Vector &operator *=(const Matrix34 &m) noexcept;
    HASH_INLINE Vector &operator *=(const Matrix33 &m) noexcept;
    HASH_INLINE Vector &operator *=(const Quaternion &q) noexcept;
    [[nodiscard]] HASH_INLINE float Norm() const noexcept;
    [[nodiscard]] HASH_INLINE float InvNorm() const noexcept;
    [[nodiscard]] HASH_INLINE Vector Normalized() const noexcept;
    [[nodiscard]] HASH_INLINE Vector FixedNormalized() const noexcept;
    HASH_INLINE float NormalizeLength() noexcept;
    HASH_INLINE Vector &Normalize() noexcept;
    HASH_INLINE Vector &FixedNormalize() noexcept;
    [[nodiscard]] constexpr float Dot(const Vector &other) const noexcept;
    [[nodiscard]] HASH_INLINE float Dot() const noexcept;
    [[nodiscard]] constexpr Vector Absolute() const noexcept;
    [[nodiscard]] constexpr Vector Reciprocal() const noexcept;
    HASH_INLINE void CrossSelf(const Vector &other) noexcept;
    [[nodiscard]] HASH_INLINE Vector Cross(const Vector &other) const noexcept;
    constexpr friend void PushMinMax(const Vector &p, Vector &minv, Vector &maxv) noexcept;

    friend std::ostream &operator<<(std::ostream &os, const Vector &val) {
        os << val.x << " " << val.y << " " << val.z;
        return os;
    }
};
#ifdef DEBUG
HASH_INLINE Vector operator *(const Vector &, float) noexcept;
HASH_INLINE Vector operator *(float, const Vector &) noexcept;

HASH_INLINE Vector operator *(const Vector &rhs, const float lhs) noexcept {
    ASSERT(_finitef(lhs));
    return Vector(rhs.x * lhs, rhs.y * lhs, rhs.z * lhs);
}

HASH_INLINE Vector operator *(const float lhs, const Vector &rhs) noexcept {
    ASSERT(_finitef(lhs));
    return Vector(rhs.x * lhs, rhs.y * lhs, rhs.z * lhs);
}

HASH_INLINE Vector operator *(const Vector &, double) noexcept;
HASH_INLINE Vector operator *(double, const Vector &) noexcept;

#pragma warning( push )
#pragma warning( disable : 4244 ) //conversion double float
HASH_INLINE Vector operator *(const Vector &rhs, const double lhs) noexcept {
    ASSERT(_finitef(lhs));
    return Vector(rhs.x * lhs, rhs.y * lhs, rhs.z * lhs); // NOLINT(clang-diagnostic-implicit-float-conversion)
}

HASH_INLINE Vector operator *(const double lhs, const Vector &rhs) noexcept {
    ASSERT(_finitef(lhs));
    return Vector(rhs.x * lhs, rhs.y * lhs, rhs.z * lhs); // NOLINT(clang-diagnostic-implicit-float-conversion)
}
#pragma warning( pop )
HASH_INLINE Vector Vector::operator -(const float scale) const noexcept {
    ASSERT(_finitef(scale));
    return Vector(x - scale, y - scale, z - scale);
}
HASH_INLINE Vector Vector::operator +(const float scale) const noexcept {
    ASSERT(_finitef(scale));
    return Vector(x + scale, y + scale, z + scale);
}
HASH_INLINE Vector Vector::operator /(const float scale) const noexcept {
    ASSERT(_finitef(scale));
    ASSERT(scale != 0.F);
    return Vector(x / scale, y / scale, z / scale);
}
HASH_INLINE void Vector::CrossSelf(const Vector &other) noexcept {
    ASSERT(IsValid());
    *this = Cross(other);
}
HASH_INLINE Vector Vector::Cross(const Vector &other) const noexcept {
        ASSERT(IsValid());
        return Vector(y * other.z - z * other.y, z * other.x - x * other.z, x * other.y - y * other.x);
}
HASH_INLINE float Vector::Dot() const noexcept { //Dot Self
    ASSERT(IsValid());
    return x * x + y * y + z * z;
}
#else
constexpr Vector operator *(const Vector &, float) noexcept;
constexpr Vector operator *(float, const Vector &) noexcept;

constexpr Vector operator *(const Vector &rhs, const float lhs) noexcept {
    return Vector(rhs.x * lhs, rhs.y * lhs, rhs.z * lhs);
}

constexpr Vector operator *(const float lhs, const Vector &rhs) noexcept {
    return Vector(rhs.x * lhs, rhs.y * lhs, rhs.z * lhs);
}

constexpr Vector operator *(const Vector &, double) noexcept;
constexpr Vector operator *(double, const Vector &) noexcept;

#pragma warning( push )
#pragma warning( disable : 4244 ) //conversion double float
constexpr Vector operator *(const Vector &rhs, const double lhs) noexcept {
    return Vector(rhs.x * lhs, rhs.y * lhs, rhs.z * lhs); // NOLINT(clang-diagnostic-implicit-float-conversion)
}

constexpr Vector operator *(const double lhs, const Vector &rhs) noexcept {
    return Vector(rhs.x * lhs, rhs.y * lhs, rhs.z * lhs); // NOLINT(clang-diagnostic-implicit-float-conversion)
}
#pragma warning( pop )
constexpr Vector Vector::operator -(const float scale) const noexcept {
    return Vector(x - scale, y - scale, z - scale);
}
constexpr Vector Vector::operator +(const float scale) const noexcept {
    return Vector(x + scale, y + scale, z + scale);
}
constexpr Vector Vector::operator /(const float scale) const noexcept {
    return Vector(x / scale, y / scale, z / scale);
}
HASH_INLINE void Vector::CrossSelf(const Vector &other) noexcept {
    *this = Cross(other);
}
HASH_INLINE Vector Vector::Cross(const Vector &other) const noexcept {
    return Vector(y * other.z - z * other.y, z * other.x - x * other.z, x * other.y - y * other.x);
}
HASH_INLINE float Vector::Dot() const noexcept { //Dot Self
    return x * x + y * y + z * z;
}
#endif

constexpr Vector Vector::Reciprocal() const noexcept {
    return Vector(hash_math::rcp(x), hash_math::rcp(y), hash_math::rcp(z));
}

constexpr Vector Vector::Absolute() const noexcept {
    return Vector(hash_math::abs(x), hash_math::abs(y), hash_math::abs(z));
}

constexpr float Vector::Dot(const Vector &other) const noexcept {
    return x * other.x + y * other.y + z * other.z;
}

HASH_INLINE float Vector::Norm() const noexcept {
    return hash_math::sqrt(Dot());
}

HASH_INLINE float Vector::InvNorm() const noexcept {
    return hash_math::rcp(hash_math::sqrt(Dot()));
}

HASH_INLINE Vector Vector::Normalized() const noexcept {
    ASSERT(IsValid());
    Vector ret_val(*this);
    return ret_val.Normalize();
}

HASH_INLINE Vector Vector::FixedNormalized() const noexcept {
    ASSERT(IsValid());
    Vector ret_val(*this);
    return ret_val.FixedNormalize();
}

HASH_INLINE float Vector::NormalizeLength() noexcept {
    ASSERT(IsValid());
    const float length_local = hash_math::sqrt(x * x + y * y + z * z);
    if (length_local < 1e-10F) [[unlikely]] {
        return 0.F;
    }
    *this /= length_local;
    return length_local;
}
/*
HASH_INLINE Vector &Vector::Normalize() noexcept {
    ASSERT(IsValid());
    const float square = Dot();
    return square != 0.F && square != 1.F ? *this /= hash_math::sqrt(square) : *this;
}
*/
HASH_INLINE Vector &Vector::Normalize() noexcept {
    const float square = hash_math::sqrt(x * x + y * y + z * z);
    if (square != 0.F && (square > 1.000001F || square < 0.99999F)) {
        *this /= square;
    }
    return *this;
}

HASH_INLINE Vector &Vector::FixedNormalize() noexcept {
    ASSERT(IsValid());
    const float square = hash_math::sqrt(x * x + y * y + z * z);
    if (square != 0.F && (square > 1.000001F || square < 0.99999F)) {
        //    if (square != 0.F && square != 1.F) [[likely]] {
        *this /= square;
        const float vsum = hash_math::abs(x + y + z);
        if (vsum > 1.F && vsum < 1.0001F) {
            FixNormalizedVector();
        }
    }
    return *this;
}

//free function
HASH_INLINE float DistancePointToPlane(const Vector &point, const Vector &p_onplane, const Vector &normal) noexcept {
    const Vector delta = point - p_onplane;
    return Dot(delta, normal);
}

constexpr void PushMinMax(const Vector &p, Vector &minv, Vector &maxv) noexcept {
    minv.x = std::min(p.x, minv.x);
    minv.y = std::min(p.y, minv.y);
    minv.z = std::min(p.z, minv.z);
    maxv.x = std::max(p.x, maxv.x);
    maxv.y = std::max(p.y, maxv.y);
    maxv.z = std::max(p.z, maxv.z);
}


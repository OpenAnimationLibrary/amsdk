﻿//BC  2/4/2004  \Bob110\Include\Macros.h
// ReSharper disable CppClangTidyCppcoreguidelinesMacroUsage
#pragma once

#include "StdAfx.h"

#include <algorithm>
#include <numbers>
/* unused
HASH_INLINE bool CompareZero(float f) noexcept {
    const int fi = *reinterpret_cast<int *>(&f);
    return (fi & 0x7fffffff) <= 4u;
}
*/

HASH_INLINE bool is_prime(const uint32_t x) noexcept {
    for (uint32_t i = 3; true; i += 2) {
        const uint32_t q = x / i;
        if (q < i) {
            return true;
        }
        if (x == q * i) {
            return false;
        }
    }
}

HASH_INLINE uint32_t Next_Prime(uint32_t x) noexcept {
    if (x <= 2) {
        return 2;
    }
    if (!(x & 1U)) {
        ++x;
    }
    for (; !is_prime(x); x += 2) {}
    return x;
}

template <typename T>
int SIGN(const T a) noexcept {
    return a < 0 ? -1 : 1;
}

constexpr int SIGN(const float a) noexcept {
    return a < 0.F ? -1 : 1;
}

constexpr int SIGN(const double a) noexcept {
    return a < 0. ? -1 : 1;
}

constexpr float SIGN_FLOAT(const float a) noexcept {
    return a < 0.F ? -1.F : 1.F;
}

constexpr double SIGN_DOUBLE(const double a) noexcept {
    return a < 0. ? -1. : 1.;
}

HASH_INLINE void Round(float &in, const double multiple) noexcept {
    const auto f_multiple = (float)multiple;
    const float epsilon = std::numeric_limits<float>::epsilon() * f_multiple;
    const float incr = signbit(in) ? -epsilon : epsilon;
    in = roundf((in + incr) / f_multiple) * f_multiple;
}

HASH_INLINE void Round(double &in, const double multiple) noexcept {
    const double epsilon = std::numeric_limits<double>::epsilon() * multiple;
    const double incr = signbit(in) ? -epsilon : epsilon;
    in = round((in + incr) / multiple) * multiple;
}

HASH_INLINE float RoundValue(const float number, const float modulo) noexcept {
    float rvalue(number);
    Round(rvalue, modulo);
    return rvalue;
}

#ifdef MAX
#undef MAX
#endif
template <typename T>
constexpr T MAX(const T a, const T b) noexcept {
    return a > b ? a : b;
}

#ifdef MIN
#undef MIN
#endif
template <typename T>
constexpr T MIN(const T a, const T b) noexcept {
    return a < b ? a : b;
}

template <typename T1>
long RoundValue(const T1 number) {
    return lrint(number);
}

template <typename T1>
int64_t RoundValueLL(const T1 number) noexcept {
    return llrint(number);
}

// Swaps the two values.
template <typename T1>
void SWAP(T1 &a, T1 &b) noexcept {
    const T1 tmp = a;
    a = b;
    b = tmp;
}

template <typename T1>
unsigned int fast_log2floor(const T1 d) {
    return static_cast<unsigned int>(hash_math::log(d) / std::numbers::ln2_v<float>);
}

template <typename T1>
float fast_log2trunc(const T1 d) {
    float ret = static_cast<float>(d);
    // cppcheck-suppress invalidPointerCast
    const auto pret = reinterpret_cast<int *>(&ret);
    *pret = *pret & 0xFF800000;
    return ret;
}

/*
template<typename T>
T lerp(T t, T a, T b) {
   ASSERT(false && "check for std::lerp");
    return a + t * (b - a);
}
*/

HASH_INLINE uint32_t fast_round_to_UINT(const float d) noexcept {
    return (uint32_t)lroundf(d);
}

template <class T>
constexpr T hash_clamp(const T &a, const T &low, const T &high) {
    T val = a;
    if (!(low <= val)) // Forces clamp(NaN,low,high) to return low
    {
        val = low;
    }
    if (val > high) {
        val = high;
    }
    return val;
}

constexpr float hash_clamp(const float &a, const float &low, const float &high) noexcept {
    float val = a;
    if (!(low <= val)) // Forces clamp(NaN,low,high) to return low
    {
        val = low;
    }
    val = std::min(val, high);
    return val;
}

/// Safe pow: clamp the domain so it never returns Inf or NaN or has divide
/// by zero error.
template <typename T>
constexpr T safe_pow(T x, T y) {
    if (y == T(0)) {
        return T(1);
    }
    if (x == T(0)) {
        return T(0);
    }
    // if x is negative, only deal with integer powers
    if (x < T(0) && y != floor(y)) {
        return T(0);
    }
    // FIXME: this does not match "fast" variant because clamping limits are different
    T r = std::pow(x, y);
    // Clamp to avoid returning Inf.
    const T big = std::numeric_limits<T>::max();
    return hash_clamp(r, -big, big);
}

/*
template <typename T1, typename T2>
float safe_pow(const T1 a, const T2 b) {
    const float result = hash_math::pow(a, b);
    if (_finitef(result))
        return result;
    return 0.F;
}
*/

template <class T>
void hash_combine(size_t &seed1, const T v) noexcept {
    std::hash<T> hasher;
    seed1 ^= hasher(v) + 0x9e3779b9 + (seed1 << 6) + (seed1 >> 2);
}

template <typename T>
constexpr auto ISODD(T x) {
    return x & 0x01;
} //shag and plugin

template <typename T>
constexpr auto FLOOR_INT(T a) {
    return a > 0 ? static_cast<int>(a) : -static_cast<int>(-a);
} // some plugins;

template <typename T>
constexpr auto ROUNDOFF(T A) {
    return static_cast<int>(A < 0 ? A - .5 : A + .5);
} // some plugins;

template <typename T>
constexpr auto ROWBYTES(T A) {
    return (A + 15) >> 4 << 1;
} //bitmap

//#define ROWWORDS(A)            (((A)+15) >> 4) //unused
//#define PADWIDTH(x)            ((((x) * 8 + 31) & (~31)) / 8) //unused
//#define CEILING_INT(a)         ((a) == (int)(a) ? (a) : (a) > 0 ? 1 + (int)(a) : -(1 + (int)(-(a)))) //unused
//#define INVERSE(A)             { (A).x = -(A).x; (A).y = -(A).y; (A).z = -(A).z; }//unused
//#define NULLDELETE(a)          { delete (a); (a) = nullptr; } //unused
//#define FI(f)                  (*((int *)&(f)))//unused
//#define IsFloatZero(f)         ((FI(f) << 1) == 0)//unused
//#define FLOATSIGNBITSET(f)     ((*(const unsigned long *)&(f)) >> 31)        //unused
//#define FLOATSIGNBITNOTSET(f)  ((~(*(const unsigned long *)&(f))) >> 31)     //unused
//#define FLOATNOTZERO(f)        ((*(const unsigned long *)&(f)) & ~(1 << 31)) //unused

//#define STRINGIFY_APPEND(a, b) "" a # b
//#define STRINGIFY(x)           STRINGIFY_APPEND("", x)

#ifdef DOCUMENT
#define DOC(A)                 _T(A)
#define MENU_DOC(A, B)         static MenuDoc f_ ## A(A, DOC(B))
//#define DOC_LEVEL(A, L)        static DocLevel f_ ## A_level(A, L)
#else
#define DOC(A)                 ""
#define MENU_DOC(A, B)
//#define DOC_LEVEL(A, L)
#endif

class MenuDoc;
void AddMenuDoc(MenuDoc *menudoc);

class MenuDoc final {
public:
    char *m_documentation;
    uint32_t m_id;

    MenuDoc(const uint32_t menuid, char *documentation) : m_documentation{documentation}, m_id{menuid} {
        AddMenuDoc(this);
    }
};

void *GetMenuDocMap();

class DocLevel;
void AddDocLevel(DocLevel *doclevel);

class DocLevel final {
public:
    uint32_t m_id;
    int m_level;

    DocLevel(const uint32_t id, const int level)
        : m_id(id), m_level(level) {
        AddDocLevel(this);
    }
};

void *GetDocLevelMap();

inline bool no_output{false};
#if defined(_DEBUG)
#define ODS(s) OutputDebugStringA(s)
HASH_INLINE void ODSF(const char *format, ...) {
    if (no_output) {
        return;
    }
    constexpr int TraceBufferSize = 2048;
    char szBuf[TraceBufferSize];
    va_list argptr;
    va_start(argptr, format);
    vsprintf_s(szBuf, TraceBufferSize, format, argptr); // NOLINT(cert-err33-c)
    va_end(argptr);
    ::OutputDebugString(szBuf);
}
#else
HASH_INLINE void ODSF(const char *, ...) noexcept {}
#define ODS(s)
#endif

HASH_INLINE void ODSF_Rel(const char *format, ...) {
    if (no_output) {
        return;
    }
    constexpr int TraceBufferSize = 2048;
    char szBuf[TraceBufferSize];
    va_list argptr;
    va_start(argptr, format);
    vsprintf_s(szBuf, TraceBufferSize, format, argptr); // NOLINT(cert-err33-c)
    va_end(argptr);
    ::OutputDebugString(szBuf);
}

template <class F>
class final_act {
public:
    explicit final_act(F f) noexcept : f_(std::move(f)) {}

    final_act(final_act &&other) noexcept
        : f_(std::move(other.f_)), invoke_(other.invoke_) {
        other.invoke_ = false;
    }

    final_act(const final_act &) = delete;
    final_act &operator=(const final_act &) = delete;
    final_act &operator=(final_act &&) = delete;

    ~final_act() noexcept {
        if (invoke_) {
            f_();
        }
    }

private:
    F f_;
    bool invoke_{true};
};

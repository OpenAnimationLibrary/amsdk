﻿//Dan  7/23/2004  \DanLP115\Include\ColorBtn.h
#pragma once

#include "DataType.h"// IWYU pragma: keep
#include "Exports.h"
#include "RGBFloat.inl"//member

class SECWellButton;

class PLUGINEXPORT HashColorBtn final {
public:
    SECWellButton *btn{nullptr};

    explicit HashColorBtn(uint32_t id);
    ~HashColorBtn();

    HashColorBtn(const HashColorBtn &) = delete;
    HashColorBtn(HashColorBtn &&) = delete;
    HashColorBtn &operator=(const HashColorBtn &) = delete;
    HashColorBtn &operator=(HashColorBtn &&) = delete;

    [[nodiscard]] RGBFloat GetColor() const;
    void SetColor(const RGBFloat &col) const;
    [[nodiscard]] COLORREF GetColorRef() const;
    void SetColorRef(COLORREF col) const;
    [[nodiscard]] uint8_t GetRed() const;
    [[nodiscard]] uint8_t GetGreen() const;
    [[nodiscard]] uint8_t GetBlue() const;
};

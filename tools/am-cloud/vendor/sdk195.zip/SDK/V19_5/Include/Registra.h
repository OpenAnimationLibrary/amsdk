﻿//RC  4/25/2002  \HRandy95\Include\Registra.h
// ReSharper disable CppParameterMayBeConst
#pragma once

#include "Exception.h"
#include "StrClass.h"

class Registration {
public:
    String m_localizedname;
    String m_classname;
    String m_filename;
    Registration *m_next{nullptr};
    HINSTANCE m_hinst{nullptr};
    HINSTANCE m_hresource{nullptr};
    HICON m_hicon{nullptr};
    uint32_t m_defaulthiconid{0};
    uint32_t m_nameid{0};
    int m_version{0};
#ifdef _WIN64
    int padding{};
#endif

    Registration() noexcept = default;

    Registration(HINSTANCE hinst, HINSTANCE hresource, const char *classname, const uint32_t nameid) noexcept : m_classname((String)classname), m_hinst(hinst), m_hresource(hresource) {
        if (hresource) {
            char buf_local[STRINGSIZE]{};
            LoadString(hresource, nameid, buf_local, STRINGSIZE);
            m_localizedname = (String)buf_local;
        } else {
            m_nameid = nameid;
        }
    }

    virtual ~Registration() {
        try {
            if (m_hinst != m_hresource) {
                FreeLibrary(m_hresource);
            }
            if (m_hinst) {
                FreeLibrary(m_hinst);
            }
        }
        catch (...) {
            DeveloperDebugThrow(__FILE__, __LINE__);
#ifdef DEBUG
            const String text = m_filename + " throw an exception in FreeLibrary.\n";
            ODS(text.Get());
           ASSERT(false && "FreeLibrary");
#endif
        }
    }

    Registration(const Registration &) = delete;
    Registration(Registration &&) = delete;
    Registration &operator=(const Registration &) = delete;
    Registration &operator=(Registration &&) = delete;

#ifdef MEMDEBUG
   void        *operator new (size_t size, char *file, const int line) {
      return ALLOCEXT(size, file, line);
   }
#else
    void *operator new(const size_t size) noexcept {
        return AllocExt(size);
    }
#endif
    void operator delete(void *ptr) noexcept {
        FreeExt(ptr);
    }
};

//BC  4/13/2004  \Bob110\Include\RType.h
#pragma once

constexpr uint8_t RSPHERE = 5U;
constexpr uint8_t RCONE = 6U;
constexpr uint8_t RCYLINDER = 7U;
constexpr uint8_t RBOX = 8U;
constexpr uint8_t SEGMENTOBJ = 9U;
constexpr uint8_t FIGUREOBJ = 10U;
constexpr uint8_t RPROP = 11U;
constexpr uint8_t BINNODE = 12U;
constexpr uint8_t PATCHBOUND = 13U;
constexpr uint8_t SUBPATCHBOUND = 14U;
constexpr uint8_t PROPPATCHBOUND = 15U;
constexpr uint8_t LINEGEOM = 16U;
constexpr uint8_t PARTICLESYSTEM = 17U;
constexpr uint8_t PARTICLE = 18U;
constexpr uint8_t BLOBBYSYSTEM = 19U;
constexpr uint8_t BLOBBY = 20U;
constexpr uint8_t FLOCKSYSTEM = 21U;
constexpr uint8_t VOLUMETRIC = 22U;
constexpr uint8_t SPRITESYSTEM = 23U;
constexpr uint8_t SPRITE = 24U;
constexpr uint8_t SHAG = 25U;
constexpr uint8_t STRAND = 26U;
constexpr uint8_t FOLLICLE = 27U;
constexpr uint8_t HAIR = 28U;
constexpr uint8_t HAIRQUAD = 29U;
constexpr uint8_t HAIRSEGMENT = 30U;
constexpr uint8_t HAIRFOLLICLE = 31U;
constexpr uint8_t GUIDEPATCH = 32U;
constexpr uint8_t HAIRCUBIC = 33U;
constexpr uint8_t FLUIDSYSTEM = 34U;
constexpr uint8_t FLUIDPARTICLE = 35U;
constexpr uint8_t STREAKSYSTEM = 36U;
constexpr uint8_t STREAK = 37U;
constexpr uint8_t LIGHT = 38U;

constexpr uint8_t FUNDAMENTAL_DELIMETER = 50U;
constexpr uint8_t PROPQUADRANGLE = 51U;
constexpr uint8_t QUADRANGLE = 52U; //this must be the last two entries, Hsp.cpp  ThreadInfo::Intersect

/*
#define RSPHERE        5
#define RCONE          6
#define RCYLINDER      7
#define RBOX           8
#define SEGMENTOBJ     9
#define FIGUREOBJ      10
#define RPROP          11
#define BINNODE        12
#define PATCHBOUND     13
#define SUBPATCHBOUND  14
#define PROPPATCHBOUND 15
#define LINEGEOM       16
#define PARTICLESYSTEM 17
#define PARTICLE       18
#define BLOBBYSYSTEM   19
#define BLOBBY         20
#define FLOCKSYSTEM    21
#define VOLUMETRIC     22
#define SPRITESYSTEM   23
#define SPRITE         24
#define SHAG           25
#define STRAND         26
#define FOLLICLE       27
#define HAIR           28
#define HAIRQUAD       29
#define HAIRSEGMENT    30
#define HAIRFOLLICLE   31
#define GUIDEPATCH     32
#define HAIRCUBIC      33
#define FLUIDSYSTEM    34
#define FLUIDPARTICLE  35
#define STREAKSYSTEM   36
#define STREAK         37
#define LIGHT          38

#define PROPQUADRANGLE 51
#define QUADRANGLE     52        //this must be the last two entries, Hsp.cpp  ThreadInfo::Intersect
*/

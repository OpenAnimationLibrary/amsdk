//NAP  12/20/2004  \Noel120\Include\RGBByte.inl
// ReSharper disable CppClangTidyCppcoreguidelinesPreferMemberInitializer
#pragma once

#include "RGBByte.h"
#include "RGBFloat.h"

HASH_INLINE RGBByte::RGBByte(const RGBFloat &color) {
    m_red = FLOATTOBYTE(color.Red());
    m_green = FLOATTOBYTE(color.Green());
    m_blue = FLOATTOBYTE(color.Blue());
}

HASH_INLINE RGBFloat RGBByte::GetFactoredRGBFloat() const noexcept {
    return RGBFloat(m_red, m_green, m_blue);
}

HASH_INLINE RGBFloat RGBByte::GetNormalizedRGBFloat() const noexcept {
    return RGBFloat((float)m_red/MAXCOLOR, (float)m_green/MAXCOLOR, (float)m_blue/MAXCOLOR);
}

HASH_INLINE RGBAByte::RGBAByte(const RGBAFloat &color) {
    m_color.m_red = FLOATTOBYTE(color.Red());
    m_color.m_green = FLOATTOBYTE(color.Green());
    m_color.m_blue = FLOATTOBYTE(color.Blue());
    m_alpha = FLOATTOBYTE(color.Alpha());
}

HASH_INLINE void RGBAByte::Set(const RGBAFloat &color) noexcept {
    m_color.m_red = FLOATTOBYTE(color.Red());
    m_color.m_green = FLOATTOBYTE(color.Green());
    m_color.m_blue = FLOATTOBYTE(color.Blue());
    m_alpha = FLOATTOBYTE(color.Alpha());
}

HASH_INLINE void RGBAByte::Set(const RGBFloat &color) noexcept {
    m_color.m_red = FLOATTOBYTE(color.Red());
    m_color.m_green = FLOATTOBYTE(color.Green());
    m_color.m_blue = FLOATTOBYTE(color.Blue());
    m_alpha = MAXCOLOR;
}

HASH_INLINE RGBFloat RGBAByte::GetRGBFloat() const noexcept {
    return RGBFloat((float)m_color.m_red / MAXCOLOR, (float)m_color.m_green / MAXCOLOR, (float)m_color.m_blue / MAXCOLOR);
}

HASH_INLINE RGBAFloat RGBAByte::GetRGBAFloat() const noexcept {
    return RGBAFloat((float)m_color.m_red / MAXCOLOR, (float)m_color.m_green / MAXCOLOR, (float)m_color.m_blue / MAXCOLOR, (float)m_alpha / MAXCOLOR);
}

HASH_INLINE RGBFloat RGBAByte::GetFactoredRGBFloat() const noexcept {
    return RGBFloat(m_color.m_red, m_color.m_green, m_color.m_blue);
}

HASH_INLINE RGBAFloat RGBAByte::GetFactoredRGBAFloat() const noexcept {
    return RGBAFloat(m_color.m_red, m_color.m_green, m_color.m_blue, m_alpha);
}

HASH_INLINE RGBFloat RGBAByte::GetNormalizedRGBFloat() const noexcept {
    return RGBFloat((float)m_color.m_red / MAXCOLOR, (float)m_color.m_green / MAXCOLOR, (float)m_color.m_blue / MAXCOLOR);
}

HASH_INLINE RGBAFloat RGBAByte::GetNormalizedRGBAFloat() const noexcept {
    return RGBAFloat((float)m_color.m_red / MAXCOLOR, (float)m_color.m_green / MAXCOLOR, (float)m_color.m_blue / MAXCOLOR, (float)m_alpha / MAXCOLOR);
}

HASH_INLINE YAByte::YAByte(const YAFloat &color) {
    m_luminance = FLOATTOBYTE(color.Luminance());
    m_alpha = FLOATTOBYTE(color.Alpha());
}

HASH_INLINE YAFloat YAByte::GetFactoredRGBAFloat() const noexcept {
    return YAFloat(m_luminance, m_alpha);
}

HASH_INLINE YAFloat YAByte::GetNormalizedRGBAFloat() const noexcept {
    return YAFloat((float)m_luminance / MAXCOLOR, (float)m_alpha / MAXCOLOR);
}

HASH_INLINE YAFloat YAByte::GetYAFloat() const noexcept {
    return YAFloat((float)m_luminance / MAXCOLOR, (float)m_alpha / MAXCOLOR);
}

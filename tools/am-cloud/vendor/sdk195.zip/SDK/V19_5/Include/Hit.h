﻿//BC  5/3/2004  \Bob110\Include\Hit.h
#pragma once

#include "Allocate.h"
#include "Vector.h"
#include "DataType.h"// IWYU pragma: keep

class RObject;
class BinNode;
class RayPatch;
class Follicle;
class HairCubic;

class Hit final {
public:
    Vector m_p{0.F};
    Vector m_truen{0.F};
    RObject *m_object{nullptr};
    BinNode *m_baseobject{nullptr};
    RayPatch *m_raypatch{nullptr};
    Follicle *m_follicle{nullptr};
    uint32_t m_patchid{0};
    float m_t{0.F};
    float m_u{0.F};
    float m_v{0.F};
    int m_offset{0};
    int m_polyid{-1};
    bool m_isexitblobby{false};
    bool m_is5point{false};
    bool m_isblobby{false};
    bool m_side{false}; //for triangle intersection
    bool m_isflipped{false};
    bool m_ishit{false};
    bool m_isadditivetransparency{false};
    bool m_ismultiplyspecularbytransparency{false};

#ifdef MEMDEBUG
    void *operator new(size_t size, char *file, const int line) noexcept {
        return ALLOCEXT(size, file, line);
    }
    void *operator new[](size_t size, char *file, const int line) {
        return ALLOCEXT(size, file, line);
    }
#else
    void *operator new(const size_t size) noexcept {
        return AllocExt(size);
    }
#endif
    void operator delete(void *ptr) noexcept {
        FreeExt(ptr);
    }

    Hit() noexcept = default;

    Hit(const Vector &mp, RObject *mobject, const float mt, const float mu, const float mv, const int mpolyid, const bool mside) noexcept
        : m_p(mp), m_truen(0.F), m_object(mobject), m_t(mt), m_u(mu), m_v(mv), m_polyid(mpolyid), m_side(mside) {}

    Hit(const Hit &other) noexcept = default;
    /*
        Hit(const Hit &other) noexcept
            : m_p(other.m_p),
              m_truen(other.m_truen),
              m_object(other.m_object),
              m_baseobject(other.m_baseobject),
              m_raypatch(other.m_raypatch),
              m_follicle(other.m_follicle),
              m_patchid(other.m_patchid),
              m_t(other.m_t),
              m_u(other.m_u),
              m_v(other.m_v),
              m_offset(other.m_offset),
              m_polyid(other.m_polyid),
              m_Hit_bitfield(other.m_Hit_bitfield) {}
    */
    ~Hit() = default;

    Hit &operator=(const Hit &) noexcept = default;
    Hit(Hit &&) = default;
    Hit &operator=(Hit &&) = default;

    void Empty() noexcept {
        m_polyid = -1;
        m_baseobject = nullptr;
        m_object = nullptr;
        m_follicle = nullptr;
        m_raypatch = nullptr;
        m_isexitblobby = m_is5point = m_isblobby = m_side = m_isflipped = m_ishit = m_isadditivetransparency = m_ismultiplyspecularbytransparency = false;
        m_t = m_u = m_v = 0.F;
        m_offset = 0;
        m_patchid = 0;
        m_p.SetZero();
        m_truen.SetZero();
    }
};

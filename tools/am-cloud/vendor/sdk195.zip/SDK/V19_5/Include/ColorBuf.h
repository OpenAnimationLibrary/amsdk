﻿//Dan  7/22/2004  \DanLP115\Include\ColorBuf.h
// ReSharper disable CppClangTidyCppcoreguidelinesMacroUsage
#pragma once

#include "StdAfx.h"
#include "RGBFloat.h"

#ifndef MAXCOLOR
#define MAXCOLOR 255
#endif

class RGBFloat;
class RGBAFloat;

class ColorBuf final {
public:
    union {
        uint32_t color;
        struct {
            uint8_t red, green, blue, alpha;
        };

    };

    ColorBuf() noexcept : color(4278190080) {}//alpha = MAXCOLOR

    explicit ColorBuf(const unsigned int col) noexcept : color(col) {}
    explicit ColorBuf(const int col) noexcept : color(col) {
        alpha = MAXCOLOR;
    }

    ColorBuf(const uint8_t pred, const uint8_t pgreen, const uint8_t pblue) noexcept : red(pred), green(pgreen), blue(pblue), alpha(MAXCOLOR) {}
    ColorBuf(const int pred, const int pgreen, const int pblue) noexcept : red(pred), green(pgreen), blue(pblue), alpha(MAXCOLOR) {}
    ColorBuf(const uint8_t pred, const uint8_t pgreen, const uint8_t pblue, const uint8_t palpha) noexcept: red(pred), green(pgreen), blue(pblue), alpha(palpha) {}

    // ReSharper disable once CppNonExplicitConvertingConstructor
    ColorBuf(const COLORREF &c) noexcept {
        red = GetRValue(c);
        green = GetGValue(c);
        blue = GetBValue(c);
        alpha = MAXCOLOR;
    }

    explicit ColorBuf(const RGBAFloat &s_color) noexcept;

    ~ColorBuf() = default;

    ColorBuf &operator=(const ColorBuf &other) noexcept {
        if (this == &other) {
            return *this;
        }
        color = other.color;
        return *this;
    }

    ColorBuf(const ColorBuf &) = default;
    ColorBuf(ColorBuf &&) = default;
    ColorBuf &operator=(ColorBuf &&) = default;

    void operator +=(const ColorBuf &) noexcept;
    void operator -=(const ColorBuf &) noexcept ;
    void operator *=(float) noexcept ;
    ColorBuf operator +(const ColorBuf &other) const noexcept ;

    // ReSharper disable once CppNonExplicitConversionOperator
    constexpr operator COLORREF() const noexcept {
        return RGB(red, green, blue);
    }

    [[nodiscard]] RGBFloat GetFactoredRGBFloat() const noexcept;
    [[nodiscard]] RGBFloat GetNormalizedRGBFloat() const noexcept;
    [[nodiscard]] RGBAFloat GetNormalizedRGBAFloat() const noexcept;

    [[nodiscard]] uint8_t Red() const noexcept {
        return red;
    }

    [[nodiscard]] uint8_t Green() const noexcept {
        return green;
    }

    [[nodiscard]] uint8_t Blue() const noexcept {
        return blue;
    }

    [[nodiscard]] uint8_t Alpha() const noexcept {
        return alpha;
    }

    [[nodiscard]] uint32_t Color() const noexcept {
        return color;
    }

    void Set(const uint8_t pred, const uint8_t pgreen, const uint8_t pblue, const uint8_t palpha) noexcept {
        red = pred;
        green = pgreen;
        blue = pblue;
        alpha = palpha;
    }

    void SetRed(const uint8_t pred) noexcept {
        red = pred;
    }

    void SetGreen(const uint8_t pgreen) noexcept {
        green = pgreen;
    }

    void SetBlue(const uint8_t pblue) noexcept {
        blue = pblue;
    }

    void SetAlpha(const uint8_t palpha) noexcept {
        alpha = palpha;
    }

    void SetColor(const uint32_t pcolor) noexcept {
        color = pcolor;
        alpha = MAXCOLOR;
    }

    void GammaCorrect(float power) noexcept;

    [[nodiscard]] HASH_INLINE RGBFloat Get() const noexcept;
    [[nodiscard]] float GetOpacity() const noexcept;
    void Set(RGBFloat s_color) noexcept ;
    void SetOpacity(float opacity) noexcept;

    constexpr friend bool operator==(const ColorBuf &lhs, const ColorBuf &rhs) noexcept {
        return lhs.color == rhs.color;
    }

    constexpr friend bool operator!=(const ColorBuf &lhs, const ColorBuf &rhs) noexcept {
        return !operator==(lhs, rhs);
    }

    friend std::ostream &operator<<(std::ostream &os, const ColorBuf &val) {
        os << val.blue << " " << val.green << " " << val.red << " " << val.alpha;
        return os;
    }

};

HASH_INLINE void ColorBuf::Set(const RGBFloat s_color) noexcept {
    red = (uint8_t) (std::min(255, fast_ftol_unsigned(s_color.Red() * MAXCOLOR + .5F)));
    green = (uint8_t) (std::min(255, fast_ftol_unsigned(s_color.Green() * MAXCOLOR + .5F)));
    blue = (uint8_t) (std::min(255, fast_ftol_unsigned(s_color.Blue() * MAXCOLOR + .5F)));
}

HASH_INLINE float ColorBuf::GetOpacity() const noexcept {
    if (alpha != 0) {
        return (float)alpha / MAXCOLOR;
    }
    return 0;
}

HASH_INLINE void ColorBuf::SetOpacity(const float opacity) noexcept {
    alpha = (uint8_t) (fast_ftol_unsigned(opacity * MAXCOLOR + .5F));
}

HASH_INLINE void ColorBuf::operator +=(const ColorBuf &other) noexcept {
    if (int tempred; (tempred = red + other.red) > MAXCOLOR) {
        red = MAXCOLOR;
    } else {
        red = (uint8_t) tempred;
    }
    if (int tempgreen; (tempgreen = green + other.green) > MAXCOLOR) {
        green = MAXCOLOR;
    } else {
        green = (uint8_t) tempgreen;
    }
    if (int tempblue; (tempblue = blue + other.blue) > MAXCOLOR) {
        blue = MAXCOLOR;
    } else {
        blue = (uint8_t) tempblue;
    }
    if (int tempalpha; (tempalpha = alpha + other.alpha) > MAXCOLOR) {
        alpha = MAXCOLOR;
    } else {
        alpha = (uint8_t) tempalpha;
    }
}

HASH_INLINE ColorBuf ColorBuf::operator +(const ColorBuf &other) const noexcept {
    ColorBuf temp(*this);
    temp.red += other.red;
    temp.green += other.green;
    temp.blue += other.blue;
    temp.alpha += other.alpha;
    return temp;
}

HASH_INLINE void ColorBuf::operator -=(const ColorBuf &other) noexcept {
    red -= other.red;
    green -= other.green;
    blue -= other.blue;
    alpha -= other.alpha;
}

HASH_INLINE void ColorBuf::operator *=(const float factor) noexcept {
    red = (uint8_t) (lround(factor * red + .5F));
    green = (uint8_t) (lround(factor * green + .5F));
    blue = (uint8_t) (lround(factor * blue + .5F));
    alpha = (uint8_t) (lround(factor * alpha + .5F));
}

HASH_INLINE void GammaCorrectColBuf(uint8_t *color, const float power) noexcept {
    if (!color || power == 1.F) {
        return;
    }
    *color = (uint8_t) (fast_round(std::min(255.F, MAXCOLOR * hash_math::pow((float)*color / MAXCOLOR, hash_math::rcp(power)))));
}

HASH_INLINE void ColorBuf::GammaCorrect(const float power) noexcept {
    if (power == 1.F) {
        return;
    }
    GammaCorrectColBuf(&red, power);
    GammaCorrectColBuf(&green, power);
    GammaCorrectColBuf(&blue, power);
}

template<typename T1, typename T2, typename T3>
constexpr auto MAKELUMINANCE(T1 red, T2 green, T3 blue) {
    return (0.299F * (red) + 0.587F * (green) + 0.114F * (blue));
}

//#include "ColorBuf.inl"

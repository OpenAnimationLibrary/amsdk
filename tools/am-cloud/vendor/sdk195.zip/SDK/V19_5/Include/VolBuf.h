﻿//MH  16 Jul 1998
#pragma once

#include "Exports.h"
#include "Vector.h"

class TurbulenceNode;
class InfluenceShape;

class VolBuf final {
public:
    Vector m_p{0.F};
    Vector m_worldp{0.F};
    TurbulenceNode *turbnodehead{nullptr};
    InfluenceShape *influenceshape{nullptr};

    VolBuf() noexcept = default;
    ~VolBuf() = default;

    VolBuf(const VolBuf &) = delete;
    VolBuf(VolBuf &&) = delete;
    VolBuf &operator=(VolBuf &&) = delete;
    VolBuf &operator=(const VolBuf &) = delete;

    [[nodiscard]] PLUGINEXPORT float GetTurbulenceValue(const Vector &turbp) const;
    [[nodiscard]] PLUGINEXPORT float GetFallOffValue(const Vector &p) const;
};

﻿//RC  4/24/2002  \HRandy95\Include\Vector2.h
#pragma once

#include "Vector.h"

#ifndef _ALGORITHM_
#include <algorithm>
#endif

class Matrix33;

//size 8
class Vector2 final {
public:
#ifdef DEFAULT_INITIALIZED
    float x{0.F};
    float y{0.F};
#else
    float x;
    float y;
#endif
    constexpr Vector2() noexcept = default;// : x(0.F), y(0.F) {}
    constexpr Vector2(const float f) noexcept : x(f), y(f) {}
    constexpr Vector2(const float xi, const float yi) noexcept : x(xi), y(yi) {}

    constexpr float const &operator [](const int index) const noexcept {
       ASSERT(index < 2);
       return (&x)[index];
    }

    constexpr float &operator [](const int index) noexcept {
       ASSERT(index < 2);
       return (&x)[index];
    }

    constexpr Vector2 &operator=(const float scale) noexcept {
        x = y = scale;
        return *this;
    }

    constexpr void SetZero() noexcept {
        x = y = 0.F;
    }

    constexpr void Set(const float px, const float py) noexcept {
        x = px;
        y = py;
    }

    constexpr void Set(const int px, const int py) noexcept {
        x = static_cast<float>(px);
        y = static_cast<float>(py);
    }

    constexpr void Set(const float init) noexcept {
        x = y = init;
    }

    constexpr Vector2 &operator +=(const Vector2 other) noexcept {
        x += other.x;
        y += other.y;
        return *this;
    }

    constexpr Vector2 &operator -=(const Vector2 other) noexcept {
        x -= other.x;
        y -= other.y;
        return *this;
    }

    constexpr Vector2 &operator *=(const Vector2 other) noexcept {
        x *= other.x;
        y *= other.y;
        return *this;
    }

    constexpr Vector2 &operator -=(const float scale) noexcept {
        x -= scale;
        y -= scale;
        return *this;
    }

    constexpr Vector2 &operator *=(const float scale) noexcept {
        x *= scale;
        y *= scale;
        return *this;
    }

    constexpr Vector2 &operator /=(const float scale) noexcept {
        ASSERT(scale != 0.F);
        x /= scale;
        y /= scale;
        return *this;
    }

    constexpr Vector2 &operator /=(const Vector2 other) noexcept {
        x /= other.x;
        y /= other.y;
        return *this;
    }

    constexpr Vector2 &Negate() noexcept {
        x = -x;
        y = -y;
        return *this;
    }

    //unary minus
    constexpr Vector2 operator -() const noexcept {
        return Vector2(*this).Negate();
    }

    [[nodiscard]] bool IsZero() const noexcept {
        ASSERT(IsValid());
        if (hash_math::abs(x) > FLT_EPSILON) {
            return false;
        }
        if (hash_math::abs(y) > FLT_EPSILON) {
            return false;
        }
        return true;
    }

    [[nodiscard]] constexpr float Sum() const noexcept {
        return x + y;
    }

    [[nodiscard]] bool InBound(const float minbound = 0.F, const float maxbound = 1.F) const noexcept {
        ASSERT(IsValid());
        if (x < minbound || x > maxbound) {
            return false;
        }
        if (y < minbound || y > maxbound) {
            return false;
        }
        return true;
    }
    
    void Clamp(const float minvalue = 0.F, const float maxvalue = 1.F) noexcept {
        ASSERT(IsValid());
        x = hash_clamp(x, minvalue, maxvalue);
        y = hash_clamp(y, minvalue, maxvalue);
    }

    bool operator==(const Vector2 other) const noexcept {
        ASSERT(IsValid());
        ASSERT(other.IsValid());
        return floatEQ(x, other.x) && floatEQ(y, other.y);
    }

    bool operator!=(const Vector2 other) const noexcept {
        ASSERT(IsValid());
        ASSERT(other.IsValid());
        return !operator==(other);
    }

    [[nodiscard]] constexpr float Square() const noexcept;
    [[nodiscard]] HASH_INLINE float Norm() const noexcept;
    constexpr Vector2 &Normalize() noexcept;
    HASH_INLINE float NormalizeLength() noexcept;
    [[nodiscard]] constexpr Vector2 Normalized() const noexcept;
    [[nodiscard]] constexpr Vector2 Absolute() const noexcept;
    [[nodiscard]] constexpr Vector2 Reciprocal() const noexcept;
    [[nodiscard]] constexpr Vector2 Orthogonal() const noexcept;
    [[nodiscard]] constexpr float Dot(Vector2) const noexcept;
    constexpr Vector2 operator +(Vector2) const noexcept;

    void PushMinMax(Vector2 &minv, Vector2 &maxv) const noexcept {
        ASSERT(IsValid());
        minv.x = std::min(x, minv.x);
        minv.y = std::min(y, minv.y);
        maxv.x = std::max(x, maxv.x);
        maxv.y = std::max(y, maxv.y);
    }

    friend void swap(Vector2 &lhs, Vector2 &rhs) noexcept {
        const Vector2 tmp(lhs);
        lhs = rhs;
        rhs = tmp;
    }

#ifdef _WIN64
    [[nodiscard]] bool IsValid() const {
        if (!_finitef(x)) {
            return false;
        }
        if (!_finitef(y)) {
            return false;
        }
        return true;
    }
#else
    [[nodiscard]] bool IsValid() const {
        if (!isfinite(x)) {
            return false;
        }
        if (!isfinite(y)) {
            return false;
        }
        return true;
    }
#endif
    //    friend Vector2 operator -(const Vector2 &);
    constexpr friend Vector2 operator -(Vector2, Vector2) noexcept;
    constexpr friend Vector2 operator *(Vector2, float) noexcept;
    constexpr friend Vector2 operator *(float, Vector2) noexcept;
    constexpr friend Vector2 operator /(Vector2, float) noexcept;

    constexpr friend Vector2 operator *(Vector2, Vector2) noexcept; //MEMBERWISE MULTIPLY
    constexpr friend float operator |(Vector2, Vector2) noexcept; //DOT PRODUCT
    constexpr friend float operator ^(Vector2, Vector2) noexcept; //CROSS PRODUCT

//    constexpr friend Vector::Vector(Vector2 other) noexcept;

    constexpr friend float Dot(const Vector2 lhs, const Vector2 rhs) noexcept {
        return lhs.x * rhs.x + lhs.y * rhs.y;
    }

    constexpr friend Vector2 ToVector2(const Vector &other) noexcept;

    friend void RotateVector2(Vector2 &source, const float anglerad) noexcept {
        auto [sa,ca] = hash_math::sincos(anglerad);
        //        const float ca = hash_math::cos(anglerad), sa = hash_math::sin(anglerad);
        source.Set(ca * source.x - sa * source.y, sa * source.x + ca * source.y);
    }

    constexpr friend float CrossZ(const Vector2 lhs, const Vector2 rhs) noexcept {
        return lhs.x * rhs.y - lhs.y * rhs.x;
    }

    friend std::ostream &operator<<(std::ostream &os, const Vector2 &vec) {
        os << vec.x << " " << vec.y;
        return os;
    }
};

//Vector2 operator -(const Vector2 &);
constexpr Vector2 operator -(Vector2, Vector2) noexcept;
constexpr Vector2 operator *(Vector2, float) noexcept;
constexpr Vector2 operator *(float, Vector2) noexcept;
constexpr Vector2 operator /(Vector2, float) noexcept;

constexpr Vector2 operator *(Vector2, Vector2) noexcept; //MEMBERWISE MULTIPLY
constexpr float operator |(Vector2, Vector2) noexcept; //DOT PRODUCT
constexpr float operator ^(Vector2, Vector2) noexcept; //Cross PRODUCT

constexpr Vector2 operator /(const Vector2 other, const float scale) noexcept {
    ASSERT(scale != 0.F);
    return Vector2(other.x / scale, other.y / scale);
}

constexpr Vector2 Vector2::operator +(const Vector2 other) const noexcept {
    return Vector2(x + other.x, y + other.y);
}

constexpr Vector2 operator -(const Vector2 lhs, const Vector2 rhs) noexcept {
    return Vector2(lhs.x - rhs.x, lhs.y - rhs.y);
}

constexpr Vector2 operator *(const Vector2 other, const float scale) noexcept {
    return Vector2(other.x * scale, other.y * scale);
}

constexpr Vector2 operator *(const float scale, const Vector2 other) noexcept {
    return Vector2(other.x * scale, other.y * scale);
}

constexpr Vector2 operator *(const Vector2 lhs, const Vector2 rhs) noexcept {
    return Vector2(lhs.x * rhs.x, lhs.y * rhs.y);
}

constexpr float operator |(const Vector2 lhs, const Vector2 rhs) noexcept {
    return lhs.x * rhs.x + lhs.y * rhs.y;
}

constexpr float operator ^(const Vector2 lhs, const Vector2 rhs) noexcept {
    return lhs.x * rhs.y - lhs.y * rhs.x;
}

constexpr float Vector2::Dot(const Vector2 other) const noexcept {
    return x * other.x + y * other.y;
}

constexpr float Vector2::Square() const noexcept {
    return x * x + y * y;
}

HASH_INLINE float Vector2::Norm() const noexcept {
    ASSERT(IsValid());
    return hash_math::sqrt(Square());
}

HASH_INLINE float Vector2::NormalizeLength() noexcept {
    ASSERT(IsValid());
    const float length_local = Norm();
    if (length_local == 0.F) {//[[unlikely]] {
        return 0.F;
    }
    *this /= length_local;
    return length_local;
}

constexpr Vector2 Vector2::Normalized() const noexcept {
    return Vector2(*this).Normalize();
}

constexpr Vector2 &Vector2::Normalize() noexcept {
    const float square = Square();
    return square != 0.F ? *this /= hash_math::sqrt(square) : *this;
}

constexpr Vector2 Vector2::Absolute() const noexcept {
    return Vector2(hash_math::abs(x), hash_math::abs(y));
}

constexpr Vector2 Vector2::Reciprocal() const noexcept {
    return Vector2(hash_math::rcp(x), hash_math::rcp(y));
}

constexpr Vector2 Vector2::Orthogonal() const noexcept {
    return Vector2(y, -x);
}

constexpr Vector::Vector(const Vector2 other) noexcept : x(other.x), y(other.y), z(1.F) {}

constexpr Vector2 ToVector2(const Vector &other) noexcept {
    return Vector2(other.x, other.y);
}


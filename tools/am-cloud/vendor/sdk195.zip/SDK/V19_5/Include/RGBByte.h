﻿// NAP  12/20/2004  \Noel120\Include\RGBByte.h
#pragma once

#include "Allocate.h"
#include "DataType.h"// IWYU pragma: keep
#include "Macros.h"

#ifndef _IOSTREAM_
#include <iostream>
#endif

class RGBFloat;
class RGBAFloat;
#ifndef MAXCOLOR
#define MAXCOLOR 255
#endif

constexpr auto FLOATTOBYTE(const float flt) {
    return (uint8_t) hash_clamp(fast_round(flt * MAXCOLOR), 0, 255);
}

//#define RGBTest(r,g,b) ((COLORREF)(((BYTE)(r)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(b))<<16)))

//******************************************************************************
//** RGBByte
//******************************************************************************
class RGBByte final {
public:
    uint8_t m_blue{0};
    uint8_t m_green{0};
    uint8_t m_red{0};

    RGBByte() noexcept = default;
    RGBByte(const float value) noexcept : m_blue(FLOATTOBYTE(value)), m_green(FLOATTOBYTE(value)), m_red(FLOATTOBYTE(value)) {}
    RGBByte(const uint8_t pred, const uint8_t pgreen, const uint8_t pblue) noexcept: m_blue(pblue), m_green(pgreen), m_red(pred) {}

    explicit RGBByte(const COLORREF c) noexcept : m_blue(GetBValue(c)), m_green(GetGValue(c)), m_red(GetRValue(c)) {}
    RGBByte(const RGBFloat &color);

    ~RGBByte() = default;
    RGBByte(const RGBByte &) = default;
    RGBByte &operator=(const RGBByte &) noexcept = default;
    RGBByte(RGBByte &&) = default;
    RGBByte &operator=(RGBByte &&) = default;

#ifdef MEMDEBUG
    void *operator new(const size_t size, char *file, const int line) {
        return ALLOCBITMAP(size, file, line);
    }
#else
    void *operator new(const size_t size) noexcept {
        return AllocBitmap(size);
    }
#endif
    void operator delete(void *ptr) noexcept {
        FreeBitmap(ptr);
    }

    // ReSharper disable once CppNonExplicitConversionOperator
    constexpr operator COLORREF() const noexcept {
        return RGB(m_red, m_green, m_blue);
    }

    RGBByte &operator /=(const float scale) noexcept {
        return *this *= hash_math::rcp(scale);
    }

    [[nodiscard]] RGBFloat GetFactoredRGBFloat() const noexcept ;
    [[nodiscard]] RGBFloat GetNormalizedRGBFloat() const noexcept ;

    [[nodiscard]] uint8_t Red() const noexcept {
        return m_red;
    }

    [[nodiscard]] uint8_t Green() const noexcept {
        return m_green;
    }

    [[nodiscard]] uint8_t Blue() const noexcept {
        return m_blue;
    }

    void Set(const uint8_t pred, const uint8_t pgreen, const uint8_t pblue) noexcept {
        m_red = pred;
        m_green = pgreen;
        m_blue = pblue;
    }

    void Set(const uint8_t value) noexcept {
        m_red = m_green = m_blue = value;
    }

    void SetRed(const uint8_t red) noexcept {
        m_red = red;
    }

    void SetGreen(const uint8_t green) noexcept {
        m_green = green;
    }

    void SetBlue(const uint8_t blue) noexcept {
        m_blue = blue;
    }

    [[nodiscard]] RGBByte GammaCorrect(float power) const noexcept;

    void Clamp() noexcept {
        m_red = hash_clamp(m_red, (uint8_t)0, (uint8_t)MAXCOLOR);
        m_green = hash_clamp(m_green, (uint8_t)0, (uint8_t)MAXCOLOR);
        m_blue = hash_clamp(m_blue, (uint8_t)0, (uint8_t)MAXCOLOR);
    }

    RGBByte &operator +=(const RGBByte &other) noexcept {
        m_red += other.m_red;
        m_green += other.m_green;
        m_blue += other.m_blue;
        Clamp();
        return *this;
    }

    RGBByte operator +(const RGBByte &other) noexcept {
        m_red = m_red + other.m_red;
        m_green = m_green + other.m_green;
        m_blue = m_blue + other.m_blue;
        Clamp();
        return RGBByte(*this);
    }

    RGBByte &operator -=(const RGBByte &other) noexcept{
        m_red -= other.m_red;
        m_green -= other.m_green;
        m_blue -= other.m_blue;
        Clamp();
        return *this;
    }

    RGBByte &operator *=(const float factor) noexcept {
        m_red *= factor;
        m_green *= factor;
        m_blue *= factor;
        Clamp();
        return *this;
    }

    [[nodiscard]] float GetLuminance() const noexcept {
        return 0.299F * m_red + 0.587F * m_green + 0.114F * m_blue;
    }

    constexpr friend bool operator==(const RGBByte &lhs, const RGBByte &rhs) noexcept {
        return lhs.m_red == rhs.m_red && lhs.m_green == rhs.m_green && lhs.m_blue == rhs.m_blue;
    }

    constexpr friend bool operator!=(const RGBByte &lhs, const RGBByte &rhs) noexcept {
        return !operator==(lhs, rhs);
    }

    friend std::ostream &operator<<(std::ostream &os, const RGBByte &val) {
        os << val.m_blue << " " << val.m_green << " " << val.m_red;
        return os;
    }
    //   bool CheckOffBound( float lobound, float hibound ) { return false; }; // YP : For HDR testing and debugging purpose
};

HASH_INLINE void GammaCorrect(uint8_t *color, const float power) noexcept {
    if (power == 1.F) {
        return;
    }
    *color = FLOATTOBYTE(hash_math::pow((float)*color / MAXCOLOR, hash_math::rcp(power)));
}

HASH_INLINE RGBByte RGBByte::GammaCorrect(const float power) const noexcept {
    if (power == 1.F) {
        return *this;
    }
    return RGBByte(
        FLOATTOBYTE(hash_math::pow((float)m_red / MAXCOLOR, hash_math::rcp(power))),
        FLOATTOBYTE(hash_math::pow((float)m_green / MAXCOLOR, hash_math::rcp(power))),
        FLOATTOBYTE(hash_math::pow((float)m_blue / MAXCOLOR, hash_math::rcp(power))));
}

//******************************************************************************
//** RGBAByte
//******************************************************************************
class RGBAByte final {
public:
    RGBByte m_color;
    uint8_t m_alpha{MAXCOLOR};

    RGBAByte() noexcept = default;
    RGBAByte(const float value) noexcept : m_color(value) {}
    RGBAByte(const uint8_t pred, const uint8_t pgreen, const uint8_t pblue) noexcept : m_color(pred, pgreen, pblue) {}
    RGBAByte(const uint8_t pred, const uint8_t pgreen, const uint8_t pblue, const uint8_t palpha) noexcept : m_color(pred, pgreen, pblue), m_alpha(palpha) {}
    explicit RGBAByte(const COLORREF c) noexcept : m_color(c) {}
    RGBAByte(const RGBAFloat &color);

    ~RGBAByte() = default;
    RGBAByte(const RGBAByte &) = default;
    RGBAByte &operator=(const RGBAByte &) noexcept = default;
    RGBAByte(RGBAByte &&) = default;
    RGBAByte &operator=(RGBAByte &&) = default;

#ifdef MEMDEBUG
    void             *operator new(const size_t size, char *file, const int line) {
        return ALLOCBITMAP(size, file, line);
    }
#else
    void *operator new(const size_t size) noexcept {
        return AllocBitmap(size);
    }
#endif
    void operator delete(void *ptr) noexcept {
        FreeBitmap(ptr);
    }

    // ReSharper disable once CppNonExplicitConversionOperator
    constexpr operator COLORREF() const noexcept {
        return RGB(m_color.m_red, m_color.m_green, m_color.m_blue);
    }

    RGBAByte &operator /=(const float scale) noexcept {
        return *this *= hash_math::rcp(scale);
    }

    [[nodiscard]] RGBFloat GetFactoredRGBFloat() const noexcept;
    [[nodiscard]] RGBFloat GetNormalizedRGBFloat() const noexcept;
    [[nodiscard]] RGBAFloat GetFactoredRGBAFloat() const noexcept;
    [[nodiscard]] RGBAFloat GetNormalizedRGBAFloat() const noexcept;

    [[nodiscard]] uint8_t Red() const noexcept {
        return m_color.m_red;
    }

    [[nodiscard]] uint8_t Green() const noexcept {
        return m_color.m_green;
    }

    [[nodiscard]] uint8_t Blue() const noexcept {
        return m_color.m_blue;
    }

    [[nodiscard]] uint8_t Alpha() const noexcept {
        return m_alpha;
    }

    void Set(const uint8_t pred, const uint8_t pgreen, const uint8_t pblue, const uint8_t alpha) noexcept {
        m_color.Set(pred, pgreen, pblue);
        m_alpha = alpha;
    }

    void SetRed(const uint8_t red) noexcept {
        m_color.SetRed(red);
    }

    void SetGreen(const uint8_t green) noexcept {
        m_color.SetGreen(green);
    }

    void SetBlue(const uint8_t blue) noexcept {
        m_color.SetBlue(blue);
    }

    void SetAlpha(const uint8_t alpha) noexcept {
        m_alpha = alpha;
    }

    [[nodiscard]] RGBAByte GammaCorrect(const float power) const noexcept {
        RGBAByte value;
        value.m_color = m_color.GammaCorrect(power);
        value.m_alpha = m_alpha;
        return value;
    }
    void Clamp() {
        m_color.Clamp();
        m_alpha = hash_clamp(m_alpha, (uint8_t)0, (uint8_t)MAXCOLOR);
    }

    RGBAByte &operator +=(const RGBAByte &other) noexcept {
        m_color.operator+=(other.m_color);
        m_alpha += other.m_alpha;
        Clamp();
        return *this;
    }

    RGBAByte operator +(const RGBAByte &other) noexcept {
        m_color.operator+=(other.m_color);
        m_alpha = std::min(m_alpha + other.m_alpha, MAXCOLOR);
        return RGBAByte(*this);
    }

    RGBAByte &operator -=(const RGBAByte &other) noexcept {
        m_color.operator-=(other.m_color);
        m_alpha -= other.m_alpha;
        Clamp();
        return *this;
    }

    RGBAByte &operator *=(const float factor) noexcept {
        m_color *= factor;
        m_alpha *= factor;
        Clamp();
        return *this;
    }

    [[nodiscard]] HASH_INLINE RGBFloat GetRGBFloat() const noexcept;
    [[nodiscard]] HASH_INLINE RGBAFloat GetRGBAFloat() const noexcept;
    [[nodiscard]] float GetOpacity() const noexcept;
    HASH_INLINE void Set(const RGBFloat &) noexcept;
    HASH_INLINE void Set(const RGBAFloat &) noexcept;
    void SetOpacity(float opacity) noexcept;

    [[nodiscard]] float GetLuminance() const noexcept {
        return m_color.GetLuminance();
    }

    constexpr friend bool operator==(const RGBAByte &lhs, const RGBAByte &rhs) noexcept {
        return lhs.m_color == rhs.m_color && lhs.m_alpha == rhs.m_alpha;
    }

    constexpr friend bool operator!=(const RGBAByte &lhs, const RGBAByte &rhs) noexcept {
        return !operator==(lhs, rhs);
    }

    friend std::ostream &operator<<(std::ostream &os, const RGBAByte &val) {
        os << val.m_color << " " << val.m_alpha;
        return os;
    }

    //   bool CheckOffBound( float lobound, float hibound ) { return false; }; // YP : For HDR testing and debugging purpose
};

HASH_INLINE float RGBAByte::GetOpacity() const noexcept {
    return (float)m_alpha / MAXCOLOR;
}

HASH_INLINE void RGBAByte::SetOpacity(const float opacity) noexcept {
    m_alpha = FLOATTOBYTE(opacity);
}


//******************************************************************************
//** YAByte
//******************************************************************************
class YAFloat;

class YAByte final {
public:
    uint8_t m_luminance{0};
    uint8_t m_alpha{MAXCOLOR};

    YAByte() noexcept = default;
    explicit YAByte(const uint8_t luminance) noexcept : m_luminance(luminance) {}
    YAByte(const float luminance) noexcept : m_luminance(FLOATTOBYTE(luminance)){}

    YAByte(const uint8_t luminance, const uint8_t alpha) noexcept : m_luminance(luminance), m_alpha(alpha) {}
    YAByte(const float luminance, const float alpha) noexcept  : m_luminance(FLOATTOBYTE(luminance)), m_alpha(FLOATTOBYTE(alpha)) {}

    YAByte(const YAFloat &color);

    ~YAByte() = default;
    YAByte(const YAByte &) = default;
    YAByte &operator=(const YAByte &) noexcept = default;
    YAByte(YAByte &&) = default;
    YAByte &operator=(YAByte &&) = default;



    // compute CIE Rec.709 luminance
    YAByte(const uint8_t pred, const uint8_t pgreen, const uint8_t pblue) noexcept {
        m_luminance = (uint8_t) (pred * 0.2125F + pgreen * 0.7154F + pblue * 0.0721F);
        m_alpha = MAXCOLOR;
    }

    YAByte(const uint8_t pred, const uint8_t pgreen, const uint8_t pblue, const uint8_t palpha) noexcept {
        m_luminance = (uint8_t) (pred * 0.2125F + pgreen * 0.7154F + pblue * 0.0721F);
        m_alpha = palpha;
    }


#ifdef MEMDEBUG
    void             *operator new(const size_t size, char *file, const int line) {
        return ALLOCBITMAP(size, file, line);
    }
#else
    void *operator new(const size_t size) noexcept {
        return AllocBitmap(size);
    }
#endif
    void operator delete(void *ptr) noexcept {
        FreeBitmap(ptr);
    }

    // ReSharper disable once CppNonExplicitConversionOperator
    constexpr operator uint8_t() const noexcept {
        return m_luminance;
    }

    YAByte &operator /=(const float scale) noexcept {
        return *this *= hash_math::rcp(scale);
    }

    [[nodiscard]] float GetFactoredFloat() const noexcept {
        return m_luminance;
    }

    [[nodiscard]] float GetNormalizedFloat() const noexcept {
        return (float)m_luminance / MAXCOLOR;
    }

    [[nodiscard]] YAFloat GetFactoredRGBAFloat() const noexcept;
    [[nodiscard]] YAFloat GetNormalizedRGBAFloat() const noexcept;

    [[nodiscard]] uint8_t Luminance() const noexcept {
        return m_luminance;
    }

    [[nodiscard]] uint8_t Alpha() const noexcept {
        return m_alpha;
    }

    void Set(const uint8_t luminance, const uint8_t alpha) noexcept {
        m_luminance = luminance;
        m_alpha = alpha;
    }

    void SetLuminance(const uint8_t luminance) noexcept {
        m_luminance = luminance;
    }

    void SetLuminance(const float luminance) noexcept {
        m_luminance = FLOATTOBYTE(luminance);
    }

    void SetAlpha(const uint8_t alpha) noexcept {
        m_alpha = alpha;
    }

    [[nodiscard]] YAByte GammaCorrect(const float power) const noexcept {
        if (power == 1.F) {
            return *this;
        }
        YAByte value;
        value.m_luminance = FLOATTOBYTE(hash_math::pow((float)m_luminance / MAXCOLOR, hash_math::rcp(power)));
        value.m_alpha = m_alpha;
        return value;
    }

    void Clamp() {
        m_luminance = hash_clamp(m_luminance, (uint8_t)0, (uint8_t)MAXCOLOR);
        m_alpha = hash_clamp(m_alpha, (uint8_t)0, (uint8_t)MAXCOLOR);
    }

    YAByte &operator +=(const YAByte &other) noexcept {
        m_luminance += other.m_luminance;
        m_alpha += other.m_alpha;
        Clamp();
        return *this;
    }

    YAByte operator +(const YAByte &other) noexcept {
        m_luminance = std::min(m_luminance + other.m_luminance, MAXCOLOR);
        m_alpha = std::min(m_alpha + other.m_alpha, MAXCOLOR);
        return YAByte(*this);
    }

    YAByte &operator -=(const YAByte &other) noexcept {
        m_luminance -= other.m_luminance;
        m_alpha -= other.m_alpha;
        Clamp();
        return *this;
    }

    YAByte &operator *=(const float factor) noexcept {
        m_luminance *= factor;
        m_alpha *= factor;
        Clamp();
        return *this;
    }

    [[nodiscard]] float GetFloat() const noexcept {
        return (float)m_luminance / MAXCOLOR;
    }

    [[nodiscard]] YAFloat GetYAFloat() const noexcept;

    [[nodiscard]] float GetOpacity() const noexcept {
        return (float)m_alpha / MAXCOLOR;
    }

    void SetOpacity(const float value) noexcept {
        m_alpha = FLOATTOBYTE(value);
    }

    [[nodiscard]] float GetLuminance() const noexcept {
        return (float)m_luminance / MAXCOLOR;
    }

    constexpr friend bool operator==(const YAByte &lhs, const YAByte &rhs) noexcept {
        return lhs.m_luminance == rhs.m_luminance && lhs.m_alpha == rhs.m_alpha;
    }

    constexpr friend bool operator!=(const YAByte &lhs, const YAByte &rhs) noexcept {
        return !operator==(lhs, rhs);
    }

    friend std::ostream &operator<<(std::ostream &os, const YAByte &val) {
        os << val.m_luminance << " " << val.m_alpha;
        return os;
    }
    //   bool CheckOffBound( float lobound, float hibound ) { return false; }; // YP : For HDR testing and debugging purpose
};


//KB  5/15/01  \Ken90\Include\SDK\HProp.h
#pragma once

#include "HObject.h"

//*********************************************************
//** HPropCache
//*********************************************************
class PLUGINEXPORT HPropCache final : public HObjectCache {
public:
    IEPolyModel *GetIEPolyModel();
};

//*********************************************************
//** HProp
//*********************************************************
class PLUGINEXPORT HProp final : public HObject {
//public:
};

//Dan  12/4/2002  \Dan100\Include\SDK\HSound.h
#pragma once

#include "HHashobj.h"

class HFilenameProperty;
class HTimeProperty;
class HPercentProperty;
class HBoolProperty;

class PLUGINEXPORT HSoundCache final : public HHashObject {
public:
    HFilenameProperty *GetFilename();
    HTimeProperty *GetStart();
    HTimeProperty *GetEnd();
    HTimeProperty *GetLength();
    HPercentProperty *GetVolume();
    HBoolProperty *GetMute();
};

class PLUGINEXPORT HSound final : public HHashObject {
public:
    HTimeRangeProperty *GetCrop();
    HTimeProperty *GetStart();
    HTimeProperty *GetEnd();
    HTimeProperty *GetLength();
    HPercentProperty *GetVolume();
    HBoolProperty *GetMute();
};

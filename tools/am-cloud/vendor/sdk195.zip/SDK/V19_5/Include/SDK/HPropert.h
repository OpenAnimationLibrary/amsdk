﻿//BC  6/14/2005  \Master120\Include\SDK\HPropert.h
//NAP Bitmap COMEBACK RGBFloat needs old ColorVector functions for backward compata
// ReSharper disable CppClangTidyMiscNewDeleteOverloads
#pragma once

#include "SDK/HHashobj.h"
#include "ColorVec.h"
#include "Rotate.h" //for TSQ and RotateEuler

//*********************************************************
//** HPropertyInfo
//*********************************************************

class PLUGINEXPORT HPropertyInfo {
public:
    enum DrawWhen : uint8_t { DRAWNEVER, DRAWALWAYS, DRAWIFSHADED, DRAWIFFLARES, DRAWIFMATERIALS, DRAWIFPARTICLES };

    enum VisibleWhen : uint8_t { VISIBLENEVER, VISIBLEALWAYS, VISIBLECACHEONLY, VISIBLEINSTANCEONLY, VISIBLESOMETIMES };

    static HPropertyInfo *New(const char *localizedname, const char *matchname);

    void operator delete(void *ptr) noexcept {
        DeleteHandle((HPropertyInfo *)ptr);
    }

    static void DeleteHandle(HPropertyInfo *handle);

    void SetLocalizedName(const char *name); //for backward comp with V9.0o and older
    void SetMatchName(const char *name); //for backward comp with V9.0o and older

    void SetLocalizedName(const String &name);
    void SetMatchName(const String &name);
    String GetLocalizedName();
    String GetMatchName();
    void SetDocumentation(const char *doc);

    DrawWhen GetDrawWhen();
    void SetDrawWhen(DrawWhen dw);

    VisibleWhen GetVisibleWhen();
    void SetVisibleWhen(VisibleWhen vw);

    BOOL IsConstant();
    void SetConstant(BOOL state); //Constant will not animate over time

    BOOL IsReadOnly(); //Both cache and instanes will be read only
    void SetReadOnly(BOOL state);

    BOOL IsReadOnlyOnCache(); //User will not be able to change the value on the cache, SetReadOnly should be set to FALSE if you want the instances to be able to be editied
    void SetReadOnlyOnCache(BOOL state);

    BOOL IsReadOnlyOnInstance(); //User will not be able to change the value on the instance, SetReadOnly should be set to FALSE if you want the caches to be able to be editied
    void SetReadOnlyOnInstance(BOOL state);

    BOOL IsAdvanced(); //only shows up if user has Show Advanced Proerties on
    void SetAdvanced(BOOL state);

    BOOL IsSaveProperty(); //Defaults to TRUE
    void SetSaveProperty(BOOL state);

    BOOL IsNotifyAnimObjectValueChanged();
    void SetNotifyAnimObjectValueChanged(BOOL state); //use this to have HxtOnPtrMessage called for your property.  This is a speed hit
    //so only set it if you really want the function to be called
    BOOL IsDeletable();
    void SetDeletable(BOOL state);

    void SetCacheAnimatable(BOOL state);
    BOOL GetCacheAnimatable();

    void SetPluginProperty(BOOL state);
    BOOL GetPluginProperty();
};

//*********************************************************
//** HProperty
//*********************************************************
class HPropertyDriver;
class HPropertyShortcut;

class PLUGINEXPORT HProperty : public HHashObject {
public:
    [[nodiscard]] HPropertyInfo *GetPropertyInfo() const;
    [[nodiscard]] HPropertyDriver *GetHeadDriver() const;

    void Show(BOOL bShow = TRUE) const;

    void SetNullable(BOOL isnullable);
    [[nodiscard]] BOOL IsNullable() const;
    [[nodiscard]] BOOL IsNull() const;
    void SetNull(BOOL state = TRUE, HAnimObject *animob = nullptr);
    void SetIsDynamic(BOOL isdynamic);
    [[nodiscard]] BOOL IsDynamic() const;

    [[nodiscard]] HHashObject *CreateParentForDriver() const;
    [[nodiscard]] HProperty *GetDriverProperty() const;
    void AddDriver(HPropertyDriver *) const;

    bool Compare(const HProperty *other, bool dochildren = true) const; //0 => EQUAL, 1 => NOT EQUAL

    [[nodiscard]] BOOL IsDefaultValue() const;
    [[nodiscard]] int GetIndex() const;

    void Copy(const HProperty *other);
    [[nodiscard]] HPropertyShortcut *FindEmptyRelation() const; //should return HEmptyRelation probably
    [[nodiscard]] HProperty *GetPropertyCache() const;
    [[nodiscard]] HProperty *MakeCopy() const;

    [[nodiscard]] String ToString() const;

    [[nodiscard]] BOOL GetFirstRelationKey() const;
    [[nodiscard]] BOOL GetNextRelationKey() const;
    BOOL GetPrevRelationKey(bool *pHasKey) const;

    [[nodiscard]] HProperty *GetParentProperty() const;

    [[nodiscard]] BOOL IsUserProperty() const;
};

//*********************************************************
//** HBoolPropertyInfo
//*********************************************************
class PLUGINEXPORT HBoolPropertyInfo final : public HPropertyInfo {
public:
    static HBoolPropertyInfo *New(const char *localizedname, const char *matchname);
    void SetDefaultValue(BOOL val);
    [[nodiscard]] BOOL GetDefaultValue() const;

    void SetDisplayInPoseSlider(BOOL show);
    BOOL GetDisplayInPoseSlider();
};

//*********************************************************
//** HBoolProperty
//*********************************************************
class PLUGINEXPORT HBoolProperty final : public HProperty {
public:
    static HBoolProperty *New();
    static HBoolProperty *New(HBoolPropertyInfo *propinfo);
    [[nodiscard]] BOOL GetValue() const;
    BOOL GetValue(Time time);
    void SetValue(BOOL value);
    void StoreValue(Time time, BOOL value, BOOL storeundo = TRUE);
};

//*********************************************************
//** HContainerProperty
//*********************************************************
class PLUGINEXPORT HContainerProperty : public HProperty {
public:
    static HContainerProperty *New();
    static HContainerProperty *New(HPropertyInfo *propinfo);
};

//*********************************************************
//HCategoryProperty
//Maintains an array of sub variables
//*********************************************************
class PLUGINEXPORT HCategoryProperty : public HContainerProperty {
public:
    static HCategoryProperty *New();
    static HCategoryProperty *New(HPropertyInfo *propinfo);
    int AddProperty(HProperty *prop);
    BOOL RemoveProperty(HProperty *prop);
};

//*********************************************************
//** HUserCategoryProperty
//*********************************************************
class PLUGINEXPORT HUserCategoryProperty final : public HCategoryProperty {
public:
    static HUserCategoryProperty *New(); //Use this to add folders to other UserCategoryProperties
    //If trytokeep is TRUE the property name will be the name passed in if it doesn't exist,
    //otherwise it will be the name appended by a instance number of the name
    int AddUserProperty(HProperty *prop, const String &basestring, BOOL trytokeepname = FALSE); //No PropertyInfo needed in passed in Property because it is dynamically allocated in this call
};

//*********************************************************
//** HBoolCategoryProperty
//*********************************************************
class PLUGINEXPORT HBoolCategoryProperty final : public HCategoryProperty {
public:
    static HBoolCategoryProperty *New();
    static HBoolCategoryProperty *New(HBoolPropertyInfo *propinfo);

    [[nodiscard]] BOOL GetValue() const;
    BOOL GetValue(Time time);
    void SetValue(BOOL value);
    void StoreValue(Time time, BOOL value, BOOL storeundo = TRUE);
};

class HTypePropertyInfo;

//*********************************************************
//** HTypeCategoryProperty
//*********************************************************
class PLUGINEXPORT HTypeCategoryProperty final : public HCategoryProperty {
public:
    static HTypeCategoryProperty *New();
    static HTypeCategoryProperty *New(HTypePropertyInfo *propinfo);

    [[nodiscard]] uint64_t GetValue() const;
    uint64_t GetValue(Time time);
    void SetValue(uint64_t value);
    void StoreValue(Time time, uint64_t value, BOOL storeundo = TRUE);
};

//*********************************************************
//** HAttrPropertyInfo
//*********************************************************
class PLUGINEXPORT HAttrPropertyInfo final : public HPropertyInfo {
public:
    static HAttrPropertyInfo *New(const char *localizedname, const char *matchname);
};

//*********************************************************
//** HAttrProperty
//*********************************************************
class HColorProperty;
class HFloatProperty;
class HPercentProperty;
class HMaterial;

class PLUGINEXPORT HAttrProperty final : public HContainerProperty {
public:
    static HAttrProperty *New(HAttrPropertyInfo *propinfo);
    static HAttrProperty *New();
    HAttrProperty *GetBaseAttr();
    HColorProperty *GetDiffuseColor();
    HFloatProperty *GetDiffuseFallOff();
    HColorProperty *GetAmbianceColor();
    HColorProperty *GetAmbianceColorForRead();
    HFloatProperty *GetAmbiance();
    HColorProperty *GetSpecularColor();
    HColorProperty *GetSpecularColorForRead();
    HFloatProperty *GetSpecularSize();
    HFloatProperty *GetSpecularIntensity();
    HFloatProperty *GetRoughness();
    HFloatProperty *GetRoughnessScale();
    HFloatProperty *GetTransparency();
    HFloatProperty *GetDensity();
    HFloatProperty *GetRefraction();
    HFloatProperty *GetTranslucency();
    HFloatProperty *GetReflectivity();
    HPercentProperty *GetReflectiveBlend();
    HFloatProperty *GetReflectivityFallOff();
    HFloatProperty *GetRadiance();
    HBoolProperty *GetGlow();
    BOOL IsComplex(); //tells whether a pre-composited attr is complex (Combiners etc..)
    BOOL IsBump(); //tells whether any of the materials on a pre-composited attr had bump on
    BOOL IsInvariant(); //tells whether any of the materials on a pre-composited attr were invariant
    BOOL IsDisplace(); //tells whether any of the materials on a pre-composited attr had displace on
    float GetSpecExponent();
    HMaterial *GetMaterialHead();
};

//*********************************************************
//** HFileInfoPropertyInfo
//*********************************************************
class PLUGINEXPORT HFileInfoPropertyInfo final : public HPropertyInfo {
//public:
};

class HFilenameProperty;
class HStringProperty;

//*********************************************************
//** HFileInfoProperty
//*********************************************************
class PLUGINEXPORT HFileInfoProperty final : public HContainerProperty {
public:
    HBoolProperty *GetEmbedded();
    HFilenameProperty *GetFileName();
    HStringProperty *GetCreatedBy();
    HStringProperty *GetLastModifiedBy();
    HStringProperty *GetDescription();
    HStringProperty *GetNotes();
};

//*********************************************************
//** HFloatPropertyInfo
//*********************************************************
class PLUGINEXPORT HFloatPropertyInfo : public HPropertyInfo {
public:
    enum : int16_t {
        FF_X = 0x0001,
        FF_Y = 0x0002,
        FF_Z = 0x0003,

        FF_RED = 0x0008,
        FF_GREEN = 0x0010,
        FF_BLUE = 0x0020,

        FF_UNIT = 0x0040,
        FF_PERCENTAGE = 0x0080,
        FF_ANGLE = 0x0100
    };

    static HFloatPropertyInfo *New(const char *localizedname, const char *matchname);
    void SetFactorValue(float val); //Set Factor before calling SetDefault, SetMin or SetMax
    void SetModulo(float modulo);
    void SetDefaultValue(float val);
    void SetMinValue(float val);
    void SetMaxValue(float val);
    void SetFlags(uint32_t flags);

    [[nodiscard]] float GetFactorValue() const;
    [[nodiscard]] float GetDefaultValue() const;
    [[nodiscard]] float GetMinValue() const;
    [[nodiscard]] float GetMaxValue() const;
    [[nodiscard]] uint32_t GetFlags() const;

    void SetDisplayInPoseSlider(BOOL show);
    BOOL GetDisplayInPoseSlider();
};

//*********************************************************
//** HFloatProperty
//*********************************************************
class PLUGINEXPORT HFloatProperty : public HProperty {
public:
    static HFloatProperty *New();
    static HFloatProperty *New(HFloatPropertyInfo *propinfo);
    [[nodiscard]] float GetValue() const;
    [[nodiscard]] float GetValue(Time time) const;
    void SetValue(float value) const;
    void StoreValue(Time time, float value, BOOL storeundo = TRUE) const;
//for backward compatibility
    [[nodiscard]] float GetValue(Time time);
    void SetValue(float value);
    void StoreValue(Time time, float value, BOOL storeundo = TRUE);
};

//*********************************************************
//** HPercentPropertyInfo
//*********************************************************
class PLUGINEXPORT HPercentPropertyInfo final : public HFloatPropertyInfo {
public:
    static HPercentPropertyInfo *New(const char *localizedname, const char *matchname);
    [[nodiscard]] float GetMinValue() const;
    [[nodiscard]] float GetMaxValue() const;
};

//*********************************************************
//** HPercentProperty
//*********************************************************
class PLUGINEXPORT HPercentProperty final : public HFloatProperty {
public:
    static HPercentProperty *New();
    static HPercentProperty *New(HPercentPropertyInfo *propinfo);
};

//*********************************************************
//** HIntPropertyInfo
//*********************************************************
class PLUGINEXPORT HIntPropertyInfo final : public HPropertyInfo {
public:
    static HIntPropertyInfo *New(const char *localizedname, const char *matchname);
    void SetDefaultValue(int val);
    void SetMinValue(int val);
    void SetMaxValue(int val);

    [[nodiscard]] int GetDefaultValue() const;
    [[nodiscard]] int GetMinValue() const;
    [[nodiscard]] int GetMaxValue() const;
};

//*********************************************************
//** HIntProperty
//*********************************************************
class PLUGINEXPORT HIntProperty final : public HProperty {
public:
    static HIntProperty *New();
    static HIntProperty *New(HIntPropertyInfo *propinfo);
    [[nodiscard]] int GetValue() const;
    int GetValue(Time time);
    void SetValue(int value);
    void StoreValue(Time time, int value, BOOL storeundo = TRUE);
};

//*********************************************************
//** HRotatePropertyInfo
//*********************************************************
class PLUGINEXPORT HRotatePropertyInfo final : public HPropertyInfo {
public:
    static HRotatePropertyInfo *New(const char *localizedname, const char *matchname);
};

//*********************************************************
//** HRotateProperty
//*********************************************************
class PLUGINEXPORT HRotateProperty final : public HProperty {
public:
    enum InterpolationMethod : uint8_t { VECTORINTERP, EULERINTERP, QUATINTERP };

    static HRotateProperty *New();
    static HRotateProperty *New(HRotatePropertyInfo *propinfo);

    InterpolationMethod GetDefaultObjectInterpolationMethod();
    void SetDefaultObjectInterpolationMethod(InterpolationMethod method);
    InterpolationMethod GetDefaultBoneInterpolationMethod();
    void SetDefaultBoneInterpolationMethod(InterpolationMethod method);
    InterpolationMethod GetDefaultRootBoneInterpolationMethod();
    void SetDefaultRootBoneInterpolationMethod(InterpolationMethod method);

    [[nodiscard]] const Quaternion &GetValue() const;
    const Quaternion &GetValue(Time time);
    void SetValue(const Quaternion &value);
    void StoreValue(Time time, const Quaternion &value, BOOL storeroll = TRUE, BOOL storeundo = TRUE);
};

//*********************************************************
//** HButtonPropertyInfo
//*********************************************************
class PLUGINEXPORT HButtonPropertyInfo final : public HPropertyInfo {
public:
    static HButtonPropertyInfo *New(const char *localizedname, const char *matchname);

    void SetButtonText(const char *);
    [[nodiscard]] const char *GetButtonText() const;
};

//*********************************************************
//** HButtonProperty
//*********************************************************
class PLUGINEXPORT HButtonProperty final : public HProperty {
public:
    static HButtonProperty *New();
    static HButtonProperty *New(HButtonPropertyInfo *propinfo);

    void SetButtonText(const char *); //Use this over the ones in ButtonPropertyInfo if you need to change the text on different instances of the property
    [[nodiscard]] const char *GetButtonText() const;
    void Press() const;
};

//*********************************************************
//** HBiasPropertyInfo
//*********************************************************
class PLUGINEXPORT HBiasPropertyInfo final : public HPropertyInfo {
public:
    static HBiasPropertyInfo *New(const char *localizedname, const char *matchname);
    HFloatPropertyInfo *GetAlphaPropertyInfo();
    HFloatPropertyInfo *GetGammaPropertyInfo();
    HFloatPropertyInfo *GetMagnitudePropertyInfo();
};

//*********************************************************
//** HBiasProperty
//*********************************************************
class PLUGINEXPORT HBiasProperty final : public HProperty {
public:
    static HBiasProperty *New();
    static HBiasProperty *New(HBiasPropertyInfo *propinfo);

    float GetAlpha();
    float GetGamma();
    float GetMagnitude();
    void SetAlpha(float num);
    void SetGamma(float num);
    void SetMagnitude(float num);

    const Vector &GetValue();
    const Vector &GetValue(Time time);
    Vector GetFactoredValue();

    void SetFactoredValue(const Vector &value);
    void SetValue(const Vector &value);
    void StoreValue(Time time, const Vector &value, BOOL storeundo = TRUE);
};

//*********************************************************
//** HStringPropertyInfo
//*********************************************************
class PLUGINEXPORT HStringPropertyInfo : public HPropertyInfo {
public:
    static HStringPropertyInfo *New(const char *localizedname, const char *matchname);
    void SetDefaultValue(const char *value);
    void SetIllegalChars(const char *value);
    [[nodiscard]] const char *GetDefaultValue() const;
    [[nodiscard]] const char *GetIllegalChars() const;
};

//*********************************************************
//** HStringProperty
//*********************************************************
class PLUGINEXPORT HStringProperty : public HProperty {
public:
    static HStringProperty *New();
    static HStringProperty *New(HStringPropertyInfo *propinfo);
    [[nodiscard]] const char *GetValue() const;
    void SetValue(const char *value);
    void StoreValue(const char *value, BOOL storeundo = TRUE);
};

//*********************************************************
//** HFilenamePropertyInfo
//*********************************************************
class PLUGINEXPORT HFilenamePropertyInfo final : public HStringPropertyInfo {
public:
    static HFilenamePropertyInfo *New(const char *localizedname, const char *matchname);
    void SetFileDialogTitle(const char *value);
    void SetFileDialogFilter(const char *value);
    void SetDefaultExtension(const char *value);
    void SetIsOpenDialog(BOOL isopendialog);
    [[nodiscard]] const char *GetFileDialogTitle() const;
    [[nodiscard]] const char *GetFileDialogFilter() const;
    [[nodiscard]] const char *GetDefaultExtension() const;
    [[nodiscard]] BOOL IsOpenDialog() const;
    BOOL IsPromptForMissingFileOnLoad();
    void SetIsPromptForMissingFileOnLoad(BOOL state);
};

//*********************************************************
//** HFilenameProperty
//*********************************************************
class PLUGINEXPORT HFilenameProperty final : public HStringProperty {
public:
    static HFilenameProperty *New();
    static HFilenameProperty *New(HFilenamePropertyInfo *propinfo);
};

//*********************************************************
//** HDirPropertyInfo
//*********************************************************
class PLUGINEXPORT HDirPropertyInfo final : public HStringPropertyInfo {
public:
    static HDirPropertyInfo *New(const char *localizedname, const char *matchname);
    void SetFileDialogTitle(const char *value);
    [[nodiscard]] const char *GetFileDialogTitle() const;
};

//*********************************************************
//** HDirProperty
//*********************************************************
class PLUGINEXPORT HDirProperty final : public HStringProperty {
public:
    static HDirProperty *New();
    static HDirProperty *New(HDirPropertyInfo *propinfo);
};

//*********************************************************
//** HTimePropertyInfo
//*********************************************************
class PLUGINEXPORT HTimePropertyInfo final : public HPropertyInfo {
public:
    static HTimePropertyInfo *New(const char *localizedname, const char *matchname);
    void SetDefaultValue(Time val);
    void SetMinValue(Time val);
    void SetMaxValue(Time val);

    [[nodiscard]] Time GetDefaultValue() const;
    [[nodiscard]] Time GetMinValue() const;
    [[nodiscard]] Time GetMaxValue() const;
};

//*********************************************************
//** HTimeProperty
//*********************************************************
class PLUGINEXPORT HTimeProperty final : public HProperty {
public:
    static HTimeProperty *New();
    static HTimeProperty *New(HTimePropertyInfo *propinfo);
    [[nodiscard]] Time GetValue() const;
    Time GetValue(Time time);
    void SetValue(Time value);
    void StoreValue(Time time, Time value, BOOL storeundo = TRUE);
    void SetPropertyInfo(HTimePropertyInfo *hpropinfo);
};

//*********************************************************
//** HTimeRangePropertyInfo
//*********************************************************
class PLUGINEXPORT HTimeRangePropertyInfo final : public HPropertyInfo {
public:
    static HTimeRangePropertyInfo *New(const char *localizedname, const char *matchname);
};

//*********************************************************
//** HTimeRangeProperty
//*********************************************************
class PLUGINEXPORT HTimeRangeProperty final : public HContainerProperty {
public:
    static HTimeRangeProperty *New();
    static HTimeRangeProperty *New(HTimeRangePropertyInfo *propinfo);
    HTimeProperty *GetStart();
    HTimeProperty *GetEnd();
};

//*********************************************************
//** HTransformPropertyInfo
//*********************************************************
class PLUGINEXPORT HTransformPropertyInfo final : public HPropertyInfo {
public:
    static HTransformPropertyInfo *New(const char *localizedname, const char *matchname);
};

class HTranslateProperty;
class HScaleProperty;

//*********************************************************
//** HTransformProperty
//*********************************************************
class PLUGINEXPORT HTransformProperty final : public HProperty {
public:
    static HTransformProperty *New();
    static HTransformProperty *New(HTransformPropertyInfo *propinfo);
    HTranslateProperty *GetTranslate();
    HScaleProperty *GetScale();
    HRotateProperty *GetRotate();
    [[nodiscard]] TSQ GetTSQ() const;
    void SetTSQ(const TSQ &tsq);
};

class HTypeInfo;

//*********************************************************
//** TypeInfoArray
//*********************************************************
//don't change , compatibility with Enhance_AM Plugins
class PLUGINEXPORT TypeInfoArray final {
    HTypeInfo *m_typeinfoarray{nullptr};
    int m_count{0};

    void AllocArray(HTypeInfo **array, int count);
    void DeleteArray(HTypeInfo *array);
    HTypeInfo *ElementAt(HTypeInfo *array, int index);

public:
    TypeInfoArray() noexcept = default;

    ~TypeInfoArray() {
        DeleteArray(m_typeinfoarray);
    }

    TypeInfoArray(const TypeInfoArray&) = delete;
    TypeInfoArray& operator=(const TypeInfoArray&) = delete;
    TypeInfoArray(TypeInfoArray&&) = delete;
    TypeInfoArray& operator=(TypeInfoArray&&) = delete;

    void SetArraySize(const int count) {
        DeleteArray(m_typeinfoarray);
        AllocArray(&m_typeinfoarray, count);
        m_count = count;
    }

    void DeleteArray() {
        DeleteArray(m_typeinfoarray);
        m_typeinfoarray = nullptr;
        m_count = 0;
    }

    HTypeInfo *operator[](const int index) {
        return ElementAt(m_typeinfoarray, index);
    }

    //Internal use only
    [[nodiscard]] HTypeInfo *GetTypeInfoArrayData() const noexcept {
        return m_typeinfoarray;
    }

    [[nodiscard]] int GetCount() const noexcept {
        return m_count;
    }
};

//*********************************************************
//** HTypeInfo
//*********************************************************
class PLUGINEXPORT HTypeInfo final {
public:
    [[nodiscard]] String GetMatchName() const;
    [[nodiscard]] String GetLocalizedName() const;
    void SetMatchName(const String &name);
    void SetLocalizedName(const String &name);
    void SetMatchName(const char *);  // Old for backward Compatibility with version 9.0o and older
    void SetLocalizedName(const char *);  // Old for backward Compatibility with version 9.0o and older
};

//*********************************************************
//** HTypePropertyInfo
//*********************************************************
class PLUGINEXPORT HTypePropertyInfo final : public HPropertyInfo {
public:
    static HTypePropertyInfo *New(const char *localizedname, const char *matchname, TypeInfoArray *typeinfoarray);

    void SetDefaultIndex(uint32_t index);
    [[nodiscard]] uint32_t GetDefaultIndex() const;
};

//*********************************************************
//** HTypeProperty
//*********************************************************
class PLUGINEXPORT HTypeProperty final : public HProperty {
public:
    static HTypeProperty *New();
    static HTypeProperty *New(HTypePropertyInfo *propinfo);

    [[nodiscard]] uint32_t GetValue() const;
    uint32_t GetValue(Time time);
    void SetValue(uint32_t value);
    void StoreValue(Time time, uint32_t value, BOOL storeundo = TRUE);
};

//*********************************************************
//** HVectorPropertyInfo
//*********************************************************
class PLUGINEXPORT HVectorPropertyInfo : public HPropertyInfo {
public:
    static HVectorPropertyInfo *New(const char *localizedname, const char *matchname);
    HFloatPropertyInfo *GetX();
    HFloatPropertyInfo *GetY();
    HFloatPropertyInfo *GetZ();

    [[nodiscard]] Vector GetDefaultValue() const;
    void SetDefaultValue(const Vector &v);
};

//*********************************************************
//** HVectorProperty
//*********************************************************
class PLUGINEXPORT HVectorProperty : public HProperty {
public:
    static HVectorProperty *New();
    static HVectorProperty *New(HVectorPropertyInfo *propinfo);

    [[nodiscard]] Vector GetValue() const;
    Vector GetValue(Time time);
    void SetValue(const Vector &value);
    void StoreValue(Time time, const Vector &value, BOOL storeundo = TRUE);

    HFloatProperty *GetX();
    HFloatProperty *GetY();
    HFloatProperty *GetZ();
};

//*********************************************************
//** HVectorPropertyNoSubsInfo
//*********************************************************
class PLUGINEXPORT HVectorPropertyNoSubsInfo final : public HPropertyInfo {
public:
    static HVectorPropertyNoSubsInfo *New(const char *localizedname, const char *matchname);
    HFloatPropertyInfo *GetX();
    HFloatPropertyInfo *GetY();
    HFloatPropertyInfo *GetZ();

    [[nodiscard]] Vector GetDefaultValue() const;
    void SetDefaultValue(const Vector &v);
};

//*********************************************************
//** HVectorPropertyNoSubs
//*********************************************************
class PLUGINEXPORT HVectorPropertyNoSubs : public HProperty {
public:
    static HVectorPropertyNoSubs *New();
    static HVectorPropertyNoSubs *New(HVectorPropertyNoSubsInfo *propinfo);

    [[nodiscard]] float GetXFactor() const;
    [[nodiscard]] float GetYFactor() const;
    [[nodiscard]] float GetZFactor() const;
    [[nodiscard]] const Vector &GetValue() const;
    const Vector &GetValue(Time time);
    [[nodiscard]] Vector GetFactoredValue() const;
    void SetFactoredValue(const Vector &value);
    void SetValue(const Vector &value);
    void StoreValue(Time time, const Vector &value, BOOL storeundo = TRUE);
};

//*********************************************************
//** HVector2PropertyInfo
//*********************************************************
class PLUGINEXPORT HVector2PropertyInfo final : public HPropertyInfo {
public:
    static HVector2PropertyInfo *New(const char *localizedname, const char *matchname);
    HFloatPropertyInfo *GetX();
    HFloatPropertyInfo *GetY();

    [[nodiscard]] Vector2 GetDefaultValue() const;
    void SetDefaultValue(const Vector2 &v);
};

//*********************************************************
//** HVector2Property
//*********************************************************
class PLUGINEXPORT HVector2Property final : public HProperty {
public:
    static HVector2Property *New();
    static HVector2Property *New(HVector2PropertyInfo *propinfo);

    [[nodiscard]] Vector2 GetValue() const;
    Vector2 GetValue(Time time);
    void SetValue(const Vector2 &value);
    void StoreValue(Time time, const Vector2 &value, BOOL storeundo = TRUE);

    HFloatProperty *GetX();
    HFloatProperty *GetY();
};

//*********************************************************
//** HColorPropertyInfo
//*********************************************************
class PLUGINEXPORT HColorPropertyInfo final : public HVectorPropertyInfo {
public:
    static HColorPropertyInfo *New(const char *localizedname, const char *matchname);
    HFloatPropertyInfo *GetRed();
    HFloatPropertyInfo *GetGreen();
    HFloatPropertyInfo *GetBlue();

    [[nodiscard]] RGBFloat GetDefaultRGBFloatValue() const;
    /*don't use this one anymore*/
    [[nodiscard]] ColorVector GetDefaultValue() const;

    void SetDefaultValue(const RGBFloat &rgbfloat);
    /*don't use this one anymore*/
    void SetDefaultValue(const ColorVector &cv);
};

//*********************************************************
//** HColorProperty
//*********************************************************
class ColorBuf;

class PLUGINEXPORT HColorProperty final : public HVectorProperty {
public:
    static HColorProperty *New();
    static HColorProperty *New(HColorPropertyInfo *propinfo);
    HFloatProperty *GetRed();
    HFloatProperty *GetGreen();
    HFloatProperty *GetBlue();

    [[nodiscard]] float GetLuminance() const;

    [[nodiscard]] COLORREF GetCOLORREF() const;
    [[nodiscard]] RGBFloat GetFactoredRGBFloat() const;
    /*don't use this one anymore*/
    [[nodiscard]] ColorVector GetFactoredColorVector() const;

    [[nodiscard]] RGBFloat GetNormalizedRGBFloat() const;
    /*don't use this one anymore*/
    [[nodiscard]] ColorVector GetNormalizedColorVector() const;

    void SetValue(const RGBFloat &value);
    /*don't use this one anymore*/
    void SetValue(const ColorVector &value);

    void StoreValue(Time time, const RGBFloat &value, BOOL storeundo = TRUE);
    /*don't use this one anymore*/
    void StoreValue(Time time, const ColorVector &value, BOOL storeundo = TRUE);

    void StoreValue(Time time, const ColorBuf &value, BOOL storeundo = TRUE);
};

//*********************************************************
//** HScalePropertyInfo
//*********************************************************
class PLUGINEXPORT HScalePropertyInfo final : public HVectorPropertyInfo {
public:
    static HScalePropertyInfo *New(const char *localizedname, const char *matchname);
};

//*********************************************************
//** HScaleProperty
//*********************************************************
class PLUGINEXPORT HScaleProperty final : public HVectorProperty {
public:
    static HScaleProperty *New();
    static HScaleProperty *New(HScalePropertyInfo *propinfo);
};

//*********************************************************
//** HTranslatePropertyInfo
//*********************************************************
class PLUGINEXPORT HTranslatePropertyInfo final : public HVectorPropertyInfo {
public:
    static HTranslatePropertyInfo *New(const char *localizedname, const char *matchname);
};

//*********************************************************
//** HTranslateProperty
//*********************************************************
class PLUGINEXPORT HTranslateProperty final : public HVectorProperty {
public:
    static HTranslateProperty *New();
    static HTranslateProperty *New(HTranslatePropertyInfo *propinfo);
};

//*********************************************************
//** HTranslatePropertyNoSubs
//*********************************************************
class PLUGINEXPORT HTranslatePropertyNoSubs final : public HVectorPropertyNoSubs {
public:
    static HTranslateProperty *New();
    static HTranslateProperty *New(HTranslatePropertyInfo *propinfo);
};

//*********************************************************
//** HObjectListNode
//*********************************************************
class PLUGINEXPORT HObjectListNode final {
public:
    HObjectListNode *GetSibling();
    void SetSibling(HObjectListNode *);

    HTreeObject *GetHObject();
    void SetObject(HTreeObject *);

    static HObjectListNode *New();
    static HObjectListNode *New(HTreeObject *obj, HObjectListNode *next);

    void operator delete(void *ptr) noexcept {
        DeleteHandle((HObjectListNode *)ptr);
    }

    static void DeleteHandle(HObjectListNode *handle);
};

//*********************************************************
//** HPointerPropertyInfo
//*********************************************************
class PLUGINEXPORT HPointerPropertyInfo : public HPropertyInfo {
public:
    static HPointerPropertyInfo *New(const char *localizedname, const char *matchname);
};

//*********************************************************
//** HPointerProperty
//*********************************************************
class PLUGINEXPORT HPointerProperty final : public HProperty {
public:
    static HPointerProperty *New();
    static HPointerProperty *New(HPointerPropertyInfo *propinfo);
    HTreeObject *GetValue();
    void SetValue(HTreeObject *obj); //Rarely used
    void StoreValue(Time time, HTreeObject *obj, BOOL storeundo = TRUE);
    String GetDescription();
    void SetDescription(const String &);
};

//*********************************************************
//** HClipPropertyInfo
//*********************************************************
class PLUGINEXPORT HClipPropertyInfo final : public HPointerPropertyInfo {
public:
    static HClipPropertyInfo *New(const char *localizedname, const char *matchname);
    HVector2PropertyInfo *GetRepeatInfo();
    HTimePropertyInfo *GetTimeInfo();
    HBoolPropertyInfo *GetSeamlessInfo();
};

class HClip;

//*********************************************************
//** HClipProperty
//*********************************************************
class PLUGINEXPORT HClipProperty final : public HContainerProperty {
public:
    static HClipProperty *New();
    static HClipProperty *New(HClipPropertyInfo *propinfo);
    HClip *GetClip();
    HVector2Property *GetRepeat();
    HTimeProperty *GetTime();
    HBoolProperty *GetIsSeamless();

    int GetWidth();
    int GetHeight();
    BOOL ReadBitmap(float x, float y, RGBFloat *diffuse, float *opacity, float pixelwidth);
    /*don't use this one anymore*/
    BOOL ReadBitmap(float x, float y, ColorVector *diffuse, float *opacity, float pixelwidth);

    BOOL ReadBumpmap(float x, float y, Vector2 &delta, float pixelwidth);
    BOOL ReadBumpmap(float x, float y, Vector2 &delta, float pixelwidth, BOOL wrapx, BOOL wrapy);
    BOOL LoadImageHash(const String &filename);
};

//*********************************************************
//** HTexInfo
//*********************************************************
class PLUGINEXPORT HTexInfo final {
public:
    HAttrProperty *GetAttr();
    Vector *GetN(); //surface normal of hit in screen space
    float GetHeight(); //displacement of surface
    void SetHeight(float val);
    Time GetTime(); //time to evaluate
    float GetFPS(); //frames per second
    float GetPixelWidth(); //screen pixel size at hit in A:M units (cm)
    Vector GetGlobalP(); //World Space, If from a HSHader plugin, use HSHader::GetHitP rather than this.
    Vector GetEye(); //point ray was cast from in screen Space
    Vector GetD(); //normalized direction of rayin screen Space
    Matrix34 *GetMatrix(); //matrix to get from model space to screen space
    int GetObjectType();
    HObject *GetHObject();
    void *GetSubObject();
    Matrix34 *GetInverseMatrix(); //matrix to get from screen to texture space
    int GetPixelX(); //screen pixel position being rendered
    int GetPixelY(); //screen pixel position being rendered
    int GetNumberPasses(); //total number of passes to render
    int GetCurrentPass(); //current pass being rendered
};

//*********************************************************
//** HShading
//*********************************************************
class HHit;

class PLUGINEXPORT HShading final : public HProperty {
public:
    void SetACol(const RGBFloat &color);
    void SetDCol(const RGBFloat &color);
    void SetSCol(const RGBFloat &color);
    RGBFloat GetACol();
    RGBFloat GetDCol();
    RGBFloat GetSCol();

    HTexInfo *GetTexInfo();
    Vector *GetAway();
    Vector *GetL();
    float GetIntensity();
    float GetLDot();
    float GetEDot();
    int GetObjectType();
    HObject *GetHObject();
    void *GetSubObject();
    Vector GetHitP();

    float GetHairRadius();
    Vector &GetHairTangent();
    Vector &GetHairCenter();
    Vector &GetHairRootNormal();
    HHit *GetHit();
};

//*********************************************************
//** HGradientPropertyInfo
//*********************************************************
class PLUGINEXPORT HGradientPropertyInfo final : public HPropertyInfo {
public:
    static HGradientPropertyInfo *New(const char *localizedname, const char *matchname);
};

//*********************************************************
//** HGradientProperty
//*********************************************************
class PLUGINEXPORT HGradientProperty final : public HProperty {
public:
    static HGradientProperty *New();
    static HGradientProperty *New(HGradientPropertyInfo *propinfo);
    RGBFloat GetColor(RGBFloat &diffuse, float n);
    /*don't use this one anymore*/
    ColorVector GetColor(ColorVector &diffuse, float n);
};

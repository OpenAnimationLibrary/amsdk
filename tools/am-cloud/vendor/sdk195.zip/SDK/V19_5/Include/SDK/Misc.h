﻿//NAP  12/20/2004  \Noel120\Include\SDK\Misc.h
#pragma once

#include "Exports.h"
#include "StringLi.h"
#include "ColorBuf.h"

class Vector;
class IEModel;
class BitmapNode;
class String;
//*********************************************************
//** Misc Exported Functions
//*********************************************************
PLUGINEXPORT HWND GetMainApplicationWnd();
PLUGINEXPORT CWinApp *GetMainApplication(); //returns A:M self
PLUGINEXPORT int GetTimeMode();
PLUGINEXPORT float GetTurbulence(const Vector &vec);
PLUGINEXPORT void DeleteIEModel(IEModel *iemodel);
PLUGINEXPORT void WriteToLog(const String &logmsg);
PLUGINEXPORT String GetAMVersion();//returns the actual versionname
PLUGINEXPORT bool IsInNetRender();
PLUGINEXPORT float GetScreenGamma();
PLUGINEXPORT ColorBuf GetColor(int index);
PLUGINEXPORT void RefreshAllTrees();
PLUGINEXPORT bool IsHashView(CView *view);
PLUGINEXPORT bool IsStreamMsg(CObject *object);
PLUGINEXPORT StringList *BrowseImages(bool *sequence); //for selecting multiple images
PLUGINEXPORT float atof_replace(const char *buf);
PLUGINEXPORT int atoi_replace(const char *buf);
PLUGINEXPORT int GetOpenMPMode(); //return 0 if openmp is disabled, otherwise returns the number of OpenMP threads should used
//example
//#pragma omp parallel for if(GetApp().m_useopenmp) num_threads(GetApp().m_azprocessor)

// ReSharper disable once CppClassCanBeFinal
class CPluginApp : public CWinApp {
public:
    CPluginApp() = default;
    ~CPluginApp() override = default;

    CPluginApp(const CPluginApp &) = delete;
    CPluginApp &operator=(const CPluginApp &) = delete;
    CPluginApp(CPluginApp &&) = delete;
    CPluginApp &operator=(CPluginApp &&) = delete;

    CWnd *GetMainWnd() override {
        return CWinApp::GetMainWnd();
    }

    int Run() override {
        return CWinApp::Run();
    }

    BOOL PreTranslateMessage(MSG *pMsg) override {
        return CWinApp::PreTranslateMessage(pMsg);
    }

    BOOL PumpMessage() override {
        return CWinApp::PumpMessage();
    }

    BOOL OnIdle(const LONG lCount) override {
        return CWinApp::OnIdle(lCount);
    }

    BOOL IsIdleMessage(MSG *pMsg) override {
        return CWinApp::IsIdleMessage(pMsg);
    }

    int DoMessageBox(LPCTSTR lpszPrompt, const uint32_t nType, const uint32_t nIDPrompt) override {
        return CWinApp::DoMessageBox(lpszPrompt, nType, nIDPrompt);
    }

    BOOL InitInstance() override {
        return CWinApp::InitInstance();
    }

    int ExitInstance() override {
        return CWinApp::ExitInstance();
    }

    void DoWaitCursor(const int nCode) override {
        CWinApp::DoWaitCursor(nCode);
    }
};

// ReSharper disable once CppClassCanBeFinal
class CPluginDialog : public CDialog {
public:
    CPluginDialog() = default;
    explicit CPluginDialog(const uint32_t nIDTemplate, CWnd *pParentWnd = nullptr) : CDialog(nIDTemplate, pParentWnd) {}
    ~CPluginDialog() override = default;

    CPluginDialog(const CPluginDialog &) = delete;
    CPluginDialog &operator=(const CPluginDialog &) = delete;
    CPluginDialog(CPluginDialog &&) = delete;
    CPluginDialog &operator=(CPluginDialog &&) = delete;

    void PreSubclassWindow() override {
        CDialog::PreSubclassWindow();
    }
    [[nodiscard]] CRuntimeClass *GetRuntimeClass() const override {
        return CDialog::GetRuntimeClass();
    }

    BOOL OnInitDialog() override {
        return CDialog::OnInitDialog();
    }
    BOOL CheckAutoCenter() override {
        return CDialog::CheckAutoCenter();
    }

    BOOL OnCmdMsg(const uint32_t nID, const int nCode, void *pExtra, AFX_CMDHANDLERINFO *pHandlerInfo) override {
        return CDialog::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
    }

    BOOL PreTranslateMessage(MSG *pMsg) override {
        return CDialog::PreTranslateMessage(pMsg);
    }

    BOOL ContinueModal() override {
        return CDialog::ContinueModal();
    }

    void EndModalLoop(const int nResult) override {
        CDialog::EndModalLoop(nResult);
    }

    [[nodiscard]] BOOL IsFrameWnd() const override {
        return CDialog::IsFrameWnd();
    }

    BOOL DestroyWindow() override {
        return CDialog::DestroyWindow();
    }

protected:
    WNDPROC *GetSuperWndProcAddr() override {
        return CDialog::GetSuperWndProcAddr();
    }

    LRESULT WindowProc(const uint32_t message, const WPARAM wParam, const LPARAM lParam) override {
        return CDialog::WindowProc(message, wParam, lParam);
    }

    BOOL OnWndMsg(const uint32_t message, const WPARAM wParam, const LPARAM lParam, LRESULT *pResult) override {
        return CDialog::OnWndMsg(message, wParam, lParam, pResult);
    }

    LRESULT DefWindowProc(const uint32_t message, const WPARAM wParam, const LPARAM lParam) override {
        return CDialog::DefWindowProc(message, wParam, lParam);
    }

    void PreInitDialog() override {
        CDialog::PreInitDialog();
    }

    BOOL OnCommand(const WPARAM wParam, const LPARAM lParam) override {
        return CDialog::OnCommand(wParam, lParam);
    }

    BOOL OnNotify(const WPARAM wParam, const LPARAM lParam, LRESULT *pResult) override {
        return CDialog::OnNotify(wParam, lParam, pResult);
    }


    void PostNcDestroy() override {
        CDialog::PostNcDestroy();
    }

    void DoDataExchange(CDataExchange *pDX) override {
        CDialog::DoDataExchange(pDX);
    }

    void OnOK() override {
        CDialog::OnOK();
    }

    void OnCancel() override {
        CDialog::OnCancel();
    }
};

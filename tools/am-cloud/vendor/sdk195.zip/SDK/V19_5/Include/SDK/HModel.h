﻿//BC  10/13/2004  \BobL115\Include\SDK\HModel.h
#pragma once

#include "HSegment.h"

class HDecalContainer;
class HGroupCP;
class HObjectCacheContainer;
class HAction;
class HChor;
class HModel;
class HGroup;
class HCP;
class HSpline;
class HPatch;
class HPatch5;
class HAttrProperty;
class HGroupContainer;
class HSplineContainer;
class HLightCacheContainer;
class HLightContainer;
class HBoneCacheContainer;
class HBoneContainer;
class HLightListNode;
class HDecal;
class HRelationContainer;
//class HGroupNode;
class HNullObjectCache;
class HActionCache;
class HBulletConstraint;

//*********************************************************
//** HModelCache
//*********************************************************
class PLUGINEXPORT HModelCache : public HSegmentCache {
public:
    //Properties
    HFileInfoProperty *GetFileInfo();
    HAttrProperty *GetAttr();

    //Traversal
    //    HModelCache *GetSiblingModelCache(); // Todo
    HObjectCacheContainer *GetParentObjectCacheContainer();
    //Export Patch model
    BOOL ExportModel(HashStream &hs);

    //Export IEModel classes
    IEPatchModel *BuildExportModel(IEModelParms *iemp, const char *modelmapfilename);
    IEPolyModel *BuildExportModel(IEPolyModelParms *iemp, const char *modelmapfilename);

    //Import IEModel classes
    BOOL MergeIEModel(IEPatchModel *model, const char *name, float peaktolerance, BOOL addgroup, BOOL showprogressbar);
    BOOL MergeIEModel(IEPolyModel *model, const char *name, float peaktolerance, BOOL addgroup, BOOL showprogressbar);

    //Creation
    static HModelCache *New(const char *name = nullptr, BOOL embedded = TRUE);
    HModel *NewInstance(HChor *);
    void Update(); //use it after a new model is createt, some splines insertet and you want to do some other operations on this model like extrude , access the tangents and so one
    void OpenView(int viewmode = 0); //open a new view , if no view for this model exists and set the view to the selected mode
    int GetViewMode(); //returns the view from which the plugin is started
    //FRONTVIEW   0
    //BACKVIEW    1
    //LEFTVIEW    2
    //RIGHTVIEW   3
    //TOPVIEW     4
    //BOTTOMVIEW  5
    void ZoomFit(); //zoomfit in all open views for this model

    void MakeCurrent(); //set the model as current and recompute all cp positions and so one

    BOOL ChangeShortCuts(HModelCache *switch_to); //changing shortcuts in chor or action from this to the switch_to model
    BOOL IsInChorOrAction(); //check if instances from this modelcache are in a chor or action

    void SetChanged(BOOL modified = TRUE);

    //Spline Operations
    HSpline *GetHeadSpline();
    HSpline *CreateSpline(); //Be sure to add at least two CP's to the spline
    void DeleteSpline(HSpline *spline);
    BOOL AttachCPs(HCP *cp1, HCP *cp2);
    BOOL AttachHook(HCP *cp1, HCP *cp2, float s);
    BOOL JoinSpline(HCP *cp1, HCP *cp2); //returns FALSE if the cp's are not the endcp's from their spline, joining spline from cp2 to spline from cp1
    void DetachCP(HCP *cp1);

    //Old style spline operations but still work great
    HSpline *StartSpline(Vector *p1, Vector *p2);
    HCP *AddCP(HCP *cp, Vector *p);
    HCP *InsertCP(HCP **cpuplink, HCP *cp, Vector *p);
    BOOL DeleteCP(HCP **cpuplink, HCP *matchcp);
    void BreakSpline(HCP *cp);

    BOOL Make5PointPatch(HGroup *group);
    BOOL Make5PointPatch(HCP *cp1, HCP *cp2, HCP *cp3, HCP *cp4, HCP *cp5);

    void CopyExtrude(BOOL extrude, HGroupCP *grouptocopy, HGroupCP **newgroup);

    //Bone operations
    //Example: modelcache->AddSegment(nullptr, nullptr, "Bone1", GetColor(modelcache->CountBones()));
    HSegmentCache *AddSegment(HBoneCache *parentbonecache, HBoneCache *afterbonecache, String &name, COLORREF color);
    int CountBones();
    HNullObjectCache *AddNullObjectCache(HBoneCache *parentbonecache, HBoneCache *afterbonecache, String &name);

    //Group Operations
    void AddToTemporaryGroup(HGroupCP *gh);
    HGroup *CreateGroup(const String &name);

    //Patch Operations
    void FindPatches();
    HPatch *FindPatch(HCP *cp1, HCP *cp2, HCP *cp3, HCP *cp4);
    HPatch5 *FindPatch(HCP *cp1, HCP *cp2, HCP *cp3, HCP *cp4, HCP *cp5);
    int GetPatchCount();
    HPatch *GetPatch(int index);
    HPatch5 *GetHeadPatch5();

    //Decal Operations
    HDecal *AddDecal(HClip *clipcache = nullptr); //nullptr will prompt

    //Retrieval
    HDecalContainer *GetChildDecalContainer();
    HGroupContainer *GetChildGroupContainer();
    HBoneCacheContainer *GetChildBoneCacheContainer();
    HLightCacheContainer *GetChildLightCacheContainer();
    HSplineContainer *GetChildSplineContainer();
    HRelationContainer *CreateRelationContainer(); //Will return existing if already allocated
};

//*********************************************************
//** HModel
//*********************************************************
class PLUGINEXPORT HModel : public HSegment {
public:
    //Properties
    HAttrProperty *GetAttr();
    HModel *GetNextModelInChor(); //Use with HChor::GetChildModel()
    HBone *FindBone(const char *name);
    void ApplyAttrPropertyToPatches(); //Applies group's HAttrProperties to appropriate patches
    HAction *ApplyAction(HActionCache *hac); //Applies a action to the model

    //Retrieval
    HDecalContainer *GetChildDecalContainer();
    HGroupContainer *GetChildGroupContainer();
    HBoneContainer *GetChildBoneContainer();
    HLightContainer *GetChildLightContainer();
    HSplineContainer *GetChildSplineContainer();
    HLightListNode *GetHeadLightList();
    HRelationContainer *GetChildRelationContainer();
    HChor *GetHChor();

    int GetCountBulletRigidConstraints(); //returns the number of Bullet Rigid Constraints for a model
    HBulletConstraint *GetBulletRigidConstraint(int); //return the bullet rigid constraint, get possible number with function before

    //Export IEModel classes
    IEPatchModel *BuildExportModel(IEModelParms *iemp, Time time, const char *modelmapfilename);
    IEPolyModel *BuildExportModel(IEPolyModelParms *iemp, Time time, const char *modelmapfilename);

    //
    //Operations
    void MakeCurrent();
};

//*********************************************************
//** HPathModel
//*********************************************************
class PLUGINEXPORT HPathModel final : public HModel {
public:
    HModelCache *GetPathModelCache();
};

//*********************************************************
//** HGroupNode
//*********************************************************
/*
class PLUGINEXPORT HGroupNode final {
public:
    HGroupNode *GetNext();
    HGroup *GetGroup();
};
*/

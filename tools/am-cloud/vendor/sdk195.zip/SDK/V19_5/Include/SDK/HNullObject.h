//Dan  6/10/2003  \Dan105\Include\SDK\HNullObject.h
#pragma once

#include "HObject.h"

class HNullObject;
class HNullObjectCache;

//*********************************************************
//** HNullObjectCache
//*********************************************************
class PLUGINEXPORT HNullObjectCache final : public HObjectCache {
public:
    //Creation
    static HNullObjectCache *New(const char *name = nullptr);

    BOOL OnDelete();
};

//*********************************************************
//** HNullObject
//*********************************************************
class PLUGINEXPORT HNullObject final : public HObject {
//public:
};

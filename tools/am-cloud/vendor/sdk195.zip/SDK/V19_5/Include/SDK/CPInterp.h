//Dan  12/20/00  \Dan90\Include\SDK\CPInterp.h
#pragma once

enum CPInterpolationMethod : uint8_t { CPI_DEFAULT, CPI_HOLD, CPI_LINEAR, CPI_SPLINE, CPI_ZEROSLOPE };

enum ExtrapolationMethod : uint8_t { EXT_RESET, EXT_HOLD, EXT_REPEAT, EXT_PINGPONG, EXT_ACCUMULATE, EXT_LINEAR };

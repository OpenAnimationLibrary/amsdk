//KB  12/20/2004  \Noel120\Include\SDK\HBitmap.h
#pragma once

#include "HHashobj.h"
#include "StringLi.h"

class HAnimation;

//*********************************************************
//** HBitmapBuffer
//*********************************************************
class PLUGINEXPORT HBitmapBuffer : public HHashObject {
public:
    //both enums must be be type int , otherwise exr/hdr failed
    //Keep BitmapBuffer (BitmapBuffer.h) up to date with this
    enum ChannelType : int {  // NOLINT(performance-enum-size)
        CT_UBYTE = 0,       //unsigned char (8 bit )
        CT_UINT = 1,        //unsigned int (32 bit)
        CT_HALF = 2,        //half (16 bit floating point)
        CT_FLOAT = 3        //float (32 bit floating point)
        //CT_NUM_CHANNELTYPE //number of channel types unused
    };

    enum BufferType : int {  // NOLINT(performance-enum-size)
        BT_SCALAR = 0,     //One single channel buffer
        BT_RGB = 1,        //RGB 3 channels buffer
        BT_RGBA = 2,       //RGBA 4 channels buffer
        BT_YA = 3         //YA 2 channels buffer
        //BT_NUM_BUFFERTYPE //number of buffer types unused
    };

    void *GetChannelAt(int channum); //NAP Bitmap COME-back expose HBitmapChannel?
    void AllocateData(int mipmaplevel = 0);
    int GetWidth();
    int GetHeight();
    BITMAPINFO *CreateBITMAPINFO(bool replacealpha0withbk = false, bool maketransparent = false, RGBFloat *background = nullptr);
    HBITMAP CreateHBitmap(bool replacealpha0withbk = true, bool maketransparent = false, RGBFloat *background = nullptr);
    HBitmapBuffer *GetNext();
    int GetNbrChannels();
    ChannelType GetChannelsType();
    BufferType GetBufferType();
    const char *GetChannelNameAt(int channum);
    void SetBackground(const RGBFloat &color);
    RGBFloat GetBackground();
    void SetIsKeyBackground(bool iskeybackground);
    BOOL GetIsKeyBackground();
    void SetGamma(float gamma);
    float GetGamma();
    void SetIsPremultipliedAlpha(bool ispremultiplied);
    BOOL GetIsPremultipliedAlpha();
    HBitmapBuffer *MakeCopy();
    HBitmapBuffer *MakeBlankCopy();
    HBitmapBuffer *MakeCroppedCopy(const RECT &cliprect);
};

//*********************************************************
//** HYABuffer
//*********************************************************
class PLUGINEXPORT HYABuffer final : public HBitmapBuffer {
public:
    void *GetData(int mipmaplevel = 0);
};

//*********************************************************
//** HRGBABuffer
//*********************************************************
class PLUGINEXPORT HRGBABuffer : public HBitmapBuffer {
public:
    void *GetData(int mipmaplevel = 0);
};

//*********************************************************
//** HRGBBuffer
//*********************************************************
class PLUGINEXPORT HRGBBuffer final : public HBitmapBuffer {
public:
    void *GetData(int mipmaplevel = 0);
};

//*********************************************************
//** HScalarBuffer
//*********************************************************
class PLUGINEXPORT HScalarBuffer final : public HBitmapBuffer {
public:
    void *GetData(int mipmaplevel = 0);
};

//*********************************************************
//** HVectorBuffer
//*********************************************************
class PLUGINEXPORT HVectorBuffer final : public HBitmapBuffer {
public:
    void *GetData(int mipmaplevel = 0);
};

//*********************************************************
//** HRGBAFloatBuffer
//*********************************************************
class PLUGINEXPORT HRGBAFloatBuffer final : public HRGBABuffer {
public:
    RGBAFloat *GetRGBAFloatData(int miplevel = 0);
};

class PLUGINEXPORT HByteBlock final {
public:
    void operator delete(void *ptr) noexcept {  // NOLINT(misc-new-delete-overloads)
        DeleteHandle((HByteBlock *)ptr);
    }

    static void DeleteHandle(HByteBlock *);
    uint8_t *GetByteBlock();
    int GetBytesPerPixel();
};

//*********************************************************
//** HBitmapNode
//*********************************************************
class PLUGINEXPORT HBitmapNode final : public HHashObject {
public:
    enum LoadFlags : uint8_t { //was : uint32_t 
        LOADDEFAULT = 0x0,
        LOADBKCOLOR = 0x01,
        LOADINFOONLY = 0x02,
        INITIALIZE = 0x04,
        NOMODIFIEDCHECK = 0x08
    };

    enum LoadStatus : uint8_t {
        LOAD_FAILED,
        LOAD_OK,
        ALREADY_LOADED
    };

    enum WriteStatus : uint8_t {
        WRITE_NORESULT = 0x0,
        WRITE_ERROR = 0x01,
        WRITE_OK = 0x02,
        WRITE_NEEDCLOSE = 0x04
    };

    int GetWidth();
    int GetHeight();
    void SetWidth(int width);
    void SetHeight(int height);
    void Copy(HBitmapNode *other);
    HBitmapNode *ScaleBitmap(int width, int height);
    HByteBlock *CreateByteBlock(bool withborder = false, bool *bHasTransparency = nullptr, bool format_BGR = false);
    int GetFps();
    void SetFps(int fps);
    int GetLength();
    void SetLength(int length);
    void AddBuffer(HBitmapBuffer *);
    void DeleteAllBuffers();
    HBitmapBuffer *GetBufferHead();
    HBitmapBuffer *FindBuffer(const String &name);
    HAnimation *GetAnimation();
    void ReadPixel(int x, int y, RGBFloat &color); //NAP Bitmap return error?
    void ReadPixel(int x, int y, RGBAFloat &color);
    void ReadPixel(int x, int y, YAFloat &color);

    uint8_t LoadFrame(const String &filename, int frame = -1, LoadFlags flags = LOADDEFAULT);
    HBitmapNode *MakeCroppedCopy(const RECT &cliprect);
    static HYABuffer *CreateYABuffer(const String &name, HBitmapBuffer::ChannelType chantype, int width, int height);
    static HRGBABuffer *CreateRGBABuffer(const String &name, HBitmapBuffer::ChannelType chantype, int width, int height);
    static HRGBBuffer *CreateRGBBuffer(const String &name, HBitmapBuffer::ChannelType chantype, int width, int height);
    static HScalarBuffer *CreateScalarBuffer(const String &name, HBitmapBuffer::ChannelType chantype, int width, int height);
    static HVectorBuffer *CreateVectorBuffer(const String &name, HBitmapBuffer::ChannelType chantype, int width, int height);
    //prefered output of a posteffect plugin is a RGBAFloatBuffer
    static HRGBAFloatBuffer *CreateRGBAFloatBuffer(const String &name, int width, int height);
    static HBitmapNode *New();
};

PLUGINEXPORT HBitmapNode *BrowseImage(const String &title, String &filename);

//*********************************************************
//** HBufferShortcut
//*********************************************************
class HCamera;

class PLUGINEXPORT HBufferShortcut final : public HHashObject {
public:
    HRGBAFloatBuffer *GetRGBAFloatBuffer(Time time, BOOL normalized = TRUE);
    //the normalized value has only effect for Depth and Normal buffers,
    //TRUE   returned a normalized buffer
    //FALSE  returned the raw data buffer
    //for depth buffer values in the depth range
    //should be checked for hash_constants::max_float, if true no depth information for this avaible
    //for normal buffer values bewteen -1 and 1
    HBufferShortcut *GetNextBufferShortcut();
    void SetBuffer(HBitmapBuffer *buffer);
    String GetFileName();
    HCamera *GetCamera();
};

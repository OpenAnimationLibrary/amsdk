//Dan  4/14/2004  \DanLP110\Include\SDK\HRotoscope.h
#pragma once

#include "HDecal.h"

//*********************************************************
//** HRotoscope
//*********************************************************
class PLUGINEXPORT HRotoscope final : public HBitmap {
public:
    HClipProperty *GetClip();
    HTypeProperty *GetViewIndex();
    HPercentProperty *GetTransparency();
    HBoolProperty *GetIsFront(); //for Camera Rotoscopes
    HBoolProperty *GetIncludeInAlphaBuffer(); //for Camera Rotoscopes
};

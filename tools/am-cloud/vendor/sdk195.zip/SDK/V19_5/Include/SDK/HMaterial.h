//Dan  12/11/2002  \Dan100\Include\SDK\HMaterial.h
#pragma once

#include "HHashobj.h"

class Texture;

//*********************************************************
//** HMaterialCache
//*********************************************************
class PLUGINEXPORT HMaterialCache final : public HHashObject {
public:
    HFileInfoProperty *GetFileInfo();
    HTransformProperty *GetTransform();
    HFloatProperty *GetBumpPercent();
    HFloatProperty *GetDisplacePercent();
    HBoolProperty *GetIsGlobalAxis();
};

//*********************************************************
//** HMaterial
//*********************************************************
class PLUGINEXPORT HMaterial final : public HHashObject {
public:
    HTransformProperty *GetTransform();
    HFloatProperty *GetBumpPercent();
    HFloatProperty *GetDisplacePercent();
    HBoolProperty *GetIsGlobalAxis();
};

//*********************************************************
//** HMaterialNode
//*********************************************************
class PLUGINEXPORT HMaterialNode : public HHashObject {
public:
    const char *GetClassName();
};

//*********************************************************
//** HTextureNode
//*********************************************************
class PLUGINEXPORT HTextureNode final : public HMaterialNode {
public:
    Texture *GetTexture();
};

//*********************************************************
//** HGradientNode
//*********************************************************
class PLUGINEXPORT HGradientNode final : public HMaterialNode {
public:
    HTranslateProperty *GetStart();
    HTranslateProperty *GetEnd();
    HFloatProperty *GetEdgeThreshold();
};

//*********************************************************
//** HSphericalNode
//*********************************************************
class PLUGINEXPORT HSphericalNode final : public HMaterialNode {
public:
    HTranslateProperty *GetTranslate();
    HScaleProperty *GetScale();
    HPercentProperty *GetBlur();
    HFloatProperty *GetRing1Size();
    HFloatProperty *GetRing2Size();
};

//*********************************************************
//** HCheckerNode
//*********************************************************
class PLUGINEXPORT HCheckerNode final : public HMaterialNode {
public:
    HTranslateProperty *GetTranslate();
    HScaleProperty *GetScale();
    HPercentProperty *GetBlur();
};

//Dan  8/4/2004  \DanLP110\Include\SDK\HObject.h
#pragma once

#include "HBone.h"

class HChor;
class HActionShortcutContainer;
class HRelationContainer;
class HAction;

//*********************************************************
//** HObjectCache
//*********************************************************
class PLUGINEXPORT HObjectCache : public HBoneCache {
//public:
};

//*********************************************************
//** HObject
//*********************************************************
class PLUGINEXPORT HObject : public HBone {
public:
    //Properties
    HBoolProperty *GetActive();
    HChor *GetChor();
    HActionShortcutContainer *GetActionShortcutContainer();
    HRelationContainer *GetRelationContainer();
    HAction *GetCurrentChorAction();
    HAction *GetorCreateCurrentChorAction(); //creates a choraction if they not exist V15d
    HObject *MakeCopy(BOOL insertintochor = TRUE);

    void SetIsActionDeleted(BOOL bState);
    BOOL IsActionDeleted();
    HAnimObject *FindAnimObjectFromCache(HAnimObject *key);

    BOOL IsShaded();
    BOOL IsWireframe();
    void SetShaded(BOOL bState);
    void SetWireframe(BOOL bState);
};

//KB  5/15/01  \Ken90\Include\SDK\HMCDevice.h
#pragma once

#include "HHashobj.h"
#include "HObject.h"

//*********************************************************
//** HMCDeviceCache
//*********************************************************
class PLUGINEXPORT HMCDeviceCache final : public HObjectCache {};

//*********************************************************
//** HMCDevice
//*********************************************************
class PLUGINEXPORT HMCDevice final : public HObject {};

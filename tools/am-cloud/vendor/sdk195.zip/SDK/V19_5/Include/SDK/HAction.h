//Dan  6/22/2004  \DanLP110\Include\SDK\HAction.h
#pragma once

#include "HHashobj.h"

class HActionCacheContainer;
class HChor;
class HActionCache;
class HBone;
class HModel;
class HModelCache;
class HPropertyDriver;
class HProperty;
class HFileInfoProperty;
class HBoolCategoryProperty;
class HTimeProperty;
class HTimeRangeProperty;
class HFloatProperty;
class HPointerProperty;
class HTypeProperty;
class HPercentProperty;
class HBoolProperty;

//*********************************************************
//** HAction
//*********************************************************
class PLUGINEXPORT HAction final : public HHashObject {
public:
    //Properties
    HTimeRangeProperty *GetCropRange();
    HTimeRangeProperty *GetChorRange();
    HFloatProperty *GetRepeatCount();
    HTimeProperty *GetCycleLength();

    enum BlendMethod : uint8_t { REPLACE, ADD, BLEND };

    HTypeProperty *GetBlendMethod();
    HPercentProperty *GetBlendRatio();
    HBoolProperty *GetIsHoldLastFrame();
    HBoolProperty *GetIsPostTransition();
    HPercentProperty *GetEase();

    //Operations
    Time GetTotalTime();
    TimeRange GetPlayRange();
    void SetPlayRange(const TimeRange &playrange);
    float GetScaleFactor();

    //Traversal
    HBone *GetParentBone();
    HActionCache *GetActionCache();
    HModel *GetParentModel();
    HChor *GetChor();
};

//*********************************************************
//** HActionCache
//*********************************************************
class PLUGINEXPORT HActionCache : public HHashObject {
public:
    char *GetName();
    //Properties
    HFileInfoProperty *GetFileInfo();
    HBoolCategoryProperty *GetHasStrideLength();
    HFloatProperty *GetStrideLength();
    HTimeRangeProperty *GetStrideRange();

    enum ScaleMethod : uint8_t { SCALENONE, SCALELENGTH, SCALEPOSITION }; //advanced
    HTypeProperty *GetScaleMethod();
    HPointerProperty *GetScaleBone();

    //Traversal
    HActionCacheContainer *GetParentActionCacheContainer();
    HChor *GetChor();
    HActionCache *GetSiblingActionCache(); //use this over GetSibling because ActionCaches get moved if the Action is currently being edited with a model

    //Operations
    HModelCache *GetDefaultModelCache();
    void SetDefaultModelCache(const char *name);
    void SetDefaultModelCache(HModelCache *mch);
    Time GetTotalTime();
    TimeRange GetPlayRange();
    void SetPlayRange(const TimeRange &playrange);
    HActionCache *BakeUnconstrainedAction(HModel *mih, float errortolerance); //same as above, just a shorter name.
    HPropertyDriver *CreateStorageDriver(HProperty *var);
    float GetScaleFactor();
    float GetScaleStandard();

    //HActionCache Creation
    static HActionCache *New(const char *pname = nullptr, BOOL embedded = TRUE, BOOL insertintoactioncachecontainer = TRUE);

    //HActionCache Editing
    HModel *EditWithModelCache(HModelCache *hmc);
    void EndEditWithModelCache(HModel *hm); //pass in the HModel returned from EditWithModelCache
};

//*********************************************************
//** HChorAction
//*********************************************************
class PLUGINEXPORT HChorAction final : public HActionCache {
public:
    enum BlendMethod : uint8_t { REPLACE, ADD, BLEND };

    HTypeProperty *GetBlendMethod();
};

//KB  5/15/01  \Ken90\Include\SDK\HLayer.h
#pragma once

#include "HModel.h"

class HLayer;

//*********************************************************
//** HLayerCache
//*********************************************************
class PLUGINEXPORT HLayerCache final : public HModelCache {
public:
    static HLayerCache *New(const char *name = nullptr, HClip *clip = nullptr, int width = 0, int height = 0);
    HLayer *NewInstance(HChor *chor);
    //Properties
};

//*********************************************************
//** HLayer
//*********************************************************
class PLUGINEXPORT HLayer final : public HModel {
//public:
    //Properties
};

/*
  Todo 
    Clip stuff
*/

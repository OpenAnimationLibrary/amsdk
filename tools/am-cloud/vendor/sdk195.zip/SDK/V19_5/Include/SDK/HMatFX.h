//Dan  12/17/2001  \Dan90\Include\SDK\HMatFX.h
#pragma once

#include "HFX.h"

//*********************************************************
//** HMatFXCache
//*********************************************************
class PLUGINEXPORT HMatFXCache final : public HFXCache {
//public:
};

//*********************************************************
//** HMatFX
//*********************************************************
class PLUGINEXPORT HMatFX final : public HFX {
public:
    HMatFX *GetNextMatFXInChor(); //Use with HChor::GetChildMatFX()
};

/*
TODO
   MaterialHead
*/

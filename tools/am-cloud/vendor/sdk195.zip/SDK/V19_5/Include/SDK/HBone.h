//BC  12/1/2004  \BobL120\Include\SDK\HBone.h
#pragma once

#include "HPropert.h"

enum RollMethod : uint8_t { Z_SINGULARITY, Y_POLES_SINGULARITY, ROLL_HISTORY }; //TODO check why its doubled

//*********************************************************
//** HBoneCache
//*********************************************************
class PLUGINEXPORT HBoneCache : public HHashObject {
public:
    //Properties
    enum RollMethod : uint8_t { Z_SINGULARITY, Y_POLES_SINGULARITY, ROLL_HISTORY };  // NOLINT(clang-diagnostic-shadow)

    HTypeProperty *GetRollMethod();
    HBoolProperty *GetChained();

    enum : uint8_t { MANIP_STANDARD, MANIP_TRANSLATEONLY, MANIP_ROTATEONLY };

    HTypeProperty *GetManipulationMethod();
    //missing some
    HBoolCategoryProperty *GetLimitManipulators();
    HBoolProperty *GetAllowXTranslate();
    HBoolProperty *GetAllowYTranslate();
    HBoolProperty *GetAllowZTranslate();
    HBoolProperty *GetAllowXScale();
    HBoolProperty *GetAllowYScale();
    HBoolProperty *GetAllowZScale();
    HBoolProperty *GetAllowXRotate();
    HBoolProperty *GetAllowYRotate();
    HBoolProperty *GetAllowZRotate();
    HBoolProperty *GetStop();
    //new way
    HVectorProperty *GetPivot();
    HVectorProperty *GetEnd();
    HRotateProperty *GetRotate(); //maybe needs a better name sets the angle of bone with no motion
    HFloatProperty *GetLength();
    Vector GetRollHandle();

    void SetBoneColor(ColorBuf &color);
    ColorBuf GetBoneColor();

    Vector *GetBounds();

    //Traversal
    HBoneCache *GetSiblingBoneCache();
    HBoneCache *GetChildBoneCache();
    HBoneCache *GetParentBoneCache();

    //Operations
    const Matrix34 &GetBoneToStandard();
    HBone *GetCurrentBone(); //returns the state variable containing the instance currently being drawn.
};

//*********************************************************
//** HBoneCacheContainer
//*********************************************************
class PLUGINEXPORT HBoneCacheContainer final : public HHashObject {
public:
    static HBoneCacheContainer *New();
    HBoneCache *GetChildBoneCache();
};

//*********************************************************
//** HBone
//*********************************************************
class PLUGINEXPORT HBone : public HHashObject {
public:
    //Properties
    HTransformProperty *GetTransform();
    HTypeProperty *GetRollMethod();
    HBoolProperty *GetStop();
    HBoolProperty *GetHidden();

    //Traversal
    HBone *GetSiblingBone();
    HBone *GetChildBone();
    HBone *GetParentBone();
    HBoneCache *GetBoneCache();

    Vector GetPivot();
    Vector GetEnd();
    void SetPivot(Vector &newpivot);
    void SetEnd(Vector &newend);

    Matrix34 GetLocalMatrix();
    Matrix34 GetGlobalMatrix();
    void GetLocalTSQ(Vector &translate, Vector &scale, Quaternion &quat);
    void GetLocalTSE(Vector &translate, Vector &scale, RotateEuler &re);

    void ComputeBoneDirections(Vector &bonedir, Vector &rolldir, Vector &parentbonedir, Vector &parentrolldir);
    const Matrix34 &GetStandardToAction();

    void SetLocalMatrix(Time time, const Matrix34 &matrix);
    void SetLocalTSQ(Time time, const Vector &translate, const Vector &scale, const Quaternion &quat);
    void SetLocalTSE(Time time, const Vector &translate, const Vector &scale, const RotateEuler &re);

    Vector *GetBounds(); //Vector        bounds[8];
    const Matrix34 &GetBoneToStandardMatrix();
    const Matrix34 &GetStandardToBoneMatrix();
    const Matrix34 &GetModelToWorldMatrix();
    const Matrix34 &GetWorldToModelMatrix();
    const Matrix34 &GetModelToScreenMatrix();
    const Matrix34 &GetScreenToModelMatrix();
};

//*********************************************************
//** HBoneContainer
//*********************************************************
class PLUGINEXPORT HBoneContainer final : public HHashObject {
public:
    HBone *GetChildBone();
};

//KNC  9/18/2005  \V130\Include\SDK\HRenderIn.h
#pragma once

#include "HHashobj.h"// IWYU pragma: keep

//*********************************************************
//** HRenderInfo
//*********************************************************
class PLUGINEXPORT HRenderInfo final {
public:
    BOOL IsShaded();
    BOOL IsWireframe();
    BOOL IsPerspective();
    BOOL IsShowBackfacing();

    void SetShaded(BOOL state);
    void SetWireframe(BOOL state);
    void SetPerspective(BOOL state);
    void SetShowBackfacing(BOOL state);

    int GetPatchSubdivisions();
    void SetPatchSubdivisions(int subdivisions);
    float GetStraight();
    void SetStraight(float straight);
};

HRenderInfo *GetHRenderInfo();

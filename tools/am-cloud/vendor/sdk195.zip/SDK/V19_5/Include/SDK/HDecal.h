//Dan  4/5/2004  \DanLP110\Include\SDK\HDecal.h
#pragma once

#include "HPropert.h"
#include "HImage.h"

//*********************************************************
//** HBitmap
//*********************************************************
class PLUGINEXPORT HBitmap : public HClip {
//public:
};

//*********************************************************
//** HDecalClip
//*********************************************************
class PLUGINEXPORT HDecalClip final : public HHashObject {
public:
    enum DecalMapType : uint8_t {
        OPAQUEMAP,
        TRANSPARENCYMAP,
        BUMPMAP,
        SPECULARSIZEMAP,
        SPECULARINTENSITYMAP,
        DIFFUSEMAP,
        MIRRORMAP,
        AMBIANCEMAP,
        COOKIECUTMAP,
        DISPLACEMENTMAP,
        FRACTALMAP,
        NEXTMAPFACTORMAP,
        OTHERMAP,
        NORMALMAP,
        OLDBUMPMAP,
        REFLECTIONMAP
    };


    enum : uint8_t {
        REFERENCEORIGINAL,
        INCLUDEINPATCHMAPS
    };

    HClipProperty *GetClip();
    HTypeProperty *GetKind();
    HFloatProperty *GetPercent();
    HTypeProperty *GetExportType();
    //  include HPropert.h
};

//*********************************************************
//** HDecalClipContainer
//*********************************************************
class PLUGINEXPORT HDecalClipContainer final : public HHashObject {
public:
    HDecalClip *GetChildDecalClip();
};

//*********************************************************
//** HBasePatchUV
//*********************************************************
class PLUGINEXPORT HBasePatchUV : public HAnimObject {
public:
    HPatch *GetPatch();
    BOOL IsPatch5UV();

    void SetUVs(Vector uvs[]);
    void GetUVs(Vector uvs[]);
};

//*********************************************************
//** HPatchUV
//*********************************************************
class PLUGINEXPORT HPatchUV final : public HBasePatchUV {
//public:
};

//*********************************************************
//** HPatch5UV
//*********************************************************
class PLUGINEXPORT HPatch5UV final : public HBasePatchUV {
//public:
};

//*********************************************************
//** HDecalStamp
//*********************************************************
class PLUGINEXPORT HDecalStamp final : public HHashObject {
public:
    /*
     4 point       5 point
    
     0 1 2 3          00
    11     4        14  01
    10     5      13      02
     9 8 7 6    12          03
                11          04
                10          05
                09  08  07  06
    */
    HBasePatchUV *AddPatchUV(HPatch *hpatch, Vector uvs[]); //12 uv's for HPatch, 15 uv's for HPatch5
    HBasePatchUV *GetFirstPatchUV();
    HBasePatchUV *GetNextPatchUV(HBasePatchUV *patchuv);
};

//*********************************************************
//** HDecalStampContainer
//*********************************************************
class PLUGINEXPORT HDecalStampContainer final : public HHashObject {
public:
    HDecalStamp *GetChildDecalStamp();
};

class HDecalContainer;

//*********************************************************
//** HDecal
//*********************************************************
class PLUGINEXPORT HDecal final : public HBitmap {
public:
    HDecalClip *AddDecalClip(HClip *clipcache = nullptr);
    HDecalStamp *AddDecalStamp();

    //Traversal
    HDecalClipContainer *GetChildDecalClipContainer();
    HDecalStampContainer *GetChildDecalStampContainer();
};

//*********************************************************
//** HDecalContainer
//*********************************************************
class PLUGINEXPORT HDecalContainer final : public HHashObject {
public:
    HDecal *GetChildDecal();
};

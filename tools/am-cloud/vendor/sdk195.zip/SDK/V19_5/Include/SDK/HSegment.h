//BC  12/6/2003  \HBob110\Include\SDK\HSegment.h
#pragma once

#include "HObject.h"
#include "HCP.h"// IWYU pragma: keep

class HGroupCP;

//*********************************************************
//** HSegmentCache
//*********************************************************
class PLUGINEXPORT HSegmentCache : public HObjectCache {
public:
    //Creation
    static HSegmentCache *New(const char *name = nullptr);

    BOOL OnDelete();

    HBoolProperty *GetBoolCutter();
    HGroupCP *GetGroupCP(); //Group of cps this bone owns
    BOOL AquireCP(HCP *cp);

    //Properties
    //HFloatProperty *GetFallOffRadius();
    //HFloatProperty *GetFallOffEndRadius();
    //HFloatProperty *GetFallOffPivotLength();
    //HFloatProperty *GetFallOffEndLength();
};

//*********************************************************
//** HSegment
//*********************************************************
class PLUGINEXPORT HSegment : public HObject {
//public:
    //Properties
};

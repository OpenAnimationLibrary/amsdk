//Dan  6/16/2004  \DanLP115\Include\SDK\HConstra.h
#pragma once

#include "SDK/HPropDri.h"

class PLUGINEXPORT HConstraint : public HPropertyDriver {
public:
    HPercentProperty *GetEnforcement();
    HBoolProperty *GetIsBeforeAction();
    HBoolProperty *GetLockOffsets();
    HPointerProperty *GetTarget1(); //for HOneTargetConstraints
    HPointerProperty *GetTarget2(); //for HTwoTargetConstraints
};

class PLUGINEXPORT HOneTargetConstraint : public HConstraint {
public:
    HTimeProperty *GetLag();
    HPointerProperty *GetBone();
};

class PLUGINEXPORT HTwoTargetConstraint : public HOneTargetConstraint {
public:
    HPointerProperty *GetBone2();
};

class PLUGINEXPORT HAimAtConstraint : public HOneTargetConstraint {
public:
    static HAimAtConstraint *New();
    HBoolProperty *GetScaleToReach();
    HBoolProperty *GetScaleZOnly();
    HRotateProperty *GetRotateOffset();
    HTranslateProperty *GetTranslateOffset();
};

class PLUGINEXPORT HKinematicConstraint final : public HAimAtConstraint {
public:
    static HKinematicConstraint *New();
    HBoolCategoryProperty *GetSupportLimitsDamping();
    HBoolProperty *GetComputeRoll();
    HBoolProperty *GetStoreHints();
};

class PLUGINEXPORT HOrientLikeConstraint final : public HOneTargetConstraint {
public:
    static HOrientLikeConstraint *New();
    HBoolProperty *GetIsStoreRoll();
    HRotateProperty *GetRotateOffset();
};

class PLUGINEXPORT HTranslateToConstraint final : public HOneTargetConstraint {
public:
    static HTranslateToConstraint *New();
    HTranslateProperty *GetTranslateOffset();
};

class PLUGINEXPORT HEulerLimits final : public HConstraint {
public:
    static HEulerLimits *New();
    HVectorProperty *GetMinEuler();
    HVectorProperty *GetMaxEuler();
    HFloatProperty *GetIKDamping();
};

class PLUGINEXPORT HSphericalLimits final : public HConstraint {
public:
    static HSphericalLimits *New();
    HVectorProperty *GetMinSphere();
    HVectorProperty *GetMaxSphere();
    HFloatProperty *GetIKDamping();
};

class PLUGINEXPORT HTranslateLimits final : public HConstraint {
public:
    static HTranslateLimits *New();
    HTranslateProperty *GetMinTranslate();
    HTranslateProperty *GetMaxTranslate();
};

class PLUGINEXPORT HRollLikeConstraint final : public HOneTargetConstraint {
public:
    static HRollLikeConstraint *New();
    HFloatProperty *GetRollOffset();
    HFloatProperty *GetRollScale();
};

class PLUGINEXPORT HAimRollAtConstraint final : public HOneTargetConstraint {
public:
    static HAimRollAtConstraint *New();
    HTranslateProperty *GetTranslateOffset();
    HFloatProperty *GetRollOffset();
};

class PLUGINEXPORT HPathConstraint final : public HConstraint {
public:
    static HPathConstraint *New();
    HTimeProperty *GetLag();
    HPointerProperty *GetSplineInstance(); //returns an HSplineInstance
    HBoolProperty *GetIsTranslateOnly();
    HBoolProperty *GetIsStoreRoll();
    HPercentProperty *GetEase();
    HTranslateProperty *GetTranslateOffset();
    HRotateProperty *GetRotateOffset();
};

class PLUGINEXPORT HScaleLikeConstraint final : public HOneTargetConstraint {
public:
    static HScaleLikeConstraint *New();
    HFloatProperty *GetScaleScale();
    HFloatProperty *GetScaleOffset();
};

class PLUGINEXPORT HAimRollLikeTwoConstraint final : public HTwoTargetConstraint //v15d
{
public:
    static HAimRollLikeTwoConstraint *New();
    HTranslateProperty *GetTranslateOffset();
    HTranslateProperty *GetTranslateOffset2();
};

class PLUGINEXPORT HAimLikeTwoConstraint final : public HTwoTargetConstraint //v15d
{
public:
    static HAimLikeTwoConstraint *New();
    HTranslateProperty *GetTranslateOffset();
    HTranslateProperty *GetTranslateOffset2();
};

class PLUGINEXPORT HSurfaceConstraint final : public HTwoTargetConstraint //v15d
{
public:
    static HSurfaceConstraint *New();
    HTranslateProperty *GetTranslateOffset();
    HRotateProperty *GetRotateOffset();
    HBoolProperty *GetIsTranslateOnly();
};

class PLUGINEXPORT HBulletConstraint final : public HConstraint {
public:
    static HBulletConstraint *New(HModel *hm); //must have a model instance at construction time, for adding the constraint to the model
    //Attention can return a nullptr , ifthe model have a BulletConstraint or a BulletSoftConstraint
    HTypeCategoryProperty *GetShapeHull();
    HFloatProperty *GetWeight();
    HFloatProperty *GetBounce();
    HFloatProperty *GetFriction();
    HFloatProperty *GetRollingFriction();
    HFloatProperty *GetSpinningFriction();
    HFloatProperty *GetLinearDamping();
    HFloatProperty *GetAngularDamping();
    HFloatProperty *GetMargin();
    HFloatProperty *GetDensity();
    HBoolProperty *GetAnisotropicFriction();
    void CalculateWeight(); //calculate the weight from the given density and the model volume
};

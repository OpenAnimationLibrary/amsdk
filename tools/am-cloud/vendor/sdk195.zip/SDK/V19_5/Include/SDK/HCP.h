﻿//BC  12/1/2004  \BobL120\Include\SDK\HCP.h
#pragma once

#include "HHashobj.h"
#include "CPInterp.h"

class HTranslatePropertyNoSubs;
class HBiasProperty;
class HCPInstance;
class HSpline;
class HGroupCP;
class HDecalClip;
class HSegmentCache;
class HCPWeight;

//*********************************************************
//** HCP
//*********************************************************
class PLUGINEXPORT HCP : public HAnimObject {
public:
    const Vector *GetPosition(); //Position of the CP, includes Muscle, and pose motion, but no Skeletal
    const Vector *GetModelPosition(); //Position of the CP with no motion, raw model data
    const Vector *GetWorldPosition(); //Position of the CP completely transformed
    const Vector *GetScreenPosition(); //Position of the CP completely transformed in world style coordinated, but facing the camera
    HCPInstance *GetCPInstance();
    HCPInstance *CreateCPInstance(); //will return the instance if it already exists
    HSpline *GetSpline();
    HCP *GetNext();
    HCP *GetPrev();
    float GetInGamma();
    float GetInAlpha();
    float GetInMagnitude();
    float GetOutGamma();
    float GetOutAlpha();
    float GetOutMagnitude();
    float GetDistance(HCP *nextcp = nullptr); //calculates the distance to the given cp, if nullptr up to the next cp
    Vector GetInTangent();
    Vector GetOutTangent();
    Vector GetModelInTangent();
    Vector GetModelOutTangent();
    Vector GetWorldInTangent();
    Vector GetWorldOutTangent();
    Vector GetScreenInTangent();
    Vector GetScreenOutTangent();
    HCP *GetNextAttached();
    HCP *GetPrevAttached();
    HCP *GetHead();
    HCPWeight *GetCPWeightHead(); //if walking through all cps should only be called when hcp == hcp->GetHead()
    BOOL AddToGroup(HGroupCP **gh);
    BOOL AddStackToGroup(HGroupCP **gh);
    void SetPosition(Vector *p); //Sets the model position
    void SetInGamma(float fValue);
    void SetInAlpha(float fValue);
    void SetInMagnitude(float fValue);
    void SetOutGamma(float fValue);
    void SetOutAlpha(float fValue);
    void SetOutMagnitude(float fValue);
    void SetPeaked();
    void SetBiasedNormal(BOOL bBiased);
    void SetSmooth();
    void SetHide(BOOL bHide);
    void ComputeInBias(const Vector &goalit, float &alpha, float &gamma, float &magnitude);
    void ComputeOutBias(const Vector &goalot, float &alpha, float &gamma, float &magnitude);
    uint32_t GetID();
    HCPWeight *AddCPWeight(); //adds a new cpweight to the head cp
    void RemoveCPWeight(HCPWeight *hcpweight); //frees handle
    //flags
    BOOL IsLoop();
    BOOL IsPeaked();
    BOOL IsSmooth();
    BOOL IsHook();
    BOOL IsFlip();
    BOOL IsHide();
    BOOL IsGroup();
    BOOL IsLocked();
    BOOL IsEndHook();
    BOOL IsHookBase();
    HSegmentCache *GetSegmentCache(); //returns the primary owner of this control point
};

//*********************************************************
//** HHookCP
//*********************************************************
class PLUGINEXPORT HHookCP final : public HCP {
public:
    float GetS();
};

//*********************************************************
//** HCPShortcut
//*********************************************************
class PLUGINEXPORT HCPShortcut final : public HAnimObjectShortcut {
public:
    uint32_t GetCPID();
    BOOL CanCompactForSaving();
};

//*********************************************************
//** HCPInstance
//*********************************************************
class PLUGINEXPORT HCPInstance final : public HAnimObject {
public:
    HBiasProperty *GetInBias();
    HBiasProperty *GetOutBias();
    HTranslatePropertyNoSubs *GetPosition();
    HCP *GetCP();
};

class PLUGINEXPORT HGroupCP final : public HHashObject {
public:
    HGroupCP *GetNext();
    HCP *GetCP();
    //creation
    static HGroupCP *New();
    void Delete();
};

class HDecalClipContainer;
class HAttrProperty;
class HClip;

//*********************************************************
//** HGroup
//*********************************************************
class PLUGINEXPORT HGroup final : public HHashObject {
public:
    //Properties
    HAttrProperty *GetAttr();
    HGroupCP *GetGroupCP();
    Matrix34 *GetMatrix();
    BOOL IsTempGroup();
    void SetTempGroup(BOOL istemp);

    BOOL AddCP(HCP *cp);
    BOOL RemoveCP(HCP *cp);

    HDecalClipContainer *GetChildDecalClipContainer();
    BOOL IsPatchInGroup(HPatch *patch);
    BOOL IsCPInGroup(HCP *hcp);

    HDecalClip *CreateGroupDecal(HClip *clipcache = nullptr); //Will prompt if nullptr
    void RotateGroupImages();
    int GetPatchCount();
};

//*********************************************************
//** HGroupContainer
//*********************************************************
class PLUGINEXPORT HGroupContainer final : public HHashObject {
public:
    HGroup *GetChildGroup();
};

//*********************************************************
//** HChannelCP
//*********************************************************
class PLUGINEXPORT HChannelCP final {
public:
    void operator delete(void *ptr) noexcept {  // NOLINT(misc-new-delete-overloads)
        DeleteHandle((HChannelCP *)ptr);
    }

    static void DeleteHandle(HChannelCP *handle);

    CPInterpolationMethod GetInterpolationMethod();
    void SetInterpolationMethod(CPInterpolationMethod method);

    //Traversal
    HChannelCP *GetNext();

    //Operations
    float GetInGamma();
    float GetInMagnitude();
    float GetOutGamma();
    float GetOutMagnitude();
    void SetInGamma(float fValue);
    void SetInMagnitude(float fValue);
    void SetOutGamma(float fValue);
    void SetOutMagnitude(float fValue);
    void SetBias(const Vector2 &goalit, const Vector2 &goalot);
    BOOL IsPeaked();
    BOOL IsSmooth();
    Time GetTime();
    [[nodiscard]] float GetValue() const;
    Vector2 GetInTangent();
    Vector2 GetOutTangent();
};

﻿//BC  11/12/2004  \BobL115\Include\SDK\Entry.h
#pragma once

#ifndef __AM_SDK
#define __AM_SDK
#endif
#ifndef _STDINT
#include "stdint.h"
#endif

enum MenuCategory : uint8_t {
    MC_GENERAL,
    MC_EXPORT,
    MC_IMPORT,
    MC_WIZARD,
    MC_PLUGINOBJECT
};

/* Command Entry Point Functions
extern "C" __declspec(dllexport) BOOL HxtLoadCommandEntry(uint32_t index, ObjectType &);
extern "C" __declspec(dllexport) BOOL HxtOnAddCommandMenu(HTreeObject *htreeobject, uint32_t index, String &menuname, MenuCategory &mc, BOOL &disabled);
extern "C" __declspec(dllexport) BOOL HxtOnCommand(HTreeObject *htreeobject, uint32_t index);
*/

/* Property Entry Point Functions
extern "C" __declspec(dllexport) BOOL HxtLoadPropertyEntry(uint32_t index, ObjectType &);
extern "C" __declspec(dllexport) HProperty *HxtOnAddProperties(HTreeObject *htreeobject, HCategoryProperty *pluginproperty, uint32_t index );
*/

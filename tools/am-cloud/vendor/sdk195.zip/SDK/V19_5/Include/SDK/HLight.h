//Dan  12/9/2002  \Dan100\Include\SDK\HLight.h
#pragma once

#include "HVolFX.h"

class HLight;
class HLightCache;

//*********************************************************
//** HLightListNode
//*********************************************************
class PLUGINEXPORT HLightListNode final : public HHashObject {
public:
    HLight *GetLight();
    HLightListNode *GetNextLightListNode();
};

//*********************************************************
//** HLightCacheContainer
//*********************************************************
class PLUGINEXPORT HLightCacheContainer final : public HHashObject {
public:
    HLightCache *GetChildLightCache();
};

//*********************************************************
//** HLightCache
//*********************************************************
class PLUGINEXPORT HLightCache final : public HVolFXCache {
public:
    HFloatProperty *GetIntensity();
    HBoolProperty *GetDiffuse();
    HBoolProperty *GetSpecular();
    HBoolCategoryProperty *GetVolumetric();
    HBoolCategoryProperty *GetCastShadows();

    enum : uint8_t { RAYTRACED, ZBUFFERED };

    HTypeProperty *GetShadowType();
    HIntProperty *GetShadowRaysCast();
    HFloatProperty *GetShadowRayBias();
    HFloatProperty *GetShadowMapSoftness();
    HFloatProperty *GetShadowMapDarkness();
    HColorProperty *GetShadowMapTint();

    enum : uint8_t { SM_256, SM_512, SM_1024, SM_2048 };

    HTypeProperty *GetShadowMapRes();
    HFloatProperty *GetShadowMapBias();
    //HLensFlareProperty *GetLensFlare();
    HFileInfoProperty *GetFileInfo();
};

//*********************************************************
//** HLightContainer
//*********************************************************
class PLUGINEXPORT HLightContainer final : public HHashObject {
public:
    HLight *GetChildLight();
};

//*********************************************************
//** HLight
//*********************************************************
class PLUGINEXPORT HLight final : public HVolFX {
public:
    HFloatProperty *GetIntensity();
    HBoolProperty *GetDiffuse();
    HBoolProperty *GetSpecular();
    HBoolCategoryProperty *GetVolumetric();
    HBoolCategoryProperty *GetCastShadows();
    HIntProperty *GetShadowRaysCast();
    HFloatProperty *GetShadowRayBias();
    HFloatProperty *GetShadowMapSoftness();
    HFloatProperty *GetShadowMapDarkness();
    HColorProperty *GetShadowMapTint();
    HTypeProperty *GetShadowMapRes();
    HFloatProperty *GetShadowMapBias();
    //HLensFlareProperty *GetLensFlare();
    HBoolProperty *GetLightAll();
    HLight *GetNextLightInChor(); //use with HChor::GetChildLight()
};

/*
TODO
   Rotoscope
   Material
   Lensflare
*/

//NAP  12/20/2004  \Noel120\Include\SDK\HImage.h
#pragma once

//*********************************************************
//** HCPWeight
//*********************************************************
class PLUGINEXPORT HCPWeight final {
public:
    HSegmentCache *GetSegmentCache();
    void SetSegmentCache(HSegmentCache *segmentcache);
    float GetWeight();
    void SetWeight(float weight);
    HCPWeight *GetNext();
};

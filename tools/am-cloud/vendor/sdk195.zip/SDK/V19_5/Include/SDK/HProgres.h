//KB  5/15/01  \Ken90\Include\SDK\HProgres.h
//*********************************************************
//** HProgressBar
//*********************************************************
#pragma once

class PLUGINEXPORT HProgressBar final {
public:
    BOOL Initialize();
    void Uninitialize();
    void SetProgressRange(int iLow, int iHight);
    void SetMessage1(const char *msg);
    void SetMessage2(const char *msg);
    void SetProgress(int iPos);
};

PLUGINEXPORT HProgressBar *GetProgressBar();

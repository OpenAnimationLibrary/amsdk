//Dan  3/29/2004  \DanLP110\Include\SDK\HProject.h
#pragma once

#include "HHashobj.h"

class HModelCache;
class HSoundCache;
class HClip;

//*********************************************************
//** HObjectCacheContainer
//*********************************************************
class PLUGINEXPORT HObjectCacheContainer : public HHashObject {
public:
    HModelCache *GetChildModelCache();
};

//*********************************************************
//** HClipCacheContainer
//*********************************************************
class PLUGINEXPORT HClipCacheContainer final : public HHashObject {
public:
    BOOL BrowseClip(String &filename, bool *issequence); //Opens File Dialog
    HClip *CreateClip(const String &filename, BOOL issequence); //Loads file
};

//*********************************************************
//** HMaterialCacheContainer
//*********************************************************
class PLUGINEXPORT HMaterialCacheContainer final : public HObjectCacheContainer {
//public:
};

class HActionCache;

//*********************************************************
//** HActionCacheContainer
//*********************************************************
class PLUGINEXPORT HActionCacheContainer final : public HObjectCacheContainer {
public:
    HActionCache *GetChildActionCache(); //use this over GetChild because ActionCaches get moved if the Action is currently being edited with a model
};

//*********************************************************
//** HActionShortcutContainer
//*********************************************************
class HActionShortcutContainer final : public HObjectCacheContainer {
//public:
};

//*********************************************************
//** HSoundContainer
//*********************************************************
class PLUGINEXPORT HSoundContainer final : public HHashObject {
public:
    HSoundCache *GetChildSoundCache();
};

class HChor;

//*********************************************************
//** HChorContainer
//*********************************************************
class PLUGINEXPORT HChorContainer final : public HObjectCacheContainer {
public:
    HChor *GetChildChor();
};

//*********************************************************
//** HProject
//*********************************************************
class PLUGINEXPORT HProject final : public HHashObject {
public:
    float GetFPS();
    float SetFPS(int newfps, BOOL storeundo); //returns the old fps
    HObjectCacheContainer *GetChildObjectCacheContainer();
    HClipCacheContainer *GetChildClipCacheContainer();
    HMaterialCacheContainer *GetChildMaterialCacheContainer();
    HActionCacheContainer *GetChildActionCacheContainer();
    HChorContainer *GetChildChorContainer();
    HClip *AddClip(const String &filename, BOOL issequence);

    void DeselectAll();
    void SetTime(Time time);
    void UpdateAllViews(BOOL force = FALSE);
    void ReloadImages(); //reload all images in the imagecontainer , rebuild icons and real time textures
    String GetFileName();
    BOOL IsLoadingProject(); //returns TRUE when the project is loading , resolve the problem of too much calls to UpdateViews for tweaked simbiont materials #0006717
};

//Retrieval
PLUGINEXPORT HProject *GetHProject();

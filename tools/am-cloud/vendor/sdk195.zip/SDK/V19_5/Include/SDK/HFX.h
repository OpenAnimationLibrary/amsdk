//KB  5/15/01  \Ken90\Include\SDK\HFX.h
#pragma once

#include "HObject.h"

//*********************************************************
//** HFXCache
//*********************************************************
class PLUGINEXPORT HFXCache : public HObjectCache {
public:
    enum : uint8_t { SPHERE, CONE, BOX, CYLINDER };

    HTypeProperty *GetType();
    HFloatProperty *GetWidth();
    HPercentProperty *GetWidthSoftness();
    HFloatProperty *GetFalloff();
    HPercentProperty *GetFalloffSoftness();
    HFloatProperty *GetConeAngle();
};

//*********************************************************
//** HFX
//*********************************************************
class PLUGINEXPORT HFX : public HObject {
public:
    HFloatProperty *GetWidth();
    HPercentProperty *GetWidthSoftness();
    HFloatProperty *GetFalloff();
    HPercentProperty *GetFalloffSoftness();
    HFloatProperty *GetConeAngle();
};

﻿//Dan  6/12/2003  \Dan105\Include\SDK\HCamera.h
#pragma once

#include "HObject.h"

//*********************************************************
//** HCameraCache
//*********************************************************
class PLUGINEXPORT HCameraCache final : public HObjectCache {
public:
    enum CAMERATYPE : uint8_t { CT_ORTHOGONAL, CT_PERSPECTIVE};

    //Properties
    HTypeProperty *GetType();
    HColorProperty *GetBackGroundColor();
    HFloatProperty *GetFocalLength();
    HFloatProperty *GetFocalDistance();
    HFloatProperty *GetGlobalAmbiance();
};

//*********************************************************
//** HCamera
//*********************************************************
class PLUGINEXPORT HCamera final : public HObject {
public:
    //Properties
    HColorProperty *GetBackGroundColor();
    HFloatProperty *GetFocalLength();
    HFloatProperty *GetFocalDistance();
    HFloatProperty *GetGlobalAmbiance();
    HCamera *GetNextCameraInChor(); //Use With HChor::GetChildCamera
};

//TODO
//BitFields
//RenderSettings - Cache
//OutputSettings - Instance
//Rotoscope/Fog Rotoscope
//Camera Type

//BC  11/30/2004  \BobL120\Include\SDK\HChor.h
#pragma once

#include "HHashobj.h"

class HModel;
class HProp;
class HCamera;
class HForce;
class HMatFX;
class HMCDevice;
class HLightListNode;
class HChorContainer;
class HFileInfoProperty;
class HTimeProperty;
class HVectorProperty;
class HIntProperty;
class HFloatProperty;
class HBoolProperty;
class HGroup;

//*********************************************************
//** HChor
//*********************************************************
class PLUGINEXPORT HChor final : public HHashObject {
public:
    //Creation
    static HChor *New();

    //Properties
    HFileInfoProperty *GetFileInfo();
    HTimeProperty *GetTotalTime();
    HVectorProperty *GetForce();
    HIntProperty *GetRigidSubSamples();
    HFloatProperty *GetRigidDrag();
    HBoolProperty *GetDisplayWhileSimulating();

    //Operations
    void CreateFrame(Time time);
    void Dirty();
    Time GetTime();
    void SetTime(Time time);
    void SetTimeWithSound(Time time);
    TimeRange GetPlayRange();
    void SetPlayRange(const TimeRange &playrange);
    void OpenView(int viewmode = 0); //open a new view , if no view for exists and set the view to the selected mode
    //FRONTVIEW   0
    //BACKVIEW    1
    //LEFTVIEW    2
    //RIGHTVIEW   3
    //TOPVIEW     4
    //BOTTOMVIEW  5

    //Traversal
    HChorContainer *GetParentChorContainer();
    HModel *GetChildModel();
    HProp *GetChildProp();
    HCamera *GetChildCamera();
    HForce *GetChildForce();
    HMatFX *GetChildMatFX();
    HMCDevice *GetChildMCDevice();
    HLightListNode *GetHeadLightList();
    HLightListNode *GetHeadAllLightList();

    //Export IEModel classes
    IEPatchModel *BuildExportModel(IEModelParms *iemp, Time time, const char *modelmapfilename);
    IEPolyModel *BuildExportModel(IEPolyModelParms *iemp, Time time, const char *modelmapfilename);
    IEPolyModel *BuildExportModel(IEPolyModelParms *iemp, Time time, const char *modelmapfilename, HModel *hmodel);
    IEPolyModel *BuildExportModel(IEPolyModel *imodel, IEPolyModelParms *iemp, Time time, const char *modelmapfilename, HModel *hmodel);
    IEPolyModel *BuildExportModel(IEPolyModelParms *iemp, HModel *hmodel, HGroup *hgroup, BOOL markpatchesinvisible, VertexInfo *vertexinfo);

    BOOL Intersect(Vector &p, Vector &d, Vector &hitp, Vector &hitn, float maxdist, float flatness);

    //for plugins like e_rebuild with many Intersect calls and not changing the models or chor between Intersect_Init and Intersect_Exit
    void MultIntersect_Init(float flatness, PVOID &oldrinfo, PVOID &newrinfo, PVOID &thread);
    BOOL MultIntersect(Vector &p, Vector &d, Vector &hitp, Vector &hitn, float maxdist, PVOID thread);
    void MultIntersect_Exit(PVOID oldrinfo, PVOID newrinfo, PVOID thread);
};

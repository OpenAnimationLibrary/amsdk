//NAP  12/20/2004  \Noel120\Include\SDK\HImage.h
#pragma once

#include "HHashobj.h"
#include "ColorBuf.h"
#include "ColorVec.h"

class BitmapNode;
class HFilenameProperty;
class HColorProperty;
class HFloatProperty;
class HBoolProperty;
class HIntProperty;

//*********************************************************
//** HClip
//*********************************************************
class PLUGINEXPORT HClip : public HHashObject {
public:
    int GetWidth();
    int GetHeight();
    int GetWidth(float repeat);
    int GetHeight(float repeat);
    ColorBuf GetBKColor();
    BOOL ReadBitmap(float x, float y, RGBFloat *diffuse, float *opacity, float pixelwidth, Time time, const Vector2 &repeat, BOOL isseamless);
    /* don't use this one anymore, just for old plugins*/
    BOOL ReadBitmap(float x, float y, ColorVector *diffuse, float *opacity, float pixelwidth, Time time, const Vector2 &repeat, BOOL isseamless);

    BOOL ReadBumpmap(float x, float y, Vector2 &delta, float pixelwidth, Time time, const Vector2 &repeat, BOOL isseamless);
    BOOL ReadBumpmap(float x, float y, Vector2 &delta, float pixelwidth, Time time, const Vector2 &repeat, BOOL isseamless, BOOL wrapx, BOOL wrapy);
};

//*********************************************************
//** HImage
//*********************************************************
class PLUGINEXPORT HImage : public HClip {
public:
    HFilenameProperty *GetFilename();
    HColorProperty *GetKeyColor();
    HFloatProperty *GetGamma();
    BitmapNode *GetBitmapNode();
};

//*********************************************************
//** HStill
//*********************************************************
class PLUGINEXPORT HStill final : public HImage {
//public:
};

//*********************************************************
//** HAnimation
//*********************************************************
class PLUGINEXPORT HAnimation final : public HImage {
public:
    HIntProperty *GetCropStart();
    HIntProperty *GetCropEnd();
    HFloatProperty *GetFps();
    HIntProperty *GetCacheSize();
};

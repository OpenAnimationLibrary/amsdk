//BC  3/1/2005  \BobL120\Include\SDK\HForce.h
#pragma once

#include "HObject.h"

//*********************************************************
//** HForceCache
//*********************************************************
class PLUGINEXPORT HForceCache final : public HObjectCache {
public:
    enum : uint8_t { F_FAN, F_VORTEX, F_FRICTION };

    HFloatProperty *GetMagnitude();
};

//*********************************************************
//** HForce
//*********************************************************
class PLUGINEXPORT HForce final : public HObject {
public:
    HFloatProperty *GetMagnitude();
    HForce *GetNextForceInChor();
    Vector GetForce(const Vector &pos, const Vector &vel);
};

/*
TODO
TurbNodeHead
Kind
*/

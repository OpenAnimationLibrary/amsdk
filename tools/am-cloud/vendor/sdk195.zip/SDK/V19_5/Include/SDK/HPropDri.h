//Dan  8/4/2004  \DanLP110\Include\SDK\HPropDri.h
#pragma once

#include "HHashobj.h"
#include "SDK/HCP.h"// IWYU pragma: keep
#include "TimeRang.h"

class HAction;
class HActionCache;
class HDriverShortcut;
class HConstraint;

//*********************************************************
//** HPropertyDriver
//*********************************************************
class PLUGINEXPORT HPropertyDriver : public HHashObject {
public:
    HProperty *GetProperty();

    //A Property can have multiple list of Drivers on them coming from different relationships, Actions, or choractions.
    //Use GetNextActionDriver to get a HeadDriver of a property to get to the next header driver of a different
    //Action applied to the property.
    HPropertyDriver *GetNextActionDriver();

    //Use GetNextDriver to walk through all the drivers for all action applied to
    //the property.
    HPropertyDriver *GetNextDriver();

    //GetNextDriverForAction will simply walk all driver applied to the property for
    //the one action
    HPropertyDriver *GetNextDriverForAction();

    //Action this driver came from
    HAction *GetAction();
    HPropertyDriver *GetDriver(); //Gets the actual driver is this is actually a drivershortcut

    BOOL IsSimpleDriverShortcut();
    void SetProperty(HProperty *);
    HDriverShortcut *NewShortcut(HActionCache *);
    int GetNumSubDrivers(); //This is used for Properties like TranslateDriversNoSubs, and BiasDrivers
    HPropertyDriver *GetSubDriverAt(int i); //This is used for Properties like TranslateDriversNoSubs, and BiasDrivers
    HProperty *FindPropertyFromDriver(BOOL cacheok = FALSE);
    HPropertyDriver *MakeCopy();
    void Copy(HPropertyDriver *other);
    void CopyKeys(HPropertyDriver *other, HAction *action = nullptr);

    HConstraint *IsConstraint();
    BOOL IsStorageDriver();

    BOOL AddSelfAppliedDrivers();
};

//*********************************************************
//** HDriverShortcut
//*********************************************************
class PLUGINEXPORT HDriverShortcut : public HPropertyDriver {
public:
    HPropertyDriver *GetDriver();
    HActionCache *GetActionCache();
};

//*********************************************************
//** HRotateDriverShortcut
//*********************************************************
class PLUGINEXPORT HRotateDriverShortcut final : public HDriverShortcut {
public:
    Quaternion GetParentCompensation();
    void SetParentCompensation(Quaternion &quat);

    BOOL HasParentCompensation();
    void SetParentCompensation(BOOL state);
};

//*********************************************************
//** HAttrDriver
//*********************************************************
class PLUGINEXPORT HAttrDriver final : public HPropertyDriver {
public:
    static HAttrDriver *New(HProperty *parent);
};

//*********************************************************
//** HBiasDriver
//*********************************************************
class PLUGINEXPORT HBiasDriver final : public HPropertyDriver {
//public:
};

//*********************************************************
//** HConstDriver
//*********************************************************
class PLUGINEXPORT HConstDriver : public HPropertyDriver {
public:
    static HConstDriver *New(HProperty *parent);
    [[nodiscard]] HProperty *GetValue() const;
};

//*********************************************************
//** HPropertyShortcut
//*********************************************************
class PLUGINEXPORT HPropertyShortcut final : public HPropertyDriver {
public:
    static HPropertyShortcut *New(HProperty *parent);
};

//*********************************************************
//** HFloatDriver
//*********************************************************
class PLUGINEXPORT HFloatDriver : public HPropertyDriver {
public:
    float GetValue(Time time, TimeRange &validrange) const;
    [[nodiscard]] float GetValue(Time time) const;
    void StoreValue(Time time, float value, BOOL storeundo = TRUE);
};

//*********************************************************
//** HChannelDriver
//*********************************************************
class PLUGINEXPORT HChannelDriver final : public HFloatDriver {
public:
    static HChannelDriver *New(HProperty *parent);

    [[nodiscard]] CPInterpolationMethod GetInterpolationMethod() const;
    void SetInterpolationMethod(CPInterpolationMethod method) const;

    [[nodiscard]] ExtrapolationMethod GetPreExtrapolationMethod() const;
    void SetPreExtrapolationMethod(ExtrapolationMethod method) const;

    [[nodiscard]] ExtrapolationMethod GetPostExtrapolationMethod() const;
    void SetPostExtrapolationMethod(ExtrapolationMethod method) const;

    HChannelCP *GetHeadCP();
    HChannelCP *GetTailCP();
    HChannelCP *GetCPFromTime(Time time);

    float GetValue(Time time, TimeRange *validrange = nullptr);
};

//*********************************************************
//** HTimeBasedKey
//*********************************************************
class HTimeProperty;

class PLUGINEXPORT HTimeBasedKey final : public HConstDriver {
public:
    [[nodiscard]] HTimeProperty *GetTime() const;
    [[nodiscard]] HTimeBasedKey *GetNextKey() const;
    [[nodiscard]] HTimeBasedKey *GetPrevKey() const;
};

//*********************************************************
//** HTimeBasedDriver
//*********************************************************
class PLUGINEXPORT HTimeBasedDriver final : public HPropertyDriver {
public:
    [[nodiscard]] HTimeBasedKey *GetFirstKeyObject() const;
    [[nodiscard]] HTimeBasedKey *GetLastKeyObject() const;
    //    HTimeBasedKey *GetKeyFromTime(Time time); // Todo
};

//*********************************************************
//** HRelationMDShortcut
//*********************************************************
class PLUGINEXPORT HRelationMDShortcut final : public HPropertyDriver {
//public:
};

//*********************************************************
//** HExpression
//*********************************************************
class PLUGINEXPORT HExpression final : public HPropertyDriver {
public:
    enum : uint8_t {
        OK,
        CANTTOKENIZE,
        NORIGHTPARENTHESIS,
        UNKNOWNSYMBOL,
        DIVISIONBYZERO,
        NOLEFTPARENTHESIS,
        NOCOMMA,
        OUTOFRANGE,
        MUSTBEFLOAT,
        BADTYPESFORADD,
        BADTYPESFORMULTIPLY,
        INCORRECTTYPE,
        MUSTBETIME,
        BADTYPESFORCOMPARE,
        BADTYPESFORAND,
        BADTYPESFOROR,
        BADTYPEFORNOT,
        MUSTBEBOOL,
        MUSTBEVECTOR,
        MISSINGPARAMETER,
        MUSTBETRANSFORM
    }; //error codes

    static HExpression *New(HProperty *parent); //V15d
    [[nodiscard]] String GetExpressionString() const;
    int SetExpressionString(const String &str); //returns error code
};

//*********************************************************
//** HRotateDriver
//*********************************************************
class PLUGINEXPORT HRotateDriver : public HPropertyDriver {
public:
    void ComputeBoneDirections(Vector &bonedir, Vector &rolldir, Vector &parentbonedir, Vector &parentrolldir) const; //Obsolete
    void ComputeBoneToParent(const Vector &bonedir, const Vector &rolldir, const Vector &parentbonedir, const Vector &parentrolldir) const; //Obsolete

    [[nodiscard]] Quaternion GetBoneToParent() const;
    void SetBoneToParent(const Quaternion &quat);

    [[nodiscard]] Quaternion GetParentToBone() const;
    void SetParentToBone(const Quaternion &quat);

    Quaternion GetValue(Time time, TimeRange &validrange) const;
    [[nodiscard]] Quaternion GetValue(Time time) const;
    void StoreValue(Time time, Quaternion &quat, BOOL storeundo = TRUE);
};

//*********************************************************
//** HEulerRotateDriver
//*********************************************************
class PLUGINEXPORT HEulerRotateDriver final : public HRotateDriver {
public:
    static HEulerRotateDriver *New(HProperty *parent);
    RotateEuler GetValue(Time time, TimeRange &validrange) const;
    [[nodiscard]] RotateEuler GetValue(Time time) const;
    void StoreValue(Time time, RotateEuler &value, BOOL storeundo = TRUE);

    HFloatDriver *GetX();
    HFloatDriver *GetY();
    HFloatDriver *GetZ();
};

//*********************************************************
//** HQuaternionRotateDriver
//*********************************************************
class PLUGINEXPORT HQuaternionRotateDriver final : public HRotateDriver {
public:
    static HQuaternionRotateDriver *New(HProperty *parent);
    Quaternion GetValue(Time time, TimeRange &validrange) const;
    [[nodiscard]] Quaternion GetValue(Time time) const;
    void StoreValue(Time time, Quaternion &quat, BOOL storeundo = TRUE);

    HFloatDriver *GetX();
    HFloatDriver *GetY();
    HFloatDriver *GetZ();
    HFloatDriver *GetW();
};

//*********************************************************
//** HVectorRotateDriver
//*********************************************************
class PLUGINEXPORT HVectorRotateDriver final : public HRotateDriver {
public:
    static HVectorRotateDriver *New(HProperty *parent);
    RotateVector GetValue(Time time, TimeRange &validrange) const;
    [[nodiscard]] RotateVector GetValue(Time time) const;
    void StoreValue(Time time, RotateVector &value, BOOL storeundo = TRUE);

    HFloatDriver *GetX();
    HFloatDriver *GetY();
    HFloatDriver *GetZ();
    HFloatDriver *GetRoll();
};

//*********************************************************
//** HTransformDriver
//*********************************************************
class PLUGINEXPORT HTransformDriver final : public HPropertyDriver {
public:
    static HTransformDriver *New(HProperty *parent);
};

//*********************************************************
//** HVectorDriverNoSubs
//*********************************************************
class PLUGINEXPORT HVectorDriverNoSubs : public HPropertyDriver {
public:
    static HVectorDriverNoSubs *New(HProperty *parent);
    Vector GetValue(Time time, TimeRange &validrange);
    Vector GetValue(Time time);
};

//*********************************************************
//** HTranslateDriverNoSubs
//*********************************************************
class PLUGINEXPORT HTranslateDriverNoSubs final : public HVectorDriverNoSubs {
public:
    static HTranslateDriverNoSubs *New(HProperty *parent);
};

//*********************************************************
//** HVector2Driver
//*********************************************************
class PLUGINEXPORT HVector2Driver final : public HPropertyDriver {
public:
    static HVector2Driver *New(HProperty *parent);
};

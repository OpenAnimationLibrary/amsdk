//Dan  12/11/2002  \Dan100\Include\SDK\HImage.h
#pragma once

#include "HashTime.h"

class HCamera;

//*********************************************************
//** HPostInfo
//*********************************************************
class PLUGINEXPORT HPostInfo final {
public:
    float GetZ(int x, int y);
    BOOL HasZBuffer();
    Time GetTime();
    String GetFileName();
    HCamera *GetCamera(); //can be nullptr
};

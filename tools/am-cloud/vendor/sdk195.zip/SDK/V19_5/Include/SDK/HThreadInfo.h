//*********************************************************
//** HThreadInfo
//*********************************************************
#pragma once

class PLUGINEXPORT HColors final {
public:
    static HColors *New();

    RGBFloat GetFinalColor();
};

class HHit;

class PLUGINEXPORT HRenderObject final {
public:
    void Normal(HHit *hit, Vector &n, Vector &d);
};

/*
class PLUGINEXPORT HBinNode final : public HRenderObject
{
   Vector    &GetMin();  // don't know how many of these we want to expose.
   Vector    &GetMax();
   HBinNode  *GetChild();
   HBinNode  *GetNextBinNode();
   int        GetNumChildren();

   void Intersect( const Vector &p, const Vector &d, HThreadInfo *hti );
   void Collision( HThreadInfo *hti, Vector &min, Vector &max );
   void Subdivide();
   void MinMax();

   HModel         *GetBinNodeModel();
   HSegment       *GetBinNodeSegment( HBinNode * );
   HObject        *GetBinNodeObject();
   BOOL            IsBoolCutter();
   BOOL            IsEdgeTransparency();
   BOOL            IsCheckCollisions();
   float           GetDisplaceScale();
   HLightListNode *GetLightList();
};
*/

class PLUGINEXPORT HHit final {
public:
    static HHit *New();
    Vector &GetP();
    float GetU();
    float GetV();

    HRenderObject *GetHObject();
};

class PLUGINEXPORT HThreadInfo final {
public:
    BOOL Intersect(const Vector &eye, Vector &d, HHit *hit, float maxdist); //fires a ray, but does not return colors, return value is whether a hit occured.
    float DoRay(float x, float y, HColors *colors, float *transparency, float &z); //fires a ray through a screen pixel, return value is the distance the ray traveled.
    float Trace(const Vector &eye, Vector &d, HColors *colors, float *transparency, HHit *hit); //fires a secondary ray into the scene, return value is the distance the ray traveled.

    HHit *GetTempHit();
};

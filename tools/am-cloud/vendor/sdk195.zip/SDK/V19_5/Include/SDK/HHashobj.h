﻿//BC  1/12/2005  \BobL120\Include\SDK\HHashObj.h

//This is just one of many header files which are distributed with the SDK.    //GREPPLUGIN
//When adding SDK functions, place your prototype in the appropriate SDK/*.h file.
#pragma once

#include "HashTime.h"
//#include "Quaterni.h"
//#include "Rotate.h"
#include "PatchID.h"
//#include "RGBFloat.h"
#include "ObjType.h"
#include "IEModel.h"
// ReSharper disable once CppUnusedIncludeDirective
#include "TimeRang.h"


/**********************************************************
HTreeObject
   HAnimObject
      HCP   - HPC.h
         HHookCP - HCP.h
      HHashObject
         HPropertyDriver - HPropDri.h
            HAttrDriver -
            HBiasDriver
            HConstDriver
            HPropertyShortcut
            HFloatDriver
               HChannelDriver
            HRelationMDShortcut
            HRotateDriver
               HEulerRotateDriver
               HQuaternionRotateDriver
               HVectorRotateDriver
            HTransformDriver
            HVectorDriverNoSubs
            HVector2Driver
         HProperty - HPropert.h
            HBiasProperty
            HBoolProperty
            HContainerProperty
               HAttrProperty
               HFileInfoProperty
               HCategoryProperty
                  HBoolCategoryProperty
                  HTypeCategoryProperty
            HFloatProperty
               HPercentProperty
            HIntProperty
            HRotateProperty
            HStringProperty
               HFilenameProperty
            HTimeProperty
            HTransformProperty
            HTypeProperty
            HVectorProperty
               HColorProperty
               HScaleProperty
               HTranslateProperty
            HVectorPropertyNoSubs
            HVector2Property
            HPointerProperty
               HBitmapProperty
         HGroupCP - HCP.cpp
         HGroup   - HCP.cpp
         HGroupContainer - HCP.CPP
         HBoneCacheContainer
         HBoneCache - HModel.cpp
            HObjectCache
               HSegmentCache
                  HModelCache
               HCamerCache
               HPropCache
               HFXCache
                  HForceCache
                  HMatFXCache
                  HVolFXCache
                     HLightCache
         HLightCacheContainer
         HBoneContainer
         HBone
            HObject
               HSegment
                  HModel
               HCamera
               HProp
               HFX
                  HForce
                  HMatFX
                  HVolFX
                     HLight
         HLightContainer
         HClip
            HBitmap
               HDecal
         HDecalClip
         HDecalClipContainer
         HDecalStamp
         HDecalStampContainer
         HDecalContainer
         HRelationContainer
         HRelation
         HActionCache
            HRelationKey
         HAction
         HObjectCacheContainer
         HActionCacheContainer
         HChor
         HProject
         HAnimObjectShortcut
         HSplineContainer
      HSPline
HPatch
   HPatch5
HChannelCP
HProgressBar
HPropertyInfo
   HBiasPropertyInfo
   HBoolPropertyInfo
   HAttrPropertyInfo
   HFileInfoPropertyInfo
   HFloatPropertyInfo
      HPercentPropertyInfo
   HIntPropertyInfo
   HRotatePropertyInfo
   HStringPropertyInfo
      HFilenamePropertyInfo
   HTimePropertyInfo
   HTransformPropertyInfo
   HTypePropertyInfo
   HVectorPropertyInfo
      HColorPropertyInfo
      HScalePropertyInfoInfo
      HTranslatPropertyInfo
   HVectorPropertyNoSubsInfo
   HVector2PropertyInfo
   HPointerPropertyInfo
HTypeInfo
**********************************************************/

class HProperty;
class HAnimObject;
class HBone;
class HCategoryProperty;
class HUserCategoryProperty;
class HHashObject;
class HashStream;
class HAnimObjectShortcut;
class HPropertyDriver;

//*********************************************************
//** HTreeObject
//*********************************************************
class PLUGINEXPORT HTreeObject {
public:
    //Retrieval
    HProperty *GetPropertyAt(int i);
    ObjectType GetObjectType();
    int GetType();

    void operator delete(void *ptr) noexcept {  // NOLINT(misc-new-delete-overloads)
        DeleteHandle((HTreeObject *)ptr);
    }

    static void DeleteHandle(HTreeObject *handle) noexcept;

    BOOL IsModified();
    void OnModified();
    void OffModified();
    HTreeObject *FindChildByName(const char *matchname);
    HTreeObject *FindChildByTreeName(const char *treename);
    void ExpandInProjectBar(BOOL expand);
    void RefreshInProjectBar(BOOL updatenow = FALSE);
    void HilightInProjectBar();

    //These 3 functions allow to walk the complete tree hierarchy and skip possible objects based on paramatwers passed in
    enum Skip : uint8_t {
        SKIPNONE = 0x00,
        SKIPINVISIBLE = 0x01,
        SKIPFILTERED = 0x02,
        SKIPADVANCED = 0x04,
        SKIPFOLDERS = 0x08
    };

    HTreeObject *GetTreeParent(uint32_t skip = SKIPINVISIBLE | SKIPFILTERED);
    HTreeObject *GetTreeProgeny(uint32_t skip = SKIPINVISIBLE | SKIPFILTERED);
    HTreeObject *GetTreeSibling(uint32_t skip = SKIPINVISIBLE | SKIPFILTERED);
    HTreeObject *GetParent(); //Skips user containers, and doesn't include classes not derived off HashObject (CPs)//
    void SetParent(HTreeObject *parent);
    void ReassignPtr(void *ptruplink, HTreeObject *newvalue);
    HAnimObject *GetAnimObject();
    HAnimObject *GetAnimObjectNotProperty();

    String GetMatchName();
    String GetTreeName();
    String GetFileName();
    String GetFullName();

    HBone *IsBone(); //returns this as an HBone if it is one, or nullptr;
    BOOL IsActionObjectChild();

    void InterpolateObjects(Time time, BOOL notify = TRUE);
    void Interpolate(Time time, BOOL notify = TRUE);
    void OffInterpolate(HProperty *dueto);

    HHashObject *IsHashObject();
    HAnimObjectShortcut *IsAnimObjectShortcut();
    HPropertyDriver *IsPropertyDriver();

    bool Save(HashStream &hs);
    void SetVisible(BOOL visible);

    void SetTempBit(BOOL state);
    BOOL GetTempBit();

    HProperty *IsProperty();
};

class HObject;

//*********************************************************
//** HAnimObject
//*********************************************************
class PLUGINEXPORT HAnimObject : public HTreeObject {
public:
    BOOL IsCache();
    HAnimObject *GetCache(); //will return it self if it is the cache
    Time GetFirstKey(bool *isselected = nullptr) const;
    [[nodiscard]] Time GetLastKey() const;
    Time GetNextKey(Time time, bool *isselected = nullptr) const;
    [[nodiscard]] Time GetPrevKey(Time time) const;
    [[nodiscard]] BOOL IsKey(Time time) const;
    [[nodiscard]] int CountKeys() const;
    BOOL DeleteKey(Time time, BOOL storeundo = TRUE);
    BOOL Reduce(float error);
    void DeleteKeys(const TimeRange &range);
    void TransformKeys(const TimeRange &range, float scale, Time offset, BOOL issnaptoint);
    void RemoveDrivers();

    HObject *GetHObject();
    HObject *GetActionObject();
};

//*********************************************************
//** HHashObject
//*********************************************************
class PLUGINEXPORT HHashObject : public HAnimObject {
public:
    //Retrieval
    char *GetName();
    void SetName(const char *name);
    BOOL IsKindOfBoneCache();

    //Hierachy
    HHashObject *GetChild(); //Skips user containers, and doesn't include classes not derived off HashObject (CPs)//
    void SetChild(HHashObject *child);
    HHashObject *GetSibling(); //Skips user containers, and doesn't include classes not derived off HashObject (CPs)//
    void SetSibling(HHashObject *sibling);
    HHashObject *GetSiblingSame(); //Skips user containers, and doesn't include classes not derived off HashObject (CPs)//
    HHashObject *GetParentOfType(ObjectType ot); //Skips user containers, and doesn't include classes not derived off HashObject (CPs)//
    HHashObject *GetHeadInstance();
    HHashObject *GetNextInstance(HHashObject *instance);
    HCategoryProperty *GetPluginProperties();
    HUserCategoryProperty *CreateUserCategoryProperty(); //will return the User Properties if it already exists
    HUserCategoryProperty *GetUserCategoryProperty();
    HHashObject *InsertUserFolder(); //insert a folder , only possible when parent is a UserFolder or Chor

    void InsertChildAtTail(HHashObject *child, BOOL modify = TRUE);
    void InsertChildAtHead(HHashObject *child);
    void InsertChildAtTailOfType(HHashObject *child);
    void InsertChildAtHeadOfType(HHashObject *child);
    void InsertChildAfterObject(HHashObject *child, HHashObject *after, BOOL markmodified = TRUE);
    void InsertChildAlpha(HHashObject *child, BOOL modify = TRUE);
    void InsertChildOfTypeAlpha(HHashObject *child);
    void InsertSibling(HHashObject *child);

    void Unstitch();
    void UnstitchWithChildren(BOOL markparentmodified = TRUE);
    void Move(HHashObject *parent, HHashObject *oldersibling, BOOL select = TRUE, BOOL markparentmodified = TRUE);
    void MoveWithChildren(HHashObject *parent, HHashObject *oldersibling, BOOL select = TRUE, BOOL markparentmodified = TRUE);
    void MarkViewsNeedDrawn();
    void SaveAllToUndo(); //This is expensive and shouldn't be done unless you are calling routines which do not store step by step info to the Undo stack.
};

//*********************************************************
//** HAnimObjectShortcut
//*********************************************************
class PLUGINEXPORT HAnimObjectShortcut : public HHashObject {
public:
    static HAnimObjectShortcut *New(const char *name, BOOL isforrelation);
    HAnimObject *GetAnimObject();
    HAnimObjectShortcut *MakeCopy();
    void Copy(HAnimObjectShortcut *other);
};

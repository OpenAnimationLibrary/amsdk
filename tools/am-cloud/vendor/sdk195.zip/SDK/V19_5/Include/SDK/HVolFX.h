//Dan  12/10/2002  \Dan100\Include\SDK\HVolFX.h
#pragma once

#include "HFX.h"

//*********************************************************
//** HVolFXCache
//*********************************************************
class PLUGINEXPORT HVolFXCache : public HFXCache {
public:
    HColorProperty *GetColor();
    HFloatProperty *GetQuality();
    HFloatProperty *GetBrightness();
    HFloatProperty *GetContrast();
};

//*********************************************************
//** HVolFX
//*********************************************************
class PLUGINEXPORT HVolFX : public HFX {
public:
    HColorProperty *GetColor();
    HFloatProperty *GetQuality();
    HFloatProperty *GetBrightness();
    HFloatProperty *GetContrast();
};

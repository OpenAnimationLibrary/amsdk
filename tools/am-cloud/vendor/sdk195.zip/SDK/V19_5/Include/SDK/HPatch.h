//BC  12/20/2004  \BobL120\Include\SDK\HPatch.h
#pragma once

//*********************************************************
//** HSpline
//*********************************************************
class HCP;

class PLUGINEXPORT HSpline final : public HAnimObject {
public:
    HCP *GetHeadCP();
    HSpline *GetNextSpline();
    HCP *CreateCPAtHead(const Vector &p);
    HCP *CreateCPAtTail(const Vector &p);
    HCP *CreateCPBefore(HCP *beforecp, const Vector &p);
    HCP *CreateCPAfter(HCP *aftercp, const Vector &p);
    BOOL DeleteCP(HCP *cp);
    BOOL MakeLooped(BOOL looped);

    void operator delete(void *ptr) noexcept {  // NOLINT(misc-new-delete-overloads)
        DeleteHandle((HSpline *)ptr);
    }

    static void DeleteHandle(HSpline *handle);

    float GetLength();
    BOOL GetPositionAndDirection(float ease, Vector &position, Vector &direction);
};

//*********************************************************
//** HSplineInstance
//*********************************************************
class PLUGINEXPORT HSplineInstance final : public HAnimObject {
public:
    HSpline *GetSpline();
    BOOL GetPositionAndDirection(float ease, Vector &position, Vector &direction);
};

//*********************************************************
//** HSplineContainer
//*********************************************************
class PLUGINEXPORT HSplineContainer final : public HHashObject {
public:
    HSpline *GetChildSpline();
};

//*********************************************************
//** HPatch
//*********************************************************
class PLUGINEXPORT HPatch {
public:
    //void  operator delete( void *ptr ) { DeleteHandle( (HPatch *)ptr ); }
    static void DeleteHandle(HPatch *handle);
    HCP *GetCP1();
    HCP *GetCP2();
    HCP *GetCP3();
    HCP *GetCP4();
    Vector &GetIT1();
    Vector &GetOT1();
    Vector &GetIT2();
    Vector &GetOT2();
    Vector &GetIT3();
    Vector &GetOT3();
    Vector &GetIT4();
    Vector &GetOT4();

    //flags
    BOOL IsFlipV1();
    BOOL IsFlipV2();
    BOOL IsFlipV3();
    BOOL IsFlipV4();
    BOOL IsHook1();
    BOOL IsHook2();
    BOOL IsHook3();
    BOOL IsHook4();
    BOOL IsUseHook1();
    BOOL IsUseHook2();
    BOOL IsUseHook3();
    BOOL IsUseHook4();
    BOOL IsEndHook1();
    BOOL IsEndHook2();
    BOOL IsEndHook3();
    BOOL IsEndHook4();
    BOOL IsHookData1();
    BOOL IsHookData2();
    BOOL IsHookData3();
    BOOL IsHookData4();

    int GetGroupImageRotation();
    PatchID GetPatchID();
    HAttrProperty *GetCompositedAttr();
    HAttrProperty *GetAttr();
    int GetNumPoints();
    void GetPatchPoints(Vector *p); //12 points if 4 point patch,  15 points if 5 point patch
    void ReverseNormal();
    Vector GetPointOnPatch(float s, float t);
    Vector GetPointNormalOnPatch(float s, float t, Vector &normal);
};

//*********************************************************
//** HPatch5
//*********************************************************
class PLUGINEXPORT HPatch5 final : public HPatch {
public:
    HPatch5 *GetNextPatch5();
    HCP *GetCP5();
    Vector &GetIT5();
    Vector &GetOT5();
    PatchID5 GetPatchID();
    BOOL IsFlipV5();
};

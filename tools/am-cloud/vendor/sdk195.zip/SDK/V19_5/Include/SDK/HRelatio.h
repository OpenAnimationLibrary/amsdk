//Dan  2/13/2004  \DanLP110\Include\SDK\HRelatio.h
#pragma once

#include "HHashobj.h"
#include "HAction.h"

class HRelation;

//*********************************************************
//** HRelationContainer
//*********************************************************
class PLUGINEXPORT HRelationContainer final : public HHashObject {
public:
    HRelation *CreateRelation(HProperty *drivingproperty);
};

//*********************************************************
//** HRelation
//*********************************************************
class PLUGINEXPORT HRelation final : public HActionCache {
public:
    HModel *StartEdit();
    void EndEdit(HModel *hm);

    //Properties
    HProperty *GetControllingProperty();
    HPercentProperty *GetEnforcement();
    HFloatProperty *RadiusFactor();
    HTimeProperty *GetLag();
    int GetKeyDim();
};

//*********************************************************
//** HRelationKey
//*********************************************************
class PLUGINEXPORT HRelationKey final : public HHashObject {
//public:
};
